# Hi-Tech Store - VibeCoding Blueprint

## Project Overview
متجر إلكتروني عربي احترافي لخدمات الكمبيوتر واللاب توب وكاميرات المراقبة، باسم Hi-Tech، م / أحمد أبو النجا، بلقاس – شارع الدهايمة. الواجهة العامة (Storefront) متجاوبة Mobile First بثلاث لغات بصرية (عربي افتراضيًا) وتدعم تصفح التصنيفات، البحث، الفلاتر الديناميكية، صفحة منتج احترافية، سلة مشتريات، Checkout يرسل الطلب إلى واتساب 01002261030، صفحة عروض، خدمات، من نحن، اتصل بنا. لوحة التحكم (Admin) كاملة وقوية: Dashboard بإحصائيات، إدارة المنتجات/التصنيفات/الطلبات/العملاء/المخزون/Banners/العروض/الإعدادات/المستخدمين والصلاحيات/Backup & Restore. كل البيانات محفوظة في قاعدة بيانات حقيقية (Nubase/Firestore) مع Authentication، Storage للصور، Server Functions للعمليات الحساسة، وبنية POS-ready للمزامنة المستقبلية مع نظام Hi-Tech POS.

## Three Design Directions
### Direction 1: Modern Tech Red/Blue
**Summary:** هوية Hi-Tech بالأحمر والأزرق على خلفية بيضاء، بطاقات منتجات نظيفة، رأس لاصق، Hero قابل للتحرير، أقسام غنية، زر واتساب عائم.
**Probability:** 0.95

### Direction 2: Editorial Premium
**Summary:** تخطيط مجلة، صور كبيرة، تايبوغرافي بارز، مساحات بيضاء فاخرة، أقل لمسة تقنية.
**Probability:** 0.35

### Direction 3: Compact Marketplace
**Summary:** كثافة عالية، كتالوج أولاً، ألوان أقل، أسلوب أمازون/جوميا مع لمسة محلية.
**Probability:** 0.45

## Selected Direction: Modern Tech Red/Blue
المستخدم حدّد صراحةً ألوان الأحمر والأزرق، Modern/Professional، Mobile First، مع لمسة تقنية تناسب الكمبيوتر واللاب توب وكاميرات المراقبة. هذا الاتجاه يعطي إشارة قوية للعلامة التجارية Hi-Tech، ويحافظ على كثافة معتدلة لعرض منتجات كثيرة، مع لوحة تحكم Dense dashboard تناسب إدارة مئات المنتجات.

## Design Principles
- Mobile First: كل قسم يبدأ بالهاتف ثم يكبر، بطاقة منتج واحدة على الموبايل.
- الأحمر والأزرق كلونين أساسيين متبادلين (Red للخصومات و"اطلب عبر واتساب"، Blue للأزرار الرئيسية وروابط الـCTA)، مع رمادي محايد للنصوص والخلفيات.
- كل عنصر مرئي يخدم تصفحًا أو شراءً — لا زخرفة مفرطة.
- سرعة الموبايل أولوية: صور محسّنة، lazy load، pagination، لا تحميل كامل الكتالوج مرة واحدة.
- الإدارة بدون كود: كل المحتوى قابل للتعديل من لوحة التحكم بما في ذلك الـBanners والعروض والخدمات والإعدادات.

## Color Philosophy
- Hi-Tech Red (#DC2626) — الخصومات، زر "اطلب عبر واتساب"، التنبيهات، الأخطاء.
- Hi-Tech Blue (#1E40AF) — الأزرار الرئيسية (أضف للسلة، Checkout)، الروابط، الهوية العامة.
- Neutral White (#FFFFFF) وOff-White (#F8FAFC) — خلفيات البطاقات والصفحات.
- Text Gray (#0F172A للنصوص الأساسية، #64748B للنصوص الثانوية).
- Status colors: Success Green (#16A34A)، Warning Amber (#D97706)، Stock-out Gray (#9CA3AF).

## Layout Paradigm
- الواجهة العامة: رأس لاصق (شعار + تصنيفات drawer + بحث + سلة + اتصال + واتساب)، Hero banner، شبكة تصنيفات، أقسام منتجات (أحدث/عروض/مميزة/الأكثر طلبًا)، قسم خدمات، Footer متعدد الأعمدة.
- صفحة التصنيف: رأس مع صورة/عنوان، فلاتر عمودية على الديسكتوب وأفقية accordion على الموبايل، شبكة منتجات مع Pagination، ترتيب (الأحدث/الأرخص/الأغلى/الأكثر مبيعًا).
- صفحة المنتج: gallery يسار/فوق، معلومات يمين/تحت، تبويبات (وصف/مواصفات/مراجعات)، منتجات مشابهة، منتجات مرتبطة.
- السلة/Checkout: بطاقة ملخص + جدول منتجات، نموذج عميل بسيط، زر إرسال واتساب.
- لوحة التحكم: Sidebar يسار + Topbar علوي + محتوى متغير، بطاقات KPI، جداول قابلة للفرز والبحث، modals للإضافة/التعديل.

## Interaction Philosophy
- كل زر ينفذ إجراءً مرئيًا: فتح drawer، تبديل تبويب، إضافة للسلة، إظهار toast، فتح modal.
- تأكيد قبل الحذف.
- رسائل نجاح/خطأ واضحة بالعربية.
- Lazy Loading للصور، Pagination للمنتجات، لا تحميل كل المنتجات مرة.
- بحث فوري (debounce 300ms) + Search Suggestions.
- السلة تُحفظ في localStorage للزائر، ومزامنتها مع قاعدة البيانات عند إتمام الطلب.
- WhatsApp Checkout: توليد رسالة منسقة (اسم العميل، المنتجات بالكميات والأسعار والإجمالي، طريقة الدفع، ملاحظات) وإرسالها إلى 01002261030.

## Typography System
- النص العربي: Cairo أو Tajawal (Google Fonts)، 400/500/600/700.
- Hierarchy: H1 28–32px، H2 22–24px، H3 18px، Body 14–15px، Small 12px.
- Line height 1.6 للنصوص الطويلة، 1.2 للعناوين.
- الأرقام الإنجليزية في الأسعار (tabular-nums).
- RTL أصيل في كل العناصر، dir="rtl" على html.

## Page Structure
### 1. Home (/)
رأس، Hero banner قابل للتحرير، شبكة تصنيفات، أحدث المنتجات، العروض، منتجات مميزة، الأكثر طلبًا، الخدمات، بيانات المحل، Footer.

### 2. All Products (/products)
قائمة كاملة بمنتجات المتجر مع فلاتر أفقية وترتيب وPagination.

### 3. Category (/category/:slug)
منتجات تصنيف محدد مع فلاتر ديناميكية حسب النوع.

### 4. Product Details (/product/:slug)
صفحة منتج كاملة: gallery، معلومات، تبويبات، CTA، مشابه.

### 5. Cart (/cart)
سلة المشتريات: تعديل الكميات، حذف، الإجمالي.

### 6. Checkout (/checkout)
نموذج بيانات العميل، ملخص الطلب، توليد رسالة واتساب.

### 7. Offers (/offers)
صفحة العروض والخصومات النشطة.

### 8. Services (/services)
الخدمات التي يقدمها المحل (تركيب، صيانة، شبكات...).

### 9. About Us (/about)
من نحن — محتوى قابل للتعديل من لوحة التحكم.

### 10. Contact Us (/contact)
بيانات التواصل، Google Maps قابل للتعديل، ساعات العمل.

### 11. Search (/search)
نتائج البحث مع فلاتر.

### 12. Admin Login (/admin/login)
تسجيل دخول الأدمن عبر Email + Password.

### 13. Admin Dashboard (/admin)
إحصائيات، KPIs، Charts.

### 14. Admin Products (/admin/products)
إدارة المنتجات (CRUD + رفع صور + خصائص + خصم + مخزون).

### 15. Admin Categories (/admin/categories)
إدارة التصنيفات والـSubcategories وترتيبها وإخفائها.

### 16. Admin Orders (/admin/orders)
إدارة الطلبات وحالاتها.

### 17. Admin Customers (/admin/customers)
قائمة العملاء وطلباتهم السابقة وإجمالي مشترياتهم.

### 18. Admin Inventory (/admin/inventory)
عرض وتعديل الكميات وحالات المخزون.

### 19. Admin Banners (/admin/banners)
إدارة Banners الـHero.

### 20. Admin Offers (/admin/offers)
إنشاء وإدارة العروض والـBundles (تاريخ بداية/نهاية، منتجات، سعر).

### 21. Admin Services (/admin/services)
إدارة الخدمات المعروضة في الموقع.

### 22. Admin Settings (/admin/settings)
إعدادات الموقع (اسم، شعار، هاتف، واتساب، عنوان، ساعات العمل، سوشيال، SEO).

### 23. Admin Users (/admin/users)
إدارة المستخدمين والصلاحيات (Admin/Manager/Staff).

### 24. Admin Payment Methods (/admin/payment-methods)
إدارة طرق الدفع (Cash، Vodafone Cash، InstaPay، تحويل بنكي).

### 25. Admin Backup & Restore (/admin/backup)
تصدير واستيراد JSON لكل البيانات (منتجات، تصنيفات، عملاء، طلبات، إعدادات).

### 26. Admin Activity Logs (/admin/logs)
سجل النشاطات للأمان.

## First Version Implementation Scope
- تجهيز مشروع TanStack Start بواجهة عربية RTL، خطوط Cairo/Tajawal، Tailwind، نظام تصميم Hi-Tech Red/Blue.

## Acceptance Criteria
- تسجيل دخول الأدمن عبر Email + Password، عدم دخول أي صفحة /admin/* بدون جلسة نشطة، ظهور رسالة خطأ واضحة عند فشل الدخول.
- إضافة/تعديل/حفظ/حذف منتج حقيقيًا في قاعدة البيانات (اسم، ماركة، موديل، SKU، Barcode، صور، أسعار، خصم، مخزون، خصائص، tags، أعلام).
- رفع صور متعددة للمنتج وحفظها في Storage، مع تحديد الصورة الرئيسية وترتيب الصور وإنشاء thumbnail.
- إدارة التصنيفات (إضافة/تعديل/حذف/ترتيب/إخفاء/إظهار) مع صورة وSubcategories، وانعكاسها فورًا على الواجهة.
- البحث يعمل على الاسم والماركة والموديل وSKU والوصف، مع Search Suggestions أثناء الكتابة.
- الفلاتر ديناميكية وتختلف حسب التصنيف (مثل: لابتوبات = ماركة/معالج/RAM/تخزين، كاميرات = دقة/نوع/IP/Outdoor).
- حساب الخصم تلقائيًا (نسبة الخصم، السعر بعد الخصم، السعر قبل الخصم)، إمكانية إيقاف الخصم، منع الكميات الأكبر من المخزون في السلة.
- حالات المخزون الصحيحة: متوفر / كمية محدودة / نفذ / غير متاح، مع ظهور "غير متوفر حاليًا" عند الصفر ومنع الإضافة للسلة.
- السلة تعدّل الكميات وتحذف وتحسب الإجمالي، تنتقل إلى Checkout يطلب بيانات العميل ويولد رسالة واتساب منظمة بصيغة المتجر إلى 01002261030.
- زر واتساب عائم يفتح محادثة مع رسالة افتراضية، وأرقام الهاتف والواتساب والعنوان من إعدادات الموقع وليس ثابتة في الكود.
- لوحة التحكم تعرض Dashboard بإحصائيات حقيقية، وإدارة الطلبات بحالات (جديد/تم التواصل/مؤكد/قيد التجهيز/شُحن/سُلّم/ملغي)، وإدارة العملاء (الاسم/الهاتف/العنوان/الطلبات السابقة/إجمالي المشتريات).
- إعدادات الموقع (اسم المتجر، الشعار، الهاتف، واتساب، العنوان، ساعات العمل، سوشيال، SEO meta، Favicon) قابلة للتعديل من لوحة التحكم وتنعكس على الواجهة.
- نظام Backup/Restore حقيقي: تصدير واستيراد المنتجات/التصنيفات/العملاء/الطلبات/الإعدادات.
- الأمان: التحقق من الصلاحيات في كل عملية Admin، عدم وجود مفاتيح سرية في Frontend، التحقق من المدخلات، حماية صفحات الإدارة.
- الأداء: Lazy Loading للصور، Pagination، SEO (meta title/description/slug)، Structured Data للمنتجات، سرعة تحميل جيدة على الموبايل.
- بنية POS-ready: IDs وعلاقات واضحة بين المنتجات والتصنيفات والمخزون والطلبات، تشبه بنية Firestore حتى يمكن مزامنة POS (https://hi-tech-pos.web.app/) مستقبلًا.

## Enhancement Suggestions
### استيراد منتجات بالجملة من Excel/CSV
- **Category:** Workflow
- **Description:** صفحة في اللوحة لاستيراد ملف Excel/CSV يحتوي على أعمدة (اسم، SKU، سعر، مخزون، ماركة، ...) وإنشاء المنتجات تلقائيًا مع معاينة الأخطاء قبل الحفظ.
- **Recommended:** Yes
- **Requires backend:** Yes
- **Backend modules:** database.crud, storage.private_bucket
- **Implementation notes:** يستفيد من server_functions لمعالجة الملف في الخادم، وإرجاع JSON قابل للمعاينة قبل الكتابة النهائية.

### تاريخ مشتريات العميل وإجمالي ما اشتراه
- **Category:** Data
- **Description:** تفصيل كل عميل: قائمة طلباته السابقة، إجمالي المشتريات، متوسط قيمة الطلب، آخر تاريخ شراء، لتسهيل المتابعة والـLoyalty.
- **Recommended:** Yes
- **Requires backend:** Yes
- **Backend modules:** database.crud
- **Implementation notes:** يُحسَب من جدول orders المرتبط بـcustomers؛ يحتاج Aggregates في Firestore أو حساب server-side.

### تنبيهات انخفاض المخزون للأدمن
- **Category:** Notification
- **Description:** عندما تصل كمية منتج لحد المخزون المنخفض، تظهر علامة في Topbar، وصفحة المخزون تُبرز هذه المنتجات بالأحمر، وإشعار في الـDashboard.
- **Recommended:** Yes
- **Requires backend:** No
- **Implementation notes:** حساب خفيف على مستوى الصفحة بدون server_function، فقط استعلام من Firestore مع فلتر quantity<=low_stock_threshold.

### صلاحيات متقدمة: Admin / Manager / Staff
- **Category:** Permissions
- **Description:** إضافة أدوار بأذونات جزئية: Admin = كل شيء، Manager = إدارة المنتجات والطلبات بدون إعدادات حساسة، Staff = قراءة فقط أو عمليات محددة.
- **Recommended:** No
- **Requires backend:** Yes
- **Backend modules:** database.crud, auth.email_password
- **Implementation notes:** يتطلب إضافة حقل role في users و Guards في كل admin route، يُفضّل تأجيله لما بعد طبقة Auth الأساسية.

### حزم / Bundles منتجات بسعر مجمع
- **Category:** Feature
- **Description:** إنشاء باقات (مثلاً: كاميرا + DVR + هارد بسعر مخفض)، تظهر كمنتج واحد في الواجهة مع إمكانية ربطها بمنتجات حقيقية في المخزون.
- **Recommended:** No
- **Requires backend:** Yes
- **Backend modules:** database.crud
- **Implementation notes:** جدول bundles يربط بـproduct_variants ومكوناتها، مع سعر إجمالي.

### مساعد AI لكتابة وصف المنتج بالعربية
- **Category:** UX
- **Description:** زر "اقترح وصفًا" داخل نموذج إضافة المنتج، يأخذ اسم المنتج والمواصفات ويولّد وصفًا تسويقيًا قصيرًا بالعربية.
- **Recommended:** No
- **Requires backend:** No
- **Implementation notes:** يحتاج مفتاح مزوّد AI يُحقن عبر context.env في server function، لا يُكشف في Frontend.

## Backend Recommendation
Provision a real backend with modules: auth.email_password, database.crud, storage.private_bucket, server_functions.secure_action.

<!-- ottermind:vibecoding-blueprint-decision:start -->
## Generation Confirmation Record

Status: Pending user confirmation
- Backend mode: Pending
- Login/auth: Pending
- Database persistence: Pending
- File upload/storage: Pending
- Selected enhancements: Pending
- Choice: Pending
- Source: Pending
- Updated at: Pending
<!-- ottermind:vibecoding-blueprint-decision:end -->
