-- Atomic, tamper-proof order placement.
-- Prices, names and SKUs are read from `products` inside the function; the
-- caller only says WHICH products and HOW MANY. Everything runs in one
-- transaction, so a failure (for example not enough stock) rolls back stock,
-- customer and order changes together.

create or replace function public.place_order(
  p_customer jsonb,
  p_items jsonb,
  p_payment text default 'cash'
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_name    text := left(trim(coalesce(p_customer->>'name', '')), 100);
  v_phone   text := regexp_replace(translate(coalesce(p_customer->>'phone', ''), '٠١٢٣٤٥٦٧٨٩', '0123456789'), '\D', '', 'g');
  v_address text := nullif(left(trim(coalesce(p_customer->>'address', '')), 300), '');
  v_notes   text := nullif(left(trim(coalesce(p_customer->>'notes', '')), 500), '');
  v_cust    uuid;
  v_order   uuid;
  v_number  text;
  v_total   numeric := 0;
  v_lines   jsonb := '[]'::jsonb;
  e         jsonb;
  r         record;
  v_prod    public.products%rowtype;
begin
  if v_name = '' then raise exception 'اسم العميل مطلوب'; end if;
  if length(v_phone) < 8 or length(v_phone) > 15 then raise exception 'رقم الهاتف غير صحيح'; end if;
  if p_items is null or jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items) = 0 then
    raise exception 'السلة فارغة';
  end if;
  if jsonb_array_length(p_items) > 50 then raise exception 'عدد الأصناف في الطلب كبير جدًا'; end if;

  for e in select * from jsonb_array_elements(p_items) loop
    if coalesce(e->>'product_id', '') !~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' then
      raise exception 'منتج غير صالح في السلة';
    end if;
    if coalesce(e->>'quantity', '') !~ '^[0-9]{1,2}$' or (e->>'quantity')::int < 1 then
      raise exception 'الكمية غير صحيحة';
    end if;
  end loop;

  -- customer (match by phone)
  select id into v_cust from public.customers where phone = v_phone limit 1;
  if v_cust is null then
    insert into public.customers (name, phone, address, notes, total_orders, total_spent, last_order_at)
    values (v_name, v_phone, v_address, v_notes, 0, 0, now())
    returning id into v_cust;
  else
    update public.customers
       set name = v_name,
           address = coalesce(v_address, address),
           notes = coalesce(v_notes, notes),
           updated_at = now()
     where id = v_cust;
  end if;

  v_number := 'HT-' || (extract(epoch from clock_timestamp()) * 1000)::bigint || '-' || (1000 + floor(random() * 9000))::int;

  insert into public.orders (order_number, customer_id, customer_name, customer_phone, customer_address, notes,
                             payment_method, status, subtotal, discount, total, source)
  values (v_number, v_cust, v_name, v_phone, v_address, v_notes,
          left(coalesce(nullif(p_payment, ''), 'cash'), 50), 'new', 0, 0, 0, 'website')
  returning id into v_order;

  for r in
    select (x->>'product_id')::uuid as pid, sum((x->>'quantity')::int)::int as qty
      from jsonb_array_elements(p_items) x
     group by 1
  loop
    -- atomic: only succeeds while the item is available and stock is enough
    update public.products
       set stock = stock - r.qty, updated_at = now()
     where id = r.pid and is_available = true and price > 0 and stock >= r.qty
    returning * into v_prod;
    if not found then
      raise exception 'أحد المنتجات غير متاح أو الكمية المطلوبة غير كافية، حدّث السلة وحاول مرة أخرى';
    end if;

    insert into public.order_items (order_id, product_id, product_name, product_sku, unit_price, quantity, line_total)
    values (v_order, v_prod.id, v_prod.name, v_prod.sku, v_prod.price, r.qty, v_prod.price * r.qty);

    v_total := v_total + v_prod.price * r.qty;
    v_lines := v_lines || jsonb_build_object(
      'product_id', v_prod.id, 'name', v_prod.name, 'unit_price', v_prod.price, 'quantity', r.qty);
  end loop;

  update public.orders set subtotal = v_total, total = v_total where id = v_order;
  update public.customers
     set total_orders = total_orders + 1, total_spent = total_spent + v_total, last_order_at = now()
   where id = v_cust;
  insert into public.activity_logs (action, entity_type, entity_id, details)
  values ('order_created', 'order', v_order::text,
          jsonb_build_object('order_number', v_number, 'total', v_total, 'source', 'website'));

  return jsonb_build_object('order_number', v_number, 'id', v_order, 'total', v_total, 'lines', v_lines);
end;
$$;

revoke all on function public.place_order(jsonb, jsonb, text) from public;
grant execute on function public.place_order(jsonb, jsonb, text) to anon, authenticated, service_role;

-- Orders can now only be created through place_order(). Direct inserts with the
-- public key (arbitrary totals, spam) are no longer allowed.
drop policy if exists "Public insert customers" on public.customers;
drop policy if exists "Public insert orders" on public.orders;
drop policy if exists "Public insert order items" on public.order_items;
