create or replace function public.jwt_email()
returns text
language sql
stable
as $$
  select lower(coalesce(nullif(current_setting('request.jwt.claims', true), '')::json->>'email', ''));
$$;

create or replace function public.is_active_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.admin_users a
    where coalesce(a.is_active, true) = true
      and public.jwt_email() <> ''
      and lower(a.email) = public.jwt_email()
  );
$$;

create or replace function public.admin_bootstrap_open()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select not exists (select 1 from public.admin_users);
$$;

drop policy if exists "Admin full access admin_users" on public.admin_users;
drop policy if exists "Admins can read admin_users" on public.admin_users;
drop policy if exists "Bootstrap or invite admin_users" on public.admin_users;
drop policy if exists "Admins can update admin_users" on public.admin_users;
drop policy if exists "Admins can delete admin_users" on public.admin_users;

create policy "Admins can read admin_users" on public.admin_users
  for select using (public.is_active_admin());

create policy "Bootstrap or invite admin_users" on public.admin_users
  for insert with check (
    public.is_active_admin()
    or (public.admin_bootstrap_open() and lower(email) = public.jwt_email())
  );

create policy "Admins can update admin_users" on public.admin_users
  for update using (public.is_active_admin()) with check (public.is_active_admin());

create policy "Admins can delete admin_users" on public.admin_users
  for delete using (public.is_active_admin());

drop policy if exists "Admin full access categories" on public.categories;
create policy "Admin full access categories" on public.categories for all
  using (public.is_active_admin()) with check (public.is_active_admin());

drop policy if exists "Admin full access brands" on public.brands;
create policy "Admin full access brands" on public.brands for all
  using (public.is_active_admin()) with check (public.is_active_admin());

drop policy if exists "Admin full access products" on public.products;
create policy "Admin full access products" on public.products for all
  using (public.is_active_admin()) with check (public.is_active_admin());

drop policy if exists "Admin full access product_images" on public.product_images;
create policy "Admin full access product_images" on public.product_images for all
  using (public.is_active_admin()) with check (public.is_active_admin());

drop policy if exists "Admin full access banners" on public.banners;
create policy "Admin full access banners" on public.banners for all
  using (public.is_active_admin()) with check (public.is_active_admin());

drop policy if exists "Admin full access offers" on public.offers;
create policy "Admin full access offers" on public.offers for all
  using (public.is_active_admin()) with check (public.is_active_admin());

drop policy if exists "Admin full access offer_products" on public.offer_products;
create policy "Admin full access offer_products" on public.offer_products for all
  using (public.is_active_admin()) with check (public.is_active_admin());

drop policy if exists "Admin full access services" on public.services;
create policy "Admin full access services" on public.services for all
  using (public.is_active_admin()) with check (public.is_active_admin());

drop policy if exists "Admin full access customers" on public.customers;
create policy "Admin full access customers" on public.customers for all
  using (public.is_active_admin()) with check (public.is_active_admin());

drop policy if exists "Admin full access orders" on public.orders;
create policy "Admin full access orders" on public.orders for all
  using (public.is_active_admin()) with check (public.is_active_admin());

drop policy if exists "Admin full access order_items" on public.order_items;
create policy "Admin full access order_items" on public.order_items for all
  using (public.is_active_admin()) with check (public.is_active_admin());

drop policy if exists "Admin full access payment_methods" on public.payment_methods;
create policy "Admin full access payment_methods" on public.payment_methods for all
  using (public.is_active_admin()) with check (public.is_active_admin());

drop policy if exists "Admin full access pages" on public.pages;
create policy "Admin full access pages" on public.pages for all
  using (public.is_active_admin()) with check (public.is_active_admin());

drop policy if exists "Admin full access activity_logs" on public.activity_logs;
create policy "Admin full access activity_logs" on public.activity_logs for all
  using (public.is_active_admin()) with check (public.is_active_admin());
