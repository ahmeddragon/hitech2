delete from public.admin_users
where email in ('probe-a@example.com', 'probe-b@example.com', 'bootstrap-probe@example.com');
