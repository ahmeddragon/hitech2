create or replace function public.diag_admin_policy_state()
returns jsonb
language sql
stable
security definer
set search_path = public
as $$
  select jsonb_build_object(
    'bootstrap_open', public.admin_bootstrap_open(),
    'auth_uid', auth.uid()::text,
    'is_active_admin', public.is_active_admin(),
    'rls_enabled', (select relrowsecurity from pg_class where oid = 'public.admin_users'::regclass),
    'rls_forced', (select relforcerowsecurity from pg_class where oid = 'public.admin_users'::regclass),
    'current_role', current_user,
    'policies', (
      select coalesce(
        jsonb_agg(jsonb_build_object('name', p.policyname, 'cmd', p.cmd, 'withcheck', p.with_check)),
        '[]'::jsonb
      )
      from pg_policies p
      where p.schemaname = 'public' and p.tablename = 'admin_users'
    )
  );
$$;
