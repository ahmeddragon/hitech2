alter table public.admin_users add column if not exists user_id uuid;

create unique index if not exists admin_users_user_id_key
  on public.admin_users (user_id)
  where user_id is not null;

create or replace function public.is_active_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.admin_users a
    where coalesce(a.is_active, true) = true
      and (
        (a.user_id is not null and a.user_id = auth.uid())
        or (
          a.user_id is null
          and public.jwt_email() <> ''
          and lower(a.email) = public.jwt_email()
        )
      )
  );
$$;

drop policy if exists "Bootstrap or invite admin_users" on public.admin_users;

create policy "Bootstrap or invite admin_users" on public.admin_users
  for insert with check (
    public.is_active_admin()
    or (public.admin_bootstrap_open() and user_id = auth.uid())
  );
