create or replace function public.diag_invoker_claims()
returns jsonb
language sql
stable
as $$
  select jsonb_build_object(
    'invoker_uid', auth.uid()::text,
    'invoker_role', auth.role(),
    'invoker_claims', coalesce(current_setting('request.jwt.claims', true), '<unset>'),
    'invoker_jwt_email', public.jwt_email()
  );
$$;
