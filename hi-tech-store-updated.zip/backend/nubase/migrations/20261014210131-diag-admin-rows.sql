create or replace function public.diag_admin_rows()
returns jsonb
language sql
stable
security definer
set search_path = public
as $$
  select coalesce(
    jsonb_agg(
      jsonb_build_object(
        'id', a.id,
        'masked_email', left(a.email, 3) || '***@' || split_part(a.email, '@', 2),
        'has_user_id', a.user_id is not null,
        'is_active', a.is_active,
        'created_at', a.created_at
      )
    ),
    '[]'::jsonb
  )
  from public.admin_users a;
$$;
