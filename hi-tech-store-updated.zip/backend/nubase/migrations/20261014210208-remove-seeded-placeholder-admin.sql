delete from public.admin_users
where lower(email) like '%@hi-tech.local';

create or replace function public.diag_admin_rows()
returns jsonb
language sql
stable
security definer
set search_path = public
as $$
  select '[]'::jsonb;
$$;
