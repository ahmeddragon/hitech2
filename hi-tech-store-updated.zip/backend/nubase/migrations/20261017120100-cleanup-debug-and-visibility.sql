-- 1) Remove the temporary debugging helpers left from the admin-login work.
drop function if exists public.debug_jwt_claims();
drop function if exists public.diag_admin_rows();
drop function if exists public.diag_admin_policy_state();
drop function if exists public.diag_invoker_claims();

-- 2) The public catalog should only expose products that are available.
--    (Admins keep full access through the "Admin full access products" policy.)
drop policy if exists "Public read available products" on public.products;
create policy "Public read available products" on public.products
  for select using (is_available = true);
