alter table public.settings
  add column if not exists admin_bootstrapped boolean not null default false;

update public.settings
set admin_bootstrapped = true
where id = 'site'
  and exists (select 1 from public.admin_users);
