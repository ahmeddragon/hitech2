drop policy if exists "Bootstrap or invite admin_users" on public.admin_users;

create policy "Bootstrap or invite admin_users" on public.admin_users
  for insert with check (
    public.is_active_admin()
    or (
      public.admin_bootstrap_open()
      and (
        user_id = auth.uid()
        or (public.jwt_email() <> '' and lower(email) = public.jwt_email())
      )
    )
  );
