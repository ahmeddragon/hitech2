create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique,
  sku text unique,
  barcode text unique,
  name text not null,
  brand_id uuid references public.brands(id) on delete set null,
  category_id uuid references public.categories(id) on delete set null,
  model text,
  short_description text,
  description text,
  specs jsonb not null default '{}'::jsonb,
  tags text[] not null default '{}',
  price_original numeric(12, 2) not null default 0,
  price numeric(12, 2) not null default 0,
  discount_percent numeric(5, 2) not null default 0,
  stock int not null default 0,
  low_stock_threshold int not null default 3,
  is_available boolean not null default true,
  is_new boolean not null default false,
  is_featured boolean not null default false,
  is_on_sale boolean not null default false,
  is_best_seller boolean not null default false,
  views_count int not null default 0,
  meta_title text,
  meta_description text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists idx_products_slug on public.products(slug);
create index if not exists idx_products_sku on public.products(sku);
create index if not exists idx_products_barcode on public.products(barcode);
create index if not exists idx_products_category on public.products(category_id);
create index if not exists idx_products_brand on public.products(brand_id);
create index if not exists idx_products_available on public.products(is_available);
create index if not exists idx_products_featured on public.products(is_featured);
create index if not exists idx_products_best_seller on public.products(is_best_seller);
create index if not exists idx_products_tags on public.products using gin(tags);

create table if not exists public.product_images (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  url text not null,
  thumbnail_url text,
  sort_order int not null default 0,
  is_main boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists idx_product_images_product on public.product_images(product_id);
