create table if not exists public.settings (
  id text primary key default 'site',
  store_name text not null default 'Hi-Tech',
  store_description text default 'لخدمات الكمبيوتر واللاب توب وكاميرات المراقبة',
  owner_name text default 'م / أحمد أبو النجا',
  phone text default '01002261030',
  whatsapp text default '01002261030',
  address text default 'بلقاس – شارع الدهايمة – بجوار كافيتريا الغريب',
  working_hours text default 'السبت - الخميس: 10 صباحًا - 10 مساءً',
  logo_url text,
  favicon_url text,
  facebook_url text,
  instagram_url text,
  tiktok_url text,
  youtube_url text,
  meta_title text default 'Hi-Tech - كمبيوتر، لاب توب، كاميرات مراقبة',
  meta_description text default 'متجر Hi-Tech في بلقاس لبيع اللاب توب، الكمبيوتر، شاشات، كاميرات المراقبة، DVR/NVR، هاردات، إكسسوارات وخدمات التركيب والصيانة.',
  map_embed text,
  about_content text default 'متجر Hi-Tech هو وجهتك الأولى في بلقاس لخدمات ومنتجات الكمبيوتر واللاب توب وكاميرات المراقبة. نوفر لك أحدث الموديلات، ضمان حقيقي، وتركيب احترافي.',
  whatsapp_default_message text default 'مرحبًا Hi-Tech، أريد الاستفسار عن أحد المنتجات.',
  order_receipt_header text default 'طلب جديد من متجر Hi-Tech',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

insert into public.settings (id) values ('site') on conflict (id) do nothing;
