create or replace function public.debug_jwt_claims()
returns jsonb
language sql
stable
as $$
  select jsonb_build_object(
    'claims_raw', coalesce(current_setting('request.jwt.claims', true), '<unset>'),
    'claim_email', coalesce(current_setting('request.jwt.claim.email', true), '<unset>'),
    'claim_sub', coalesce(current_setting('request.jwt.claim.sub', true), '<unset>'),
    'claim_role', coalesce(current_setting('request.jwt.claim.role', true), '<unset>'),
    'auth_role', coalesce(auth.role(), '<null>'),
    'auth_uid', coalesce(auth.uid()::text, '<null>'),
    'jwt_email_fn', public.jwt_email()
  );
$$;
