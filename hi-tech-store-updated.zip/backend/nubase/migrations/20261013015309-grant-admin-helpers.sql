grant execute on function public.jwt_email() to public;
grant execute on function public.is_active_admin() to public;
grant execute on function public.admin_bootstrap_open() to public;
