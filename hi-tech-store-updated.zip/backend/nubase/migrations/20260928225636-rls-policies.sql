-- Row-Level Security for Hi-Tech Store
alter table public.settings enable row level security;
alter table public.categories enable row level security;
alter table public.brands enable row level security;
alter table public.products enable row level security;
alter table public.product_images enable row level security;
alter table public.banners enable row level security;
alter table public.offers enable row level security;
alter table public.offer_products enable row level security;
alter table public.services enable row level security;
alter table public.customers enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.payment_methods enable row level security;
alter table public.pages enable row level security;
alter table public.activity_logs enable row level security;
alter table public.admin_users enable row level security;

drop policy if exists "Public read settings" on public.settings;
create policy "Public read settings" on public.settings for select using (true);

drop policy if exists "Public read visible categories" on public.categories;
create policy "Public read visible categories" on public.categories for select using (is_visible = true);

drop policy if exists "Public read brands" on public.brands;
create policy "Public read brands" on public.brands for select using (is_visible = true);

drop policy if exists "Public read available products" on public.products;
create policy "Public read available products" on public.products for select using (true);

drop policy if exists "Public read product images" on public.product_images;
create policy "Public read product images" on public.product_images for select using (true);

drop policy if exists "Public read active banners" on public.banners;
create policy "Public read active banners" on public.banners for select using (is_active = true);

drop policy if exists "Public read active offers" on public.offers;
create policy "Public read active offers" on public.offers for select using (is_active = true);

drop policy if exists "Public read offer products" on public.offer_products;
create policy "Public read offer products" on public.offer_products for select using (true);

drop policy if exists "Public read active services" on public.services;
create policy "Public read active services" on public.services for select using (is_active = true);

drop policy if exists "Public read active payment methods" on public.payment_methods;
create policy "Public read active payment methods" on public.payment_methods for select using (is_active = true);

drop policy if exists "Public read active pages" on public.pages;
create policy "Public read active pages" on public.pages for select using (is_active = true);

drop policy if exists "Public insert customers" on public.customers;
create policy "Public insert customers" on public.customers for insert with check (true);

drop policy if exists "Public insert orders" on public.orders;
create policy "Public insert orders" on public.orders for insert with check (true);

drop policy if exists "Public insert order items" on public.order_items;
create policy "Public insert order items" on public.order_items for insert with check (true);

drop policy if exists "Admin full access settings" on public.settings;
create policy "Admin full access settings" on public.settings for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

drop policy if exists "Admin full access categories" on public.categories;
create policy "Admin full access categories" on public.categories for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

drop policy if exists "Admin full access brands" on public.brands;
create policy "Admin full access brands" on public.brands for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

drop policy if exists "Admin full access products" on public.products;
create policy "Admin full access products" on public.products for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

drop policy if exists "Admin full access product_images" on public.product_images;
create policy "Admin full access product_images" on public.product_images for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

drop policy if exists "Admin full access banners" on public.banners;
create policy "Admin full access banners" on public.banners for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

drop policy if exists "Admin full access offers" on public.offers;
create policy "Admin full access offers" on public.offers for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

drop policy if exists "Admin full access offer_products" on public.offer_products;
create policy "Admin full access offer_products" on public.offer_products for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

drop policy if exists "Admin full access services" on public.services;
create policy "Admin full access services" on public.services for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

drop policy if exists "Admin full access customers" on public.customers;
create policy "Admin full access customers" on public.customers for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

drop policy if exists "Admin full access orders" on public.orders;
create policy "Admin full access orders" on public.orders for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

drop policy if exists "Admin full access order_items" on public.order_items;
create policy "Admin full access order_items" on public.order_items for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

drop policy if exists "Admin full access payment_methods" on public.payment_methods;
create policy "Admin full access payment_methods" on public.payment_methods for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

drop policy if exists "Admin full access pages" on public.pages;
create policy "Admin full access pages" on public.pages for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

drop policy if exists "Admin full access activity_logs" on public.activity_logs;
create policy "Admin full access activity_logs" on public.activity_logs for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

drop policy if exists "Admin full access admin_users" on public.admin_users;
create policy "Admin full access admin_users" on public.admin_users for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');
