// Admin Products Management - List with search, edit, delete
import { createFileRoute, Link } from '@tanstack/react-router'
import { useMemo, useRef, useState } from 'react'
import {
  Copy,
  Edit,
  Eye,
  Filter,
  Loader2,
  Plus,
  Search,
  Star,
  Trash2,
  Upload,
  X,
} from 'lucide-react'
import { toast } from 'sonner'
import {
  addProductImageFn,
  deleteProductFn,
  deleteProductImageFn,
  duplicateProductFn,
  setMainProductImageFn,
  upsertProductFn,
} from '../lib/admin'
import { importImageFile } from '../lib/image-upload'
import {
  getBrands,
  getCategories,
  getProducts,
} from '../lib/store-api'
import { Button } from '../components/ui/button'
import type { Brand, Category, Product } from '../lib/types'
import { STOCK_COLORS, STOCK_LABELS, getStockStatus } from '../lib/types'
import { cn } from '../lib/utils'
import { useAuth } from '../lib/auth-context'

type LoaderData = {
  products: Product[]
  categories: Category[]
  brands: Brand[]
}

export const Route = createFileRoute('/admin/products')({
  loader: async (): Promise<LoaderData> => {
    const [res, categories, brands] = await Promise.all([
      getProducts({ data: { page_size: 500 } }),
      getCategories(),
      getBrands(),
    ])
    return { products: res.items, categories, brands }
  },
  component: AdminProducts,
})

function AdminProducts() {
  const { products: initial, categories, brands } = Route.useLoaderData() as LoaderData
  const { accessToken } = useAuth()
  const [search, setSearch] = useState('')
  const [filterCat, setFilterCat] = useState('')
  const [editing, setEditing] = useState<Product | null>(null)
  const [creating, setCreating] = useState(false)
  const [reloadFlag, setReloadFlag] = useState(0)

  const filtered = useMemo(() => {
    return initial.filter((p) => {
      if (filterCat && p.category_id !== filterCat) return false
      if (!search.trim()) return true
      const s = search.toLowerCase()
      return [p.name, p.sku, p.model]
        .filter(Boolean)
        .some((v) => String(v).toLowerCase().includes(s))
    })
  }, [initial, search, filterCat])

  const onDelete = async (p: Product) => {
    if (!confirm(`حذف "${p.name}"؟ هذا الإجراء لا يمكن التراجع عنه.`)) return
    try {
      await deleteProductFn({ data: { id: p.id } })
      toast.success('تم حذف المنتج')
      setReloadFlag(reloadFlag + 1)
      // Force a route invalidation
      window.location.reload()
    } catch (err: any) {
      toast.error(err?.message ?? 'فشل الحذف')
    }
  }

  const onDuplicate = async (p: Product) => {
    try {
      await duplicateProductFn({ data: { id: p.id } })
      toast.success('تم نسخ المنتج')
      window.location.reload()
    } catch (err: any) {
      toast.error(err?.message ?? 'فشل النسخ')
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold">المنتجات</h1>
          <p className="text-sm text-muted-foreground">{filtered.length} منتج</p>
        </div>
        <Button onClick={() => setCreating(true)} className="bg-[var(--ht-blue)] hover:bg-[var(--ht-blue-dark)]">
          <Plus className="size-4 ml-1" /> منتج جديد
        </Button>
      </div>

      <div className="flex gap-2 flex-wrap">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
          <input
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="بحث في المنتجات..."
            className="w-full pr-10 pl-3 py-2 rounded-md border border-border bg-card text-sm"
          />
        </div>
        <select
          value={filterCat}
          onChange={(e) => setFilterCat(e.target.value)}
          className="px-3 py-2 rounded-md border border-border bg-card text-sm"
        >
          <option value="">كل التصنيفات</option>
          {categories.map((c) => (
            <option key={c.id} value={c.id}>{c.name}</option>
          ))}
        </select>
      </div>

      <div className="rounded-xl border border-border bg-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-muted-foreground text-right text-xs uppercase">
              <tr>
                <th className="px-3 py-3 text-right font-medium">المنتج</th>
                <th className="px-3 py-3 text-right font-medium">التصنيف</th>
                <th className="px-3 py-3 text-right font-medium">SKU</th>
                <th className="px-3 py-3 text-right font-medium">السعر</th>
                <th className="px-3 py-3 text-right font-medium">المخزون</th>
                <th className="px-3 py-3 text-right font-medium">الحالة</th>
                <th className="px-3 py-3 text-right font-medium">إجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-3 py-10 text-center text-muted-foreground">
                    لا توجد منتجات
                  </td>
                </tr>
              ) : (
                filtered.map((p) => {
                  const stock = getStockStatus(p)
                  return (
                    <tr key={p.id} className="hover:bg-muted/30">
                      <td className="px-3 py-3">
                        <div className="flex items-center gap-2">
                          {p.main_image?.url ? (
                            <img src={p.main_image.url} alt="" className="size-10 rounded-md object-cover" />
                          ) : (
                            <div className="size-10 rounded-md bg-muted flex items-center justify-center text-xs">—</div>
                          )}
                          <div className="min-w-0">
                            <p className="font-medium line-clamp-1">{p.name}</p>
                            {p.brand && <p className="text-xs text-muted-foreground">{p.brand.name}</p>}
                          </div>
                        </div>
                      </td>
                      <td className="px-3 py-3 text-muted-foreground">{p.category?.name ?? '—'}</td>
                      <td className="px-3 py-3 tabular-nums text-muted-foreground">{p.sku ?? '—'}</td>
                      <td className="px-3 py-3 tabular-nums">
                        {p.price.toLocaleString('ar-EG')} ج.م
                        {p.discount_percent > 0 && (
                          <span className="block text-xs text-[var(--ht-red)]">خصم {Math.round(p.discount_percent)}%</span>
                        )}
                      </td>
                      <td className="px-3 py-3 tabular-nums">{p.stock}</td>
                      <td className="px-3 py-3">
                        <span className={cn('text-xs px-2 py-0.5 rounded border', STOCK_COLORS[stock])}>
                          {STOCK_LABELS[stock]}
                        </span>
                      </td>
                      <td className="px-3 py-3">
                        <div className="flex items-center gap-1">
                          <Link to="/product/$slug" params={{ slug: p.slug }} target="_blank" className="p-1.5 rounded hover:bg-muted" aria-label="معاينة">
                            <Eye className="size-4" />
                          </Link>
                          <button onClick={() => setEditing(p)} className="p-1.5 rounded hover:bg-muted text-[var(--ht-blue)]" aria-label="تعديل">
                            <Edit className="size-4" />
                          </button>
                          <button onClick={() => onDuplicate(p)} className="p-1.5 rounded hover:bg-muted" aria-label="نسخ">
                            <Copy className="size-4" />
                          </button>
                          <button onClick={() => onDelete(p)} className="p-1.5 rounded hover:bg-red-50 text-red-600" aria-label="حذف">
                            <Trash2 className="size-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  )
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {(editing || creating) && (
        <ProductEditModal
          product={editing}
          categories={categories}
          brands={brands}
          accessToken={accessToken}
          onClose={() => {
            setEditing(null)
            setCreating(false)
          }}
          onSaved={() => {
            setEditing(null)
            setCreating(false)
            window.location.reload()
          }}
        />
      )}
    </div>
  )
}

function ProductEditModal({
  product,
  categories,
  brands,
  onClose,
  onSaved,
}: {
  product: Product | null
  categories: Category[]
  brands: Brand[]
  accessToken: string | null
  onClose: () => void
  onSaved: () => void
}) {
  const initial = product
  const [form, setForm] = useState({
    name: initial?.name ?? '',
    slug: initial?.slug ?? '',
    sku: initial?.sku ?? '',
    barcode: initial?.barcode ?? '',
    brand_id: initial?.brand_id ?? '',
    category_id: initial?.category_id ?? '',
    model: initial?.model ?? '',
    short_description: initial?.short_description ?? '',
    description: initial?.description ?? '',
    specs: JSON.stringify(initial?.specs ?? {}, null, 2),
    tags: (initial?.tags ?? []).join(', '),
    price_original: initial?.price_original ?? 0,
    price: initial?.price ?? 0,
    stock: initial?.stock ?? 0,
    low_stock_threshold: initial?.low_stock_threshold ?? 3,
    is_available: initial?.is_available ?? true,
    is_new: initial?.is_new ?? false,
    is_featured: initial?.is_featured ?? false,
    is_on_sale: initial?.is_on_sale ?? false,
    is_best_seller: initial?.is_best_seller ?? false,
    meta_title: initial?.meta_title ?? '',
    meta_description: initial?.meta_description ?? '',
  })
  const [submitting, setSubmitting] = useState(false)
  const [images, setImages] = useState<any[]>(initial?.images ?? [])
  const [newImageUrl, setNewImageUrl] = useState('')
  const [uploading, setUploading] = useState(false)
  const fileInput = useRef<HTMLInputElement>(null)

  const afterImageChange = () => window.location.reload()

  const onUploadFile = async (file: File) => {
    if (!initial) return
    setUploading(true)
    try {
      const url = await importImageFile(file)
      await addProductImageFn({
        data: {
          product_id: initial.id,
          url,
          is_main: images.length === 0,
          sort_order: images.length,
        },
      })
      toast.success('تم رفع الصورة')
      afterImageChange()
    } catch (err: any) {
      toast.error(err?.message ?? 'فشل رفع الصورة')
    } finally {
      setUploading(false)
    }
  }

  const onAddImageUrl = async (url: string) => {
    if (!initial || !url.trim()) return
    try {
      await addProductImageFn({
        data: { product_id: initial.id, url: url.trim(), is_main: images.length === 0, sort_order: images.length },
      })
      toast.success('تمت إضافة الصورة')
      setNewImageUrl('')
      afterImageChange()
    } catch (err: any) {
      toast.error(err?.message ?? 'فشل إضافة الصورة')
    }
  }

  const onDeleteImage = async (img: any) => {
    if (!initial || !img?.id) return
    if (!confirm('حذف هذه الصورة؟')) return
    try {
      await deleteProductImageFn({ data: { id: img.id } })
      toast.success('تم حذف الصورة')
      afterImageChange()
    } catch (err: any) {
      toast.error(err?.message ?? 'فشل حذف الصورة')
    }
  }

  const onSetMainImage = async (img: any) => {
    if (!initial || !img?.id) return
    try {
      await setMainProductImageFn({ data: { product_id: initial.id, id: img.id } })
      toast.success('تم تعيين الصورة الرئيسية')
      afterImageChange()
    } catch (err: any) {
      toast.error(err?.message ?? 'فشل تعيين الصورة الرئيسية')
    }
  }

  // Auto-generate slug from name
  const updateField = (key: keyof typeof form, value: any) => {
    setForm((f) => {
      const next = { ...f, [key]: value }
      if (key === 'name' && !initial) {
        next.slug = String(value)
          .toLowerCase()
          .replace(/[^\p{L}\p{N}\s-]/gu, '')
          .replace(/\s+/g, '-')
          .replace(/-+/g, '-')
          .slice(0, 80)
      }
      // Auto discount
      if (key === 'price' || key === 'price_original') {
        const o = Number(key === 'price_original' ? value : form.price_original)
        const p = Number(key === 'price' ? value : form.price)
        if (o > 0 && p < o) {
          next.is_on_sale = true
        }
      }
      return next
    })
  }

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitting(true)
    try {
      let specsObj = {}
      try {
        specsObj = JSON.parse(form.specs)
      } catch {
        toast.error('صيغة المواصفات الفنية يجب أن تكون JSON صحيح')
        setSubmitting(false)
        return
      }
      const tags = form.tags.split(',').map((t) => t.trim()).filter(Boolean)
      const payload = {
        ...(initial?.id ? { id: initial.id } : {}),
        slug: form.slug,
        sku: form.sku || null,
        barcode: form.barcode || null,
        name: form.name,
        brand_id: form.brand_id || null,
        category_id: form.category_id || null,
        model: form.model || null,
        short_description: form.short_description || null,
        description: form.description || null,
        specs: specsObj,
        tags,
        price_original: Number(form.price_original),
        price: Number(form.price),
        discount_percent:
          form.price_original > 0 && form.price < form.price_original
            ? Math.round(((form.price_original - form.price) / form.price_original) * 100 * 100) / 100
            : 0,
        stock: Number(form.stock),
        low_stock_threshold: Number(form.low_stock_threshold),
        is_available: form.is_available,
        is_new: form.is_new,
        is_featured: form.is_featured,
        is_on_sale: form.is_on_sale,
        is_best_seller: form.is_best_seller,
        meta_title: form.meta_title || null,
        meta_description: form.meta_description || null,
      }
      await upsertProductFn({ data: payload as any })
      toast.success(initial ? 'تم تحديث المنتج' : 'تم إضافة المنتج')
      onSaved()
    } catch (err: any) {
      toast.error(err?.message ?? 'فشل الحفظ')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/50 overflow-y-auto">
      <div className="min-h-full flex items-center justify-center p-4">
        <form
          onSubmit={onSubmit}
          className="w-full max-w-4xl bg-card rounded-2xl shadow-2xl max-h-[90vh] overflow-y-auto"
        >
          <div className="sticky top-0 bg-card border-b border-border p-4 flex items-center justify-between">
            <h2 className="font-bold text-lg">{initial ? 'تعديل منتج' : 'منتج جديد'}</h2>
            <button type="button" onClick={onClose} aria-label="إغلاق" className="p-2 hover:bg-muted rounded">
              <X className="size-5" />
            </button>
          </div>

          <div className="p-5 space-y-5">
            <div className="grid sm:grid-cols-2 gap-4">
              <Field label="اسم المنتج *" required>
                <input
                  type="text"
                  required
                  value={form.name}
                  onChange={(e) => updateField('name', e.target.value)}
                  className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm"
                />
              </Field>
              <Field label="Slug (رابط المنتج) *" required>
                <input
                  type="text"
                  required
                  value={form.slug}
                  onChange={(e) => updateField('slug', e.target.value)}
                  className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm text-left dir-ltr"
                />
              </Field>
              <Field label="SKU">
                <input
                  type="text"
                  value={form.sku}
                  onChange={(e) => updateField('sku', e.target.value)}
                  className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm"
                />
              </Field>
              <Field label="Barcode">
                <input
                  type="text"
                  value={form.barcode}
                  onChange={(e) => updateField('barcode', e.target.value)}
                  className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm"
                />
              </Field>
              <Field label="الماركة">
                <select
                  value={form.brand_id}
                  onChange={(e) => updateField('brand_id', e.target.value)}
                  className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm"
                >
                  <option value="">— بدون ماركة —</option>
                  {brands.map((b) => (
                    <option key={b.id} value={b.id}>{b.name}</option>
                  ))}
                </select>
              </Field>
              <Field label="التصنيف">
                <select
                  value={form.category_id}
                  onChange={(e) => updateField('category_id', e.target.value)}
                  className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm"
                >
                  <option value="">— بدون تصنيف —</option>
                  {categories.map((c) => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </select>
              </Field>
              <Field label="الموديل">
                <input
                  type="text"
                  value={form.model}
                  onChange={(e) => updateField('model', e.target.value)}
                  className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm"
                />
              </Field>
              <Field label="Tags (مفصولة بفاصلة)">
                <input
                  type="text"
                  value={form.tags}
                  onChange={(e) => updateField('tags', e.target.value)}
                  placeholder="لاب توب, HP, قوي"
                  className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm"
                />
              </Field>
            </div>

            <Field label="وصف مختصر">
              <textarea
                rows={2}
                value={form.short_description}
                onChange={(e) => updateField('short_description', e.target.value)}
                className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm"
              />
            </Field>
            <Field label="الوصف الكامل">
              <textarea
                rows={4}
                value={form.description}
                onChange={(e) => updateField('description', e.target.value)}
                className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm"
              />
            </Field>
            <Field label="المواصفات الفنية (JSON)">
              <textarea
                rows={5}
                value={form.specs}
                onChange={(e) => updateField('specs', e.target.value)}
                placeholder={'{"المعالج": "i5", "الرام": "8GB"}'}
                className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm font-mono text-left dir-ltr"
              />
            </Field>

            <div className="grid sm:grid-cols-4 gap-4">
              <Field label="السعر الأصلي">
                <input
                  type="number"
                  step="0.01"
                  min={0}
                  value={form.price_original}
                  onChange={(e) => updateField('price_original', Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm"
                />
              </Field>
              <Field label="السعر الحالي">
                <input
                  type="number"
                  step="0.01"
                  min={0}
                  value={form.price}
                  onChange={(e) => updateField('price', Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm"
                />
              </Field>
              <Field label="الكمية">
                <input
                  type="number"
                  min={0}
                  value={form.stock}
                  onChange={(e) => updateField('stock', Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm"
                />
              </Field>
              <Field label="حد التنبيه">
                <input
                  type="number"
                  min={0}
                  value={form.low_stock_threshold}
                  onChange={(e) => updateField('low_stock_threshold', Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm"
                />
              </Field>
            </div>

            <div className="flex flex-wrap gap-4 text-sm">
              <CheckField label="متاح" checked={form.is_available} onChange={(v) => updateField('is_available', v)} />
              <CheckField label="منتج جديد" checked={form.is_new} onChange={(v) => updateField('is_new', v)} />
              <CheckField label="منتج مميز" checked={form.is_featured} onChange={(v) => updateField('is_featured', v)} />
              <CheckField label="عرض خاص" checked={form.is_on_sale} onChange={(v) => updateField('is_on_sale', v)} />
              <CheckField label="الأكثر مبيعًا" checked={form.is_best_seller} onChange={(v) => updateField('is_best_seller', v)} />
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              <Field label="Meta Title (SEO)">
                <input
                  type="text"
                  value={form.meta_title}
                  onChange={(e) => updateField('meta_title', e.target.value)}
                  className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm"
                />
              </Field>
              <Field label="Meta Description (SEO)">
                <input
                  type="text"
                  value={form.meta_description}
                  onChange={(e) => updateField('meta_description', e.target.value)}
                  className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm"
                />
              </Field>
            </div>

            {/* Images section for existing products */}
            {initial && (
              <div>
                <label className="block text-sm font-medium mb-2">صور المنتج</label>
                {images.length === 0 ? (
                  <p className="text-xs text-muted-foreground mb-2">لا توجد صور بعد — ارفع أول صورة الآن.</p>
                ) : (
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-3">
                    {images.map((img: any) => (
                      <div key={img.id ?? img.url} className="relative group">
                        <img src={img.url} alt="" className="aspect-square w-full object-cover rounded-md border" />
                        {img.is_main && (
                          <span className="absolute top-1 right-1 text-[10px] bg-[var(--ht-blue)] text-white px-1.5 py-0.5 rounded">
                            رئيسية
                          </span>
                        )}
                        <div className="absolute top-1 left-1 flex gap-1">
                          {!img.is_main && (
                            <button
                              type="button"
                              title="تعيين كصورة رئيسية"
                              onClick={() => onSetMainImage(img)}
                              className="p-1 rounded bg-white/90 text-[var(--ht-blue)] shadow"
                            >
                              <Star className="size-3.5" />
                            </button>
                          )}
                          <button
                            type="button"
                            title="حذف الصورة"
                            onClick={() => onDeleteImage(img)}
                            className="p-1 rounded bg-white/90 text-red-600 shadow"
                          >
                            <Trash2 className="size-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                <input
                  ref={fileInput}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => {
                    const f = e.target.files?.[0]
                    if (f) onUploadFile(f)
                    e.target.value = ''
                  }}
                />
                <Button
                  type="button"
                  variant="outline"
                  disabled={uploading}
                  onClick={() => fileInput.current?.click()}
                >
                  {uploading ? (
                    <>
                      <Loader2 className="size-4 ml-2 animate-spin" /> جاري رفع الصورة...
                    </>
                  ) : (
                    <>
                      <Upload className="size-4 ml-2" /> رفع صورة من الجهاز
                    </>
                  )}
                </Button>

                <div className="flex gap-2 mt-3">
                  <input
                    type="url"
                    value={newImageUrl}
                    onChange={(e) => setNewImageUrl(e.target.value)}
                    placeholder="أو أضف رابط صورة مباشر https://..."
                    className="flex-1 px-3 py-2 rounded-md border border-border bg-background text-sm"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    disabled={!newImageUrl.trim()}
                    onClick={() => onAddImageUrl(newImageUrl)}
                  >
                    إضافة بالرابط
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground mt-2">
                  يتم ضغط الصور تلقائيًا عند الرفع لتحسين سرعة الموقع. الصورة الأولى تُعتبر الصورة الرئيسية للمنتج.
                </p>
              </div>
            )}
          </div>

          <div className="sticky bottom-0 bg-card border-t border-border p-4 flex items-center justify-end gap-2">
            <Button type="button" variant="outline" onClick={onClose}>
              إلغاء
            </Button>
            <Button type="submit" disabled={submitting} className="bg-[var(--ht-blue)] hover:bg-[var(--ht-blue-dark)]">
              {submitting ? 'جاري الحفظ...' : initial ? 'حفظ التغييرات' : 'إضافة المنتج'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  )
}

function Field({ label, children, required }: { label: string; children: React.ReactNode; required?: boolean }) {
  return (
    <div>
      <label className="block text-sm font-medium mb-1.5">
        {label} {required && <span className="text-red-600">*</span>}
      </label>
      {children}
    </div>
  )
}

function CheckField({ label, checked, onChange }: { label: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <label className="flex items-center gap-2 cursor-pointer">
      <input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} />
      <span>{label}</span>
    </label>
  )
}