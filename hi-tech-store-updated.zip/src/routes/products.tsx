// All Products page with filters and sorting
import { createFileRoute, Link, useNavigate } from '@tanstack/react-router'
import { useState } from 'react'
import { Filter, X } from 'lucide-react'
import {
  getCategories,
  getProducts,
  getSettings,
  getVisibleBrands,
} from '../lib/store-api'
import { StoreLayout } from '../components/store-layout'
import { ProductCard } from '../components/product-card'
import { Button } from '../components/ui/button'
import type { Brand, Category, Product, Settings } from '../lib/types'

type Search = {
  category?: string
  brand?: string
  min_price?: number
  max_price?: number
  sort: 'newest' | 'price_asc' | 'price_desc' | 'best_selling'
  in_stock?: boolean
  page?: number
}

type LoaderData = {
  settings: Settings
  categories: Category[]
  brands: Brand[]
  initialProducts: Product[]
}

export const Route = createFileRoute('/products')({
  validateSearch: (search: Record<string, unknown>): Search => ({
    category: typeof search.category === 'string' ? search.category : undefined,
    brand: typeof search.brand === 'string' ? search.brand : undefined,
    min_price: typeof search.min_price === 'string' ? Number(search.min_price) : undefined,
    max_price: typeof search.max_price === 'string' ? Number(search.max_price) : undefined,
    sort:
      typeof search.sort === 'string'
        ? (search.sort as Search['sort'])
        : 'newest',
    in_stock: search.in_stock === '1' || search.in_stock === true,
    page: typeof search.page === 'string' ? Number(search.page) : 1,
  }),
  loaderDeps: ({ search }) => search,
  loader: async ({ deps }): Promise<LoaderData> => {
    const [settings, categories, brands, productsRes] = await Promise.all([
      getSettings(),
      getCategories(),
      getVisibleBrands(),
      getProducts({
        data: {
        category_id: deps.category,
        brand_id: deps.brand,
        min_price: deps.min_price,
        max_price: deps.max_price,
        in_stock_only: deps.in_stock,
        sort: deps.sort,
        page: deps.page,
        page_size: 24,
        },
      }),
    ])
    return { settings, categories, brands, initialProducts: productsRes.items }
  },
  component: ProductsPage,
  head: () => ({ meta: [{ title: 'كل المنتجات | Hi-Tech' }] }),
})

function ProductsPage() {
  const { settings, categories, brands, initialProducts } = Route.useLoaderData()
  const search = Route.useSearch() as Search
  const navigate = useNavigate({ from: Route.fullPath })
  const [showFilters, setShowFilters] = useState(false)

  const updateSearch = (patch: Partial<Search>) => {
    navigate({ search: { ...search, ...patch, page: 1 } as any })
  }

  return (
    <StoreLayout settings={settings} categories={categories}>
      <div className="mx-auto max-w-7xl px-4 py-6">
        <div className="flex items-center justify-between mb-4 gap-2 flex-wrap">
          <div>
            <h1 className="text-2xl font-bold">كل المنتجات</h1>
            <p className="text-sm text-muted-foreground">{initialProducts.length} منتج</p>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" className="lg:hidden" onClick={() => setShowFilters(true)}>
              <Filter className="size-4 ml-1" /> فلاتر
            </Button>
            <select
              value={search.sort}
              onChange={(e) => updateSearch({ sort: e.target.value as Search['sort'] })}
              className="px-3 py-1.5 rounded-md border border-border bg-card text-sm"
            >
              <option value="newest">الأحدث</option>
              <option value="price_asc">السعر: الأقل أولاً</option>
              <option value="price_desc">السعر: الأعلى أولاً</option>
              <option value="best_selling">الأكثر مبيعًا</option>
            </select>
          </div>
        </div>

        <div className="grid lg:grid-cols-[260px_1fr] gap-6">
          <aside className="hidden lg:block">
            <Filters categories={categories} brands={brands} search={search} updateSearch={updateSearch} />
          </aside>

          {showFilters && (
            <div className="fixed inset-0 z-50 lg:hidden">
              <div className="absolute inset-0 bg-black/50" onClick={() => setShowFilters(false)} />
              <div className="absolute top-0 right-0 h-full w-[88%] max-w-sm bg-card overflow-y-auto p-5 shadow-2xl animate-fade-in">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-bold">الفلاتر</h3>
                  <button onClick={() => setShowFilters(false)} aria-label="إغلاق">
                    <X className="size-5" />
                  </button>
                </div>
                <Filters categories={categories} brands={brands} search={search} updateSearch={updateSearch} />
              </div>
            </div>
          )}

          <div>
            {initialProducts.length === 0 ? (
              <div className="text-center py-20 text-muted-foreground">
                <p className="text-lg">لا توجد منتجات مطابقة للفلاتر الحالية</p>
                <Button variant="outline" className="mt-4" onClick={() => navigate({ search: { sort: 'newest' } })}>
                  إعادة تعيين الفلاتر
                </Button>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
                {initialProducts.map((p) => (
                  <ProductCard key={p.id} product={p} />
                ))}
              </div>
            )}
            <Pagination current={search.page ?? 1} search={search} navigate={navigate} />
          </div>
        </div>
      </div>
    </StoreLayout>
  )
}

function Filters({
  categories,
  brands,
  search,
  updateSearch,
}: {
  categories: Category[]
  brands: Brand[]
  search: Search
  updateSearch: (patch: Partial<Search>) => void
}) {
  return (
    <div className="space-y-5">
      <div>
        <h4 className="font-semibold mb-2">التصنيف</h4>
        <div className="space-y-1.5 text-sm max-h-64 overflow-y-auto">
          <label className="flex items-center gap-2">
            <input type="radio" name="cat" checked={!search.category} onChange={() => updateSearch({ category: undefined })} />
            <span>كل التصنيفات</span>
          </label>
          {categories.map((c) => (
            <label key={c.id} className="flex items-center gap-2">
              <input
                type="radio"
                name="cat"
                checked={search.category === c.id}
                onChange={() => updateSearch({ category: c.id })}
              />
              <span>{c.name}</span>
            </label>
          ))}
        </div>
      </div>

      <div>
        <h4 className="font-semibold mb-2">الماركة</h4>
        <select
          value={search.brand ?? ''}
          onChange={(e) => updateSearch({ brand: e.target.value || undefined })}
          className="w-full px-3 py-2 rounded-md border border-border bg-card text-sm"
        >
          <option value="">كل الماركات</option>
          {brands.map((b) => (
            <option key={b.id} value={b.id}>{b.name}</option>
          ))}
        </select>
      </div>

      <div>
        <h4 className="font-semibold mb-2">السعر (ج.م)</h4>
        <div className="flex gap-2">
          <input
            type="number"
            placeholder="من"
            value={search.min_price ?? ''}
            onChange={(e) => updateSearch({ min_price: e.target.value ? Number(e.target.value) : undefined })}
            className="w-full px-2 py-1.5 rounded-md border border-border bg-card text-sm"
          />
          <input
            type="number"
            placeholder="إلى"
            value={search.max_price ?? ''}
            onChange={(e) => updateSearch({ max_price: e.target.value ? Number(e.target.value) : undefined })}
            className="w-full px-2 py-1.5 rounded-md border border-border bg-card text-sm"
          />
        </div>
      </div>

      <div>
        <label className="flex items-center gap-2 text-sm">
          <input
            type="checkbox"
            checked={!!search.in_stock}
            onChange={(e) => updateSearch({ in_stock: e.target.checked })}
          />
          <span>المتوفر فقط</span>
        </label>
      </div>

      <Button
        variant="outline"
        className="w-full"
        onClick={() =>
          updateSearch({
            category: undefined,
            brand: undefined,
            min_price: undefined,
            max_price: undefined,
            in_stock: undefined,
          })
        }
      >
        إعادة تعيين
      </Button>
    </div>
  )
}

function Pagination({ current, search, navigate }: { current: number; search: Search; navigate: any }) {
  return (
    <div className="mt-8 flex items-center justify-center gap-2">
      <Button
        variant="outline"
        size="sm"
        disabled={current <= 1}
        onClick={() => navigate({ search: { ...search, page: Math.max(1, current - 1) } as any })}
      >
        السابق
      </Button>
      <span className="px-3 text-sm">صفحة {current}</span>
      <Button
        variant="outline"
        size="sm"
        onClick={() => navigate({ search: { ...search, page: current + 1 } as any })}
      >
        التالي
      </Button>
    </div>
  )
}