// Category page: products filtered by category slug with dynamic filters
import { createFileRoute, Link, useNavigate } from '@tanstack/react-router'
import { useState } from 'react'
import { Filter, X } from 'lucide-react'
import {
  getCategoryBySlug,
  getProducts,
  getSettings,
  getVisibleBrands,
  getVisibleCategories,
} from '../lib/store-api'
import { StoreLayout } from '../components/store-layout'
import { ProductCard } from '../components/product-card'
import { Button } from '../components/ui/button'
import type { Brand, Category, Product, Settings } from '../lib/types'

type Search = {
  brand?: string
  min_price?: number
  max_price?: number
  sort: 'newest' | 'price_asc' | 'price_desc' | 'best_selling'
  in_stock?: boolean
  filters?: Record<string, string[]>
  page?: number
}

type LoaderData = {
  settings: Settings
  categories: Category[]
  category: Category
  brands: Brand[]
  products: Product[]
}

export const Route = createFileRoute('/category/$slug')({
  parseParams: (raw) => ({
    slug: typeof raw.slug === 'string' ? raw.slug : '',
  }),
  validateSearch: (search: Record<string, unknown>): Search => {
    const filters: Record<string, string[]> = {}
    for (const k of Object.keys(search)) {
      if (k.startsWith('f_')) {
        const v = (search as any)[k]
        const key = k.slice(2)
        if (typeof v === 'string' && v) filters[key] = v.split(',').filter(Boolean)
      }
    }
    return {
      brand: typeof search.brand === 'string' ? search.brand : undefined,
      min_price: typeof search.min_price === 'string' ? Number(search.min_price) : undefined,
      max_price: typeof search.max_price === 'string' ? Number(search.max_price) : undefined,
      sort:
        typeof search.sort === 'string'
          ? (search.sort as Search['sort'])
          : 'newest',
      in_stock: search.in_stock === '1' || search.in_stock === true,
      filters: Object.keys(filters).length > 0 ? filters : undefined,
      page: typeof search.page === 'string' ? Number(search.page) : 1,
    }
  },
  loaderDeps: ({ search }) => search,
  loader: async ({ params, deps }): Promise<LoaderData> => {
    const [settings, category, allCategories, brands, productsRes] = await Promise.all([
      getSettings(),
      getCategoryBySlug({ data: { slug: params.slug } }),
      getVisibleCategories(),
      getVisibleBrands(),
      getProducts({
        data: {
        category_slug: params.slug,
        brand_id: deps.brand,
        min_price: deps.min_price,
        max_price: deps.max_price,
        in_stock_only: deps.in_stock,
        sort: deps.sort,
        page: deps.page,
        page_size: 24,
        },
      }),
    ])
    if (!category) throw new Error('Category not found')
    // Refine server-side by filters in specs if present
    let items = productsRes.items
    if (deps.filters && Object.keys(deps.filters).length > 0) {
      items = items.filter((p) => {
        return Object.entries(deps.filters!).every(([key, values]) => {
          if (values.length === 0) return true
          if (key === 'brand') return !p.brand_id || values.includes(p.brand_id)
          if (key === 'price') return true
          const specValue = (p.specs as any)?.[key] ?? (p as any)[key]
          if (!specValue) return false
          return values.includes(String(specValue))
        })
      })
    }
    return { settings, categories: allCategories, category, brands, products: items }
  },
  component: CategoryPage,
  notFoundComponent: () => (
    <div className="mx-auto max-w-3xl px-4 py-20 text-center">
      <h1 className="text-2xl font-bold">التصنيف غير موجود</h1>
      <Link to="/" className="text-[var(--ht-blue)] hover:underline mt-3 inline-block">
        العودة للرئيسية
      </Link>
    </div>
  ),
})

function CategoryPage() {
  const { settings, categories, category, brands, products } = Route.useLoaderData() as LoaderData
  const search = Route.useSearch() as Search
  const navigate = useNavigate({ from: Route.fullPath })
  const [showFilters, setShowFilters] = useState(false)

  const updateSearch = (patch: Partial<Search> & Record<string, any>) => {
    navigate({ search: { ...search, ...patch, page: 1 } as any })
  }

  const toggleFilterValue = (key: string, value: string) => {
    const current = search.filters ?? {}
    const list = current[key] ?? []
    const exists = list.includes(value)
    const next = exists ? list.filter((v) => v !== value) : [...list, value]
    const newFilters = { ...current, [key]: next }
    if (next.length === 0) delete newFilters[key]
    updateSearch({ ...search, filters: newFilters } as any)
  }

  return (
    <StoreLayout settings={settings} categories={categories}>
      {/* Category header */}
      <section className="bg-gradient-to-r from-[var(--ht-blue)] to-[var(--ht-blue-dark)] text-white">
        <div className="mx-auto max-w-7xl px-4 py-8">
          <nav className="text-xs opacity-80 mb-2">
            <Link to="/" className="hover:underline">الرئيسية</Link> / <span>{category.name}</span>
          </nav>
          <h1 className="text-2xl sm:text-3xl font-bold">{category.name}</h1>
          {category.description && <p className="text-sm opacity-90 mt-1 max-w-3xl">{category.description}</p>}
        </div>
      </section>

      <div className="mx-auto max-w-7xl px-4 py-6">
        <div className="flex items-center justify-between mb-4 gap-2 flex-wrap">
          <p className="text-sm text-muted-foreground">{products.length} منتج</p>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" className="lg:hidden" onClick={() => setShowFilters(true)}>
              <Filter className="size-4 ml-1" /> فلاتر
            </Button>
            <select
              value={search.sort}
              onChange={(e) => updateSearch({ sort: e.target.value as Search['sort'] })}
              className="px-3 py-1.5 rounded-md border border-border bg-card text-sm"
            >
              <option value="newest">الأحدث</option>
              <option value="price_asc">السعر: الأقل أولاً</option>
              <option value="price_desc">السعر: الأعلى أولاً</option>
              <option value="best_selling">الأكثر مبيعًا</option>
            </select>
          </div>
        </div>

        <div className="grid lg:grid-cols-[280px_1fr] gap-6">
          <aside className="hidden lg:block">
            <Filters
              category={category}
              brands={brands}
              search={search}
              updateSearch={updateSearch}
              toggleFilterValue={toggleFilterValue}
            />
          </aside>

          {showFilters && (
            <div className="fixed inset-0 z-50 lg:hidden">
              <div className="absolute inset-0 bg-black/50" onClick={() => setShowFilters(false)} />
              <div className="absolute top-0 right-0 h-full w-[88%] max-w-sm bg-card overflow-y-auto p-5 shadow-2xl animate-fade-in">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-bold">الفلاتر</h3>
                  <button onClick={() => setShowFilters(false)} aria-label="إغلاق">
                    <X className="size-5" />
                  </button>
                </div>
                <Filters
                  category={category}
                  brands={brands}
                  search={search}
                  updateSearch={updateSearch}
                  toggleFilterValue={toggleFilterValue}
                />
              </div>
            </div>
          )}

          <div>
            {products.length === 0 ? (
              <div className="text-center py-20 text-muted-foreground">
                <p>لا توجد منتجات في هذا التصنيف حاليًا</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
                {products.map((p) => (
                  <ProductCard key={p.id} product={p} />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </StoreLayout>
  )
}

function Filters({
  category,
  brands,
  search,
  updateSearch,
  toggleFilterValue,
}: {
  category: Category
  brands: Brand[]
  search: Search
  updateSearch: (patch: any) => void
  toggleFilterValue: (k: string, v: string) => void
}) {
  const filterSchema = category.filter_schema ?? []
  return (
    <div className="space-y-5">
      <div>
        <h4 className="font-semibold mb-2">الماركة</h4>
        <div className="space-y-1.5 text-sm max-h-64 overflow-y-auto">
          <label className="flex items-center gap-2">
            <input
              type="radio"
              name="brand"
              checked={!search.brand}
              onChange={() => updateSearch({ brand: undefined })}
            />
            <span>كل الماركات</span>
          </label>
          {brands.map((b) => (
            <label key={b.id} className="flex items-center gap-2">
              <input
                type="radio"
                name="brand"
                checked={search.brand === b.id}
                onChange={() => updateSearch({ brand: b.id })}
              />
              <span>{b.name}</span>
            </label>
          ))}
        </div>
      </div>

      {filterSchema.map((group: any) => {
        if (group.key === 'brand') return null
        if (group.type === 'range') {
          return (
            <div key={group.key}>
              <h4 className="font-semibold mb-2">{group.label}</h4>
              <div className="flex gap-2">
                <input
                  type="number"
                  placeholder="من"
                  value={search.min_price ?? ''}
                  onChange={(e) => updateSearch({ min_price: e.target.value ? Number(e.target.value) : undefined })}
                  className="w-full px-2 py-1.5 rounded-md border border-border bg-card text-sm"
                />
                <input
                  type="number"
                  placeholder="إلى"
                  value={search.max_price ?? ''}
                  onChange={(e) => updateSearch({ max_price: e.target.value ? Number(e.target.value) : undefined })}
                  className="w-full px-2 py-1.5 rounded-md border border-border bg-card text-sm"
                />
              </div>
            </div>
          )
        }
        const selected = search.filters?.[group.key] ?? []
        return (
          <div key={group.key}>
            <h4 className="font-semibold mb-2">{group.label}</h4>
            <div className="space-y-1.5 text-sm">
              {(group.options ?? []).map((opt: any) => (
                <label key={opt.value} className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={selected.includes(opt.value)}
                    onChange={() => toggleFilterValue(group.key, opt.value)}
                  />
                  <span>{opt.label}</span>
                </label>
              ))}
            </div>
          </div>
        )
      })}

      <div>
        <label className="flex items-center gap-2 text-sm">
          <input
            type="checkbox"
            checked={!!search.in_stock}
            onChange={(e) => updateSearch({ in_stock: e.target.checked })}
          />
          <span>المتوفر فقط</span>
        </label>
      </div>

      <Button
        variant="outline"
        className="w-full"
        onClick={() => updateSearch({ brand: undefined, in_stock: undefined, min_price: undefined, max_price: undefined, filters: undefined })}
      >
        إعادة تعيين
      </Button>
    </div>
  )
}