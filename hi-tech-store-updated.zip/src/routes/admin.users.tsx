// Admin Users Management
import { createFileRoute } from '@tanstack/react-router'
import { useState } from 'react'
import { Trash2, UserPlus, X } from 'lucide-react'
import { toast } from 'sonner'
import { createAdminUserFn, deleteAdminUserFn, listAdminUsersFn, updateAdminUserFn } from '../lib/admin'
import { Button } from '../components/ui/button'
import { useAuth } from '../lib/auth-context'
import type { AdminUser } from '../lib/types'

type LoaderData = { users: AdminUser[]; currentEmail: string | null }

export const Route = createFileRoute('/admin/users')({
  loader: async (): Promise<LoaderData> => {
    try {
      const users = await listAdminUsersFn()
      return { users, currentEmail: null }
    } catch (e) {
      return { users: [], currentEmail: null }
    }
  },
  component: AdminUsers,
})

function AdminUsers() {
  const { users } = Route.useLoaderData() as LoaderData
  const [creating, setCreating] = useState(false)
  const { session } = useAuth()
  const [list, setList] = useState(users)

  const onDelete = async (id: string) => {
    if (!confirm('حذف هذا المستخدم؟')) return
    try {
      await deleteAdminUserFn({ data: { id } })
      toast.success('تم الحذف')
      setList(list.filter((u) => u.id !== id))
    } catch (e: any) {
      toast.error(e?.message ?? 'فشل')
    }
  }

  const onUpdate = async (u: AdminUser, patch: Partial<AdminUser>) => {
    try {
      await updateAdminUserFn({ data: { id: u.id, ...patch } as any })
      toast.success('تم التحديث')
      setList(list.map((x) => (x.id === u.id ? { ...x, ...patch } : x)))
    } catch (e: any) {
      toast.error(e?.message ?? 'فشل')
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">المستخدمون والصلاحيات</h1>
          <p className="text-sm text-muted-foreground">{list.length} مستخدم</p>
        </div>
        <Button onClick={() => setCreating(true)} className="bg-[var(--ht-blue)] hover:bg-[var(--ht-blue-dark)]">
          <UserPlus className="size-4 ml-1" /> إضافة مستخدم
        </Button>
      </div>

      <div className="rounded-xl border border-border bg-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-right">
              <tr>
                <th className="px-3 py-3 font-medium">الاسم</th>
                <th className="px-3 py-3 font-medium">البريد</th>
                <th className="px-3 py-3 font-medium">الدور</th>
                <th className="px-3 py-3 font-medium">الحالة</th>
                <th className="px-3 py-3 font-medium">إجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {list.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-3 py-10 text-center text-muted-foreground">لا يوجد مستخدمون بعد</td>
                </tr>
              ) : (
                list.map((u) => (
                  <tr key={u.id} className="hover:bg-muted/30">
                    <td className="px-3 py-3">{u.full_name ?? '—'}</td>
                    <td className="px-3 py-3 tabular-nums">{u.email}</td>
                    <td className="px-3 py-3">
                      <select
                        value={u.role}
                        onChange={(e) => onUpdate(u, { role: e.target.value as any })}
                        className="px-2 py-1 rounded border border-border bg-background text-sm"
                      >
                        <option value="admin">مدير عام</option>
                        <option value="manager">مدير</option>
                        <option value="staff">موظف</option>
                      </select>
                    </td>
                    <td className="px-3 py-3">
                      <label className="inline-flex items-center gap-2 cursor-pointer text-sm">
                        <input
                          type="checkbox"
                          checked={u.is_active}
                          onChange={(e) => onUpdate(u, { is_active: e.target.checked })}
                        />
                        نشط
                      </label>
                    </td>
                    <td className="px-3 py-3">
                      <button
                        onClick={() => onDelete(u.id)}
                        disabled={u.email === session?.email}
                        className="p-1.5 rounded hover:bg-red-50 text-red-600 disabled:opacity-40"
                      >
                        <Trash2 className="size-4" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {creating && <CreateUserModal onClose={() => setCreating(false)} onCreated={() => window.location.reload()} />}
    </div>
  )
}

function CreateUserModal({ onClose, onCreated }: { onClose: () => void; onCreated: () => void }) {
  const [form, setForm] = useState({ email: '', full_name: '' })
  const [submitting, setSubmitting] = useState(false)

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!form.email) {
      toast.error('يرجى إدخال البريد الإلكتروني')
      return
    }
    setSubmitting(true)
    try {
      await createAdminUserFn({ data: { email: form.email.trim(), full_name: form.full_name.trim() || undefined } })
      toast.success('تمت إضافة المستخدم. اطلب منه إنشاء كلمة المرور من صفحة الدخول.')
      onCreated()
    } catch (e: any) {
      toast.error(e?.message ?? 'فشل الإضافة')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/50 overflow-y-auto">
      <div className="min-h-full flex items-center justify-center p-4">
        <form onSubmit={onSubmit} className="w-full max-w-md bg-card rounded-2xl shadow-2xl">
          <div className="border-b border-border p-4 flex items-center justify-between">
            <h2 className="font-bold">إضافة مستخدم جديد</h2>
            <button type="button" onClick={onClose} className="p-2 hover:bg-muted rounded"><X className="size-5" /></button>
          </div>
          <div className="p-5 space-y-3">
            <Field label="الاسم">
              <input type="text" value={form.full_name} onChange={(e) => setForm((p) => ({ ...p, full_name: e.target.value }))} className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm" />
            </Field>
            <Field label="البريد الإلكتروني" required>
              <input type="email" required value={form.email} onChange={(e) => setForm((p) => ({ ...p, email: e.target.value }))} className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm" />
            </Field>
            <p className="text-xs text-muted-foreground leading-relaxed">
              بعد إضافة البريد، يفتح صاحب الحساب صفحة تسجيل دخول لوحة التحكم ويضغط
              «أنشئ كلمة المرور الخاصة بك» ليضبط كلمة مروره بنفسه.
            </p>
          </div>
          <div className="border-t border-border p-4 flex items-center justify-end gap-2">
            <Button type="button" variant="outline" onClick={onClose}>إلغاء</Button>
            <Button type="submit" disabled={submitting} className="bg-[var(--ht-blue)] hover:bg-[var(--ht-blue-dark)]">{submitting ? '...' : 'إنشاء'}</Button>
          </div>
        </form>
      </div>
    </div>
  )
}

function Field({ label, children, required }: { label: string; children: React.ReactNode; required?: boolean }) {
  return (
    <div>
      <label className="block text-sm font-medium mb-1.5">{label} {required && <span className="text-red-600">*</span>}</label>
      {children}
    </div>
  )
}