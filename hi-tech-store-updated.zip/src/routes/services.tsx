// Services page
import { createFileRoute, Link } from '@tanstack/react-router'
import {
  Camera,
  Cpu,
  HardDrive,
  Laptop,
  Network,
  Phone,
  Plug,
  Settings,
  Wrench,
  Wifi,
} from 'lucide-react'
import { getActiveServices, getSettings, getVisibleCategories } from '../lib/store-api'
import { StoreLayout } from '../components/store-layout'
import { Button } from '../components/ui/button'
import type { Service } from '../lib/types'
import type { Settings as StoreSettings } from '../lib/types'

type LoaderData = {
  settings: StoreSettings
  categories: Awaited<ReturnType<typeof getVisibleCategories>>
  services: Service[]
}

const ICON_MAP: Record<string, any> = {
  Camera,
  Wrench,
  HardDrive,
  Cpu,
  Laptop,
  Network,
  Wifi,
  Plug,
  Settings,
}

export const Route = createFileRoute('/services')({
  loader: async (): Promise<LoaderData> => {
    const [settings, categories, services] = await Promise.all([
      getSettings(),
      getVisibleCategories(),
      getActiveServices(),
    ])
    return { settings, categories, services }
  },
  component: ServicesPage,
  head: () => ({ meta: [{ title: 'خدماتنا | Hi-Tech' }] }),
})

function ServicesPage() {
  const { settings, categories, services } = Route.useLoaderData() as LoaderData
  return (
    <StoreLayout settings={settings} categories={categories}>
      <section className="bg-gradient-to-r from-[var(--ht-blue)] to-[var(--ht-blue-dark)] text-white">
        <div className="mx-auto max-w-7xl px-4 py-8">
          <Wrench className="size-10 mb-2" />
          <h1 className="text-2xl sm:text-3xl font-bold">خدماتنا الاحترافية</h1>
          <p className="opacity-90 mt-1 text-sm">تركيب، صيانة، شبكات، ودعم فني متخصص</p>
        </div>
      </section>

      <div className="mx-auto max-w-7xl px-4 py-6">
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {services.map((s) => {
            const Icon = ICON_MAP[s.icon ?? 'Wrench'] ?? Wrench
            return (
              <article
                key={s.id}
                className="rounded-xl border border-border bg-card p-5 hover:shadow-lg hover:border-[var(--ht-blue)] transition-all"
              >
                <div className="size-12 rounded-lg bg-[var(--ht-blue-light)] text-[var(--ht-blue)] flex items-center justify-center mb-3">
                  <Icon className="size-6" />
                </div>
                <h3 className="font-bold mb-1">{s.title}</h3>
                {s.description && <p className="text-sm text-muted-foreground leading-6">{s.description}</p>}
              </article>
            )
          })}
        </div>

        <div className="mt-10 rounded-2xl bg-gradient-to-r from-[var(--ht-blue)] to-[var(--ht-blue-dark)] text-white p-6 sm:p-8 grid sm:grid-cols-2 gap-4 items-center">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold">هل تحتاج إلى خدمة أو استشارة؟</h2>
            <p className="opacity-90 mt-2 text-sm">فريقنا جاهز للرد على استفساراتك. اتصل بنا الآن أو راسلنا على واتساب.</p>
          </div>
          <div className="flex flex-wrap gap-2 sm:justify-end">
            <a
              href={`tel:${settings.phone}`}
              className="inline-flex items-center gap-2 px-5 py-3 rounded-md bg-white text-[var(--ht-blue)] font-semibold"
            >
              <Phone className="size-4" /> اتصال
            </a>
            <a
              href={`https://wa.me/${settings.whatsapp.replace(/^0/, '20')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-5 py-3 rounded-md bg-green-500 text-white font-semibold"
            >
              واتساب
            </a>
          </div>
        </div>
      </div>
    </StoreLayout>
  )
}