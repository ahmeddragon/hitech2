// Admin Offers Management
import { createFileRoute } from '@tanstack/react-router'
import { useState } from 'react'
import { Edit, Plus, Trash2, X } from 'lucide-react'
import { toast } from 'sonner'
import { deleteOfferFn, upsertOfferFn } from '../lib/admin'
import { getActiveOffers, getProducts } from '../lib/store-api'
import { Button } from '../components/ui/button'
import type { Product } from '../lib/types'

type LoaderData = {
  offers: Awaited<ReturnType<typeof getActiveOffers>>
  products: Product[]
}

export const Route = createFileRoute('/admin/offers')({
  loader: async (): Promise<LoaderData> => {
    const [offers, prods] = await Promise.all([getActiveOffers(), getProducts({ data: { page_size: 500 } })])
    return { offers, products: prods.items }
  },
  component: AdminOffers,
})

function AdminOffers() {
  const { offers, products } = Route.useLoaderData() as LoaderData
  const [editing, setEditing] = useState<any | null>(null)
  const [creating, setCreating] = useState(false)

  const onDelete = async (o: any) => {
    if (!confirm('حذف هذا العرض؟')) return
    await deleteOfferFn({ data: { id: o.id } })
    toast.success('تم الحذف')
    window.location.reload()
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">العروض</h1>
          <p className="text-sm text-muted-foreground">{offers.length} عرض</p>
        </div>
        <Button onClick={() => setCreating(true)} className="bg-[var(--ht-red)] hover:bg-[var(--ht-red-dark)]">
          <Plus className="size-4 ml-1" /> عرض جديد
        </Button>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {offers.map((o) => (
          <article key={o.id} className="rounded-xl border border-border bg-card overflow-hidden">
            <div className="aspect-[16/9] bg-muted">
              {o.image_url ? <img src={o.image_url} alt="" className="size-full object-cover" /> : <div className="size-full flex items-center justify-center text-muted-foreground">لا توجد صورة</div>}
            </div>
            <div className="p-3">
              <h3 className="font-bold">{o.title}</h3>
              <p className="text-xs text-muted-foreground">{o.product_ids.length} منتج • خصم {Math.round(Number(o.discount_percent))}%</p>
              <div className="flex items-center gap-1 mt-3">
                <Button variant="outline" size="sm" onClick={() => setEditing(o)}><Edit className="size-3.5" /></Button>
                <Button variant="outline" size="sm" onClick={() => onDelete(o)} className="text-red-600"><Trash2 className="size-3.5" /></Button>
              </div>
            </div>
          </article>
        ))}
      </div>

      {(editing || creating) && (
        <OfferModal
          offer={editing}
          products={products}
          onClose={() => {
            setEditing(null)
            setCreating(false)
          }}
          onSaved={() => window.location.reload()}
        />
      )}
    </div>
  )
}

function OfferModal({ offer, products, onClose, onSaved }: { offer: any | null; products: Product[]; onClose: () => void; onSaved: () => void }) {
  const [form, setForm] = useState({
    slug: offer?.slug ?? '',
    title: offer?.title ?? '',
    description: offer?.description ?? '',
    image_url: offer?.image_url ?? '',
    discount_percent: Number(offer?.discount_percent ?? 0),
    is_active: offer?.is_active ?? true,
    sort_order: offer?.sort_order ?? 0,
    product_ids: (offer?.product_ids ?? []) as string[],
  })
  const [submitting, setSubmitting] = useState(false)

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitting(true)
    try {
      await upsertOfferFn({
        data: {
          ...(offer?.id ? { id: offer.id } : {}),
          slug: form.slug || form.title.toLowerCase().replace(/\s+/g, '-'),
          title: form.title,
          description: form.description || null,
          image_url: form.image_url || null,
          discount_percent: form.discount_percent,
          is_active: form.is_active,
          sort_order: form.sort_order,
          product_ids: form.product_ids,
        } as any,
      })
      toast.success(offer ? 'تم التحديث' : 'تم الإضافة')
      onSaved()
    } catch (e: any) {
      toast.error(e?.message ?? 'فشل')
    } finally {
      setSubmitting(false)
    }
  }

  const toggleProduct = (id: string) => {
    setForm((p) => ({
      ...p,
      product_ids: p.product_ids.includes(id) ? p.product_ids.filter((x) => x !== id) : [...p.product_ids, id],
    }))
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/50 overflow-y-auto">
      <div className="min-h-full flex items-center justify-center p-4">
        <form onSubmit={onSubmit} className="w-full max-w-2xl bg-card rounded-2xl shadow-2xl">
          <div className="border-b border-border p-4 flex items-center justify-between">
            <h2 className="font-bold">{offer ? 'تعديل عرض' : 'عرض جديد'}</h2>
            <button type="button" onClick={onClose} className="p-2 hover:bg-muted rounded">
              <X className="size-5" />
            </button>
          </div>
          <div className="p-5 space-y-4">
            <div className="grid sm:grid-cols-2 gap-3">
              <Field label="العنوان" required>
                <input type="text" required value={form.title} onChange={(e) => setForm((p) => ({ ...p, title: e.target.value }))} className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm" />
              </Field>
              <Field label="نسبة الخصم %">
                <input type="number" min={0} max={100} step={0.01} value={form.discount_percent} onChange={(e) => setForm((p) => ({ ...p, discount_percent: Number(e.target.value) }))} className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm" />
              </Field>
            </div>
            <Field label="الوصف">
              <textarea rows={2} value={form.description} onChange={(e) => setForm((p) => ({ ...p, description: e.target.value }))} className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm" />
            </Field>
            <Field label="رابط الصورة">
              <input type="url" value={form.image_url} onChange={(e) => setForm((p) => ({ ...p, image_url: e.target.value }))} placeholder="https://..." className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm" />
            </Field>
            <Field label="المنتجات في العرض">
              <div className="max-h-48 overflow-y-auto border border-border rounded-md p-2 space-y-1">
                {products.map((p) => (
                  <label key={p.id} className="flex items-center gap-2 text-sm cursor-pointer">
                    <input type="checkbox" checked={form.product_ids.includes(p.id)} onChange={() => toggleProduct(p.id)} />
                    <span className="line-clamp-1 flex-1">{p.name}</span>
                  </label>
                ))}
              </div>
              <p className="text-xs text-muted-foreground mt-1">محدد: {form.product_ids.length}</p>
            </Field>
            <div className="flex items-center gap-2">
              <label className="flex items-center gap-2 text-sm cursor-pointer">
                <input type="checkbox" checked={form.is_active} onChange={(e) => setForm((p) => ({ ...p, is_active: e.target.checked }))} />
                نشط
              </label>
            </div>
          </div>
          <div className="border-t border-border p-4 flex items-center justify-end gap-2">
            <Button type="button" variant="outline" onClick={onClose}>إلغاء</Button>
            <Button type="submit" disabled={submitting} className="bg-[var(--ht-blue)] hover:bg-[var(--ht-blue-dark)]">{submitting ? '...' : 'حفظ'}</Button>
          </div>
        </form>
      </div>
    </div>
  )
}

function Field({ label, children, required }: { label: string; children: React.ReactNode; required?: boolean }) {
  return (
    <div>
      <label className="block text-sm font-medium mb-1.5">
        {label} {required && <span className="text-red-600">*</span>}
      </label>
      {children}
    </div>
  )
}