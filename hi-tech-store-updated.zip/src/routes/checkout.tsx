// Checkout page — sends WhatsApp message with full order details
import { createFileRoute, Link, useNavigate } from '@tanstack/react-router'
import { useState } from 'react'
import { Loader2, Send, ShoppingBag } from 'lucide-react'
import { toast } from 'sonner'
import { getActivePaymentMethods, getSettings, getVisibleCategories } from '../lib/store-api'
import { submitOrderFn } from '../lib/orders'
import { buildWhatsAppLink, buildWhatsAppMessage } from '../lib/whatsapp'
import { StoreLayout } from '../components/store-layout'
import { useCart } from '../components/cart-context'
import { Button } from '../components/ui/button'
import type { PaymentMethod, Settings } from '../lib/types'
import { WhatsappIcon } from '../components/header'

type LoaderData = {
  settings: Settings
  categories: Awaited<ReturnType<typeof getVisibleCategories>>
  paymentMethods: PaymentMethod[]
}

export const Route = createFileRoute('/checkout')({
  loader: async (): Promise<LoaderData> => {
    const [settings, categories, paymentMethods] = await Promise.all([
      getSettings(),
      getVisibleCategories(),
      getActivePaymentMethods(),
    ])
    return { settings, categories, paymentMethods }
  },
  component: CheckoutPage,
  head: () => ({ meta: [{ title: 'إتمام الطلب | Hi-Tech' }] }),
})

function CheckoutPage() {
  const { settings, categories, paymentMethods } = Route.useLoaderData() as LoaderData
  const { items, subtotal, discount, total, clear } = useCart()
  const navigate = useNavigate()
  const [submitting, setSubmitting] = useState(false)
  const [form, setForm] = useState({
    name: '',
    phone: '',
    address: '',
    notes: '',
    paymentMethod: paymentMethods[0]?.name ?? 'كاش',
  })

  if (items.length === 0) {
    return (
      <StoreLayout settings={settings} categories={categories}>
        <div className="mx-auto max-w-3xl px-4 py-20 text-center">
          <ShoppingBag className="size-12 mx-auto text-muted-foreground" />
          <h1 className="text-2xl font-bold mt-3">السلة فارغة</h1>
          <p className="text-muted-foreground mt-2">أضف منتجات إلى السلة قبل إتمام الطلب.</p>
          <Link to="/products" className="mt-4 inline-block text-[var(--ht-blue)] hover:underline">
            تصفح المنتجات
          </Link>
        </div>
      </StoreLayout>
    )
  }

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!form.name.trim() || !form.phone.trim()) {
      toast.error('يرجى إدخال الاسم ورقم الهاتف')
      return
    }
    setSubmitting(true)
    try {
      const order = await submitOrderFn({
        data: {
          customer: {
            name: form.name.trim(),
            phone: form.phone.trim(),
            address: form.address.trim() || undefined,
            notes: form.notes.trim() || undefined,
          },
          items: items.map((i) => ({
            product_id: i.product_id,
            product_name: i.name,
            product_sku: null,
            unit_price: i.unit_price,
            quantity: i.quantity,
          })),
          payment_method: form.paymentMethod,
        },
      })

      // Use the prices confirmed by the server, not the ones held in the browser.
      const confirmedCart = order.lines.map((l) => {
        const original = items.find((i) => i.product_id === l.product_id)
        return {
          product_id: l.product_id,
          slug: original?.slug ?? '',
          name: l.name,
          unit_price: l.unit_price,
          quantity: l.quantity,
          max_stock: original?.max_stock ?? l.quantity,
        }
      })
      const message = buildWhatsAppMessage({
        settings,
        cart: confirmedCart,
        totals: { subtotal: order.total, discount: 0, total: order.total },
        customer: {
          name: form.name,
          phone: form.phone,
          address: form.address,
          notes: form.notes,
        },
        paymentMethod: form.paymentMethod,
      })
      const link = buildWhatsAppLink(settings.whatsapp, message)
      clear()
      toast.success('تم تسجيل طلبك بنجاح')
      // Open WhatsApp in a new tab
      window.open(link, '_blank')
      navigate({ to: '/' })
    } catch (err: any) {
      toast.error(err?.message ?? 'حدث خطأ، حاول مرة أخرى')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <StoreLayout settings={settings} categories={categories}>
      <div className="mx-auto max-w-5xl px-4 py-6">
        <h1 className="text-2xl font-bold mb-4">إتمام الطلب</h1>
        <form onSubmit={onSubmit} className="grid lg:grid-cols-[1fr_360px] gap-6">
          <div className="space-y-4">
            <section className="rounded-xl border border-border bg-card p-5">
              <h3 className="font-bold mb-3">بيانات العميل</h3>
              <div className="space-y-3">
                <Field label="الاسم الكامل *">
                  <input
                    type="text"
                    required
                    value={form.name}
                    onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
                    className="w-full px-3 py-2.5 rounded-md border border-border bg-background text-sm"
                    placeholder="مثال: أحمد محمد"
                  />
                </Field>
                <Field label="رقم الهاتف *">
                  <input
                    type="tel"
                    required
                    inputMode="numeric"
                    value={form.phone}
                    onChange={(e) => setForm((f) => ({ ...f, phone: e.target.value }))}
                    className="w-full px-3 py-2.5 rounded-md border border-border bg-background text-sm tabular-nums"
                    placeholder="01xxxxxxxxx"
                  />
                </Field>
                <Field label="العنوان">
                  <textarea
                    rows={2}
                    value={form.address}
                    onChange={(e) => setForm((f) => ({ ...f, address: e.target.value }))}
                    className="w-full px-3 py-2.5 rounded-md border border-border bg-background text-sm"
                    placeholder="العنوان بالتفصيل (المحافظة - المنطقة - الشارع)"
                  />
                </Field>
                <Field label="ملاحظات">
                  <textarea
                    rows={2}
                    value={form.notes}
                    onChange={(e) => setForm((f) => ({ ...f, notes: e.target.value }))}
                    className="w-full px-3 py-2.5 rounded-md border border-border bg-background text-sm"
                    placeholder="أي تفاصيل تريد إضافتها للطلب"
                  />
                </Field>
              </div>
            </section>

            <section className="rounded-xl border border-border bg-card p-5">
              <h3 className="font-bold mb-3">طريقة الدفع المفضلة</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {paymentMethods.map((pm) => (
                  <label
                    key={pm.id}
                    className={`flex items-start gap-3 p-3 rounded-md border cursor-pointer transition-colors ${
                      form.paymentMethod === pm.name ? 'border-[var(--ht-blue)] bg-[var(--ht-blue-light)]' : 'border-border hover:bg-muted'
                    }`}
                  >
                    <input
                      type="radio"
                      name="payment"
                      checked={form.paymentMethod === pm.name}
                      onChange={() => setForm((f) => ({ ...f, paymentMethod: pm.name }))}
                      className="mt-0.5"
                    />
                    <div>
                      <p className="font-semibold text-sm">{pm.icon} {pm.name}</p>
                      {pm.instructions && (
                        <p className="text-xs text-muted-foreground mt-1 leading-5">{pm.instructions}</p>
                      )}
                      {pm.account_number && (
                        <p className="text-xs font-mono mt-1">{pm.account_number}</p>
                      )}
                    </div>
                  </label>
                ))}
              </div>
            </section>
          </div>

          <aside className="space-y-3">
            <div className="rounded-xl border border-border bg-card p-5 sticky top-32">
              <h3 className="font-bold mb-3">ملخص الطلب</h3>
              <div className="space-y-2 text-sm mb-3 max-h-72 overflow-y-auto">
                {items.map((it) => (
                  <div key={it.product_id} className="flex justify-between gap-2">
                    <span className="line-clamp-2 flex-1">
                      {it.name} × {it.quantity}
                    </span>
                    <span className="tabular-nums shrink-0">
                      {(it.unit_price * it.quantity).toLocaleString('ar-EG')} ج.م
                    </span>
                  </div>
                ))}
              </div>
              <div className="space-y-2 text-sm border-t border-border pt-3">
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">المجموع الفرعي</span>
                  <span className="tabular-nums">{(subtotal + discount).toLocaleString('ar-EG')} ج.م</span>
                </div>
                {discount > 0 && (
                  <div className="flex items-center justify-between text-green-600">
                    <span>الخصم</span>
                    <span className="tabular-nums">- {discount.toLocaleString('ar-EG')} ج.م</span>
                  </div>
                )}
                <div className="flex items-center justify-between text-lg font-bold pt-2 border-t border-border">
                  <span>الإجمالي</span>
                  <span className="tabular-nums text-[var(--ht-blue)]">
                    {total.toLocaleString('ar-EG')} ج.م
                  </span>
                </div>
              </div>

              <Button
                type="submit"
                size="lg"
                disabled={submitting}
                className="w-full mt-4 bg-[var(--ht-red)] hover:bg-[var(--ht-red-dark)]"
              >
                {submitting ? (
                  <>
                    <Loader2 className="size-4 ml-2 animate-spin" /> جاري الإرسال...
                  </>
                ) : (
                  <>
                    <Send className="size-4 ml-2" /> إرسال الطلب عبر واتساب
                  </>
                )}
              </Button>
              <p className="text-[11px] text-muted-foreground mt-2 leading-5">
                سيتم فتح واتساب لإرسال تفاصيل الطلب، وسيتواصل معك المحل لتأكيد التوصيل والدفع.
              </p>
            </div>
          </aside>
        </form>
      </div>
    </StoreLayout>
  )
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="block text-sm font-medium mb-1.5">{label}</label>
      {children}
    </div>
  )
}