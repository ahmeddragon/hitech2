// Admin Orders Management
import { createFileRoute } from '@tanstack/react-router'
import { useMemo, useState } from 'react'
import { Eye, Search, Trash2, X } from 'lucide-react'
import { toast } from 'sonner'
import { deleteOrderFn, updateOrderStatusFn } from '../lib/admin'
import { getOrders } from '../lib/store-api'
import { Button } from '../components/ui/button'
import type { Order, OrderStatus } from '../lib/types'
import { ORDER_STATUSES } from '../lib/types'
import { cn } from '../lib/utils'

type LoaderData = { orders: Order[] }

export const Route = createFileRoute('/admin/orders')({
  loader: async (): Promise<LoaderData> => ({ orders: await getOrders({ data: {} }) }),
  component: AdminOrders,
})

function AdminOrders() {
  const { orders } = Route.useLoaderData() as LoaderData
  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState('')
  const [viewing, setViewing] = useState<Order | null>(null)

  const filtered = useMemo(() => {
    return orders.filter((o) => {
      if (statusFilter && o.status !== statusFilter) return false
      if (!search.trim()) return true
      const s = search.toLowerCase()
      return [o.order_number, o.customer_name, o.customer_phone]
        .filter(Boolean)
        .some((v) => String(v).toLowerCase().includes(s))
    })
  }, [orders, search, statusFilter])

  const onUpdateStatus = async (id: string, status: OrderStatus) => {
    await updateOrderStatusFn({ data: { id, status } })
    toast.success('تم تحديث حالة الطلب')
    window.location.reload()
  }

  const onDelete = async (id: string) => {
    if (!confirm('حذف هذا الطلب؟')) return
    await deleteOrderFn({ data: { id } })
    toast.success('تم الحذف')
    window.location.reload()
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold">الطلبات</h1>
          <p className="text-sm text-muted-foreground">{filtered.length} طلب</p>
        </div>
      </div>

      <div className="flex gap-2 flex-wrap">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
          <input
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="بحث برقم الطلب، الاسم، الهاتف..."
            className="w-full pr-10 pl-3 py-2 rounded-md border border-border bg-card text-sm"
          />
        </div>
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="px-3 py-2 rounded-md border border-border bg-card text-sm"
        >
          <option value="">كل الحالات</option>
          {ORDER_STATUSES.map((s) => (
            <option key={s.value} value={s.value}>{s.label}</option>
          ))}
        </select>
      </div>

      <div className="rounded-xl border border-border bg-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-right">
              <tr>
                <th className="px-3 py-3 font-medium">رقم الطلب</th>
                <th className="px-3 py-3 font-medium">العميل</th>
                <th className="px-3 py-3 font-medium">الهاتف</th>
                <th className="px-3 py-3 font-medium">الإجمالي</th>
                <th className="px-3 py-3 font-medium">الدفع</th>
                <th className="px-3 py-3 font-medium">الحالة</th>
                <th className="px-3 py-3 font-medium">التاريخ</th>
                <th className="px-3 py-3 font-medium">إجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={8} className="px-3 py-10 text-center text-muted-foreground">لا توجد طلبات</td>
                </tr>
              ) : (
                filtered.map((o) => {
                  const status = ORDER_STATUSES.find((s) => s.value === o.status)
                  return (
                    <tr key={o.id} className="hover:bg-muted/30">
                      <td className="px-3 py-3 font-mono text-xs">{o.order_number}</td>
                      <td className="px-3 py-3">{o.customer_name}</td>
                      <td className="px-3 py-3 tabular-nums">{o.customer_phone}</td>
                      <td className="px-3 py-3 font-bold tabular-nums">{Number(o.total).toLocaleString('ar-EG')} ج.م</td>
                      <td className="px-3 py-3 text-xs">{o.payment_method}</td>
                      <td className="px-3 py-3">
                        <select
                          value={o.status}
                          onChange={(e) => onUpdateStatus(o.id, e.target.value as OrderStatus)}
                          className={cn('text-xs px-2 py-1 rounded border-0', status?.color)}
                        >
                          {ORDER_STATUSES.map((s) => (
                            <option key={s.value} value={s.value}>{s.label}</option>
                          ))}
                        </select>
                      </td>
                      <td className="px-3 py-3 text-xs text-muted-foreground">
                        {o.created_at ? new Date(o.created_at).toLocaleDateString('ar-EG') : '—'}
                      </td>
                      <td className="px-3 py-3">
                        <div className="flex items-center gap-1">
                          <button onClick={() => setViewing(o)} className="p-1.5 rounded hover:bg-muted text-[var(--ht-blue)]">
                            <Eye className="size-4" />
                          </button>
                          <button onClick={() => onDelete(o.id)} className="p-1.5 rounded hover:bg-red-50 text-red-600">
                            <Trash2 className="size-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  )
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {viewing && <OrderDetailsModal order={viewing} onClose={() => setViewing(null)} />}
    </div>
  )
}

function OrderDetailsModal({ order, onClose }: { order: Order; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 bg-black/50 overflow-y-auto">
      <div className="min-h-full flex items-center justify-center p-4">
        <div className="w-full max-w-2xl bg-card rounded-2xl shadow-2xl">
          <div className="border-b border-border p-4 flex items-center justify-between">
            <div>
              <h2 className="font-bold text-lg">تفاصيل الطلب</h2>
              <p className="text-xs text-muted-foreground font-mono">{order.order_number}</p>
            </div>
            <button onClick={onClose} className="p-2 hover:bg-muted rounded">
              <X className="size-5" />
            </button>
          </div>
          <div className="p-5 space-y-4">
            <div className="grid sm:grid-cols-2 gap-4 text-sm">
              <Field label="اسم العميل">{order.customer_name}</Field>
              <Field label="الهاتف">{order.customer_phone}</Field>
              <Field label="العنوان" full>{order.customer_address ?? '—'}</Field>
              <Field label="طريقة الدفع">{order.payment_method}</Field>
              <Field label="ملاحظات" full>{order.notes ?? '—'}</Field>
            </div>

            <div>
              <h3 className="font-bold mb-2">المنتجات</h3>
              <div className="rounded-md border border-border overflow-hidden">
                <table className="w-full text-sm">
                  <thead className="bg-muted/40">
                    <tr>
                      <th className="px-3 py-2 text-right font-medium">المنتج</th>
                      <th className="px-3 py-2 text-right font-medium">الكمية</th>
                      <th className="px-3 py-2 text-right font-medium">السعر</th>
                      <th className="px-3 py-2 text-right font-medium">الإجمالي</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    {(order.items ?? []).map((it) => (
                      <tr key={it.id}>
                        <td className="px-3 py-2">{it.product_name}</td>
                        <td className="px-3 py-2 tabular-nums">{it.quantity}</td>
                        <td className="px-3 py-2 tabular-nums">{Number(it.unit_price).toLocaleString('ar-EG')} ج.م</td>
                        <td className="px-3 py-2 tabular-nums font-bold">{Number(it.line_total).toLocaleString('ar-EG')} ج.م</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="mt-3 text-right space-y-1 text-sm">
                <p>المجموع: <span className="tabular-nums font-bold">{Number(order.subtotal).toLocaleString('ar-EG')} ج.م</span></p>
                <p className="text-lg font-bold text-[var(--ht-blue)]">
                  الإجمالي: <span className="tabular-nums">{Number(order.total).toLocaleString('ar-EG')} ج.م</span>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

function Field({ label, children, full }: { label: string; children: React.ReactNode; full?: boolean }) {
  return (
    <div className={full ? 'sm:col-span-2' : ''}>
      <p className="text-xs text-muted-foreground mb-1">{label}</p>
      <p>{children}</p>
    </div>
  )
}