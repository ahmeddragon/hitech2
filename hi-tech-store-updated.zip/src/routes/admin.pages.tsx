// Admin Pages Management (About, etc.)
import { createFileRoute } from '@tanstack/react-router'
import { useEffect, useState } from 'react'
import { Edit, Save, X } from 'lucide-react'
import { toast } from 'sonner'
import { upsertPageFn } from '../lib/admin'
import { getPage } from '../lib/store-api'
import { Button } from '../components/ui/button'
import type { Page } from '../lib/types'

type LoaderData = { about: Page | null; contact: Page | null }

export const Route = createFileRoute('/admin/pages')({
  loader: async (): Promise<LoaderData> => ({
    about: await getPage({ data: { slug: 'about' } }),
    contact: await getPage({ data: { slug: 'contact' } }),
  }),
  component: AdminPages,
})

function AdminPages() {
  const { about, contact } = Route.useLoaderData() as LoaderData
  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold">الصفحات</h1>
        <p className="text-sm text-muted-foreground">إدارة محتوى الصفحات</p>
      </div>
      <PageEditor slug="about" initial={about} title="صفحة من نحن" />
      <PageEditor slug="contact" initial={contact} title="صفحة اتصل بنا" />
    </div>
  )
}

function PageEditor({ slug, initial, title }: { slug: string; initial: Page | null; title: string }) {
  const [content, setContent] = useState(initial?.content ?? '')
  const [metaTitle, setMetaTitle] = useState(initial?.meta_title ?? '')
  const [metaDescription, setMetaDescription] = useState(initial?.meta_description ?? '')
  const [isActive, setIsActive] = useState(initial?.is_active ?? true)
  const [submitting, setSubmitting] = useState(false)

  const onSave = async () => {
    setSubmitting(true)
    try {
      await upsertPageFn({
        data: {
          ...(initial?.id ? { id: initial.id } : {}),
          slug,
          title,
          content,
          meta_title: metaTitle || null,
          meta_description: metaDescription || null,
          is_active: isActive,
        },
      })
      toast.success('تم الحفظ')
    } catch (e: any) {
      toast.error(e?.message ?? 'فشل')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <section className="rounded-xl border border-border bg-card p-5 space-y-3">
      <div className="flex items-center justify-between">
        <h2 className="font-bold">{title}</h2>
        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" checked={isActive} onChange={(e) => setIsActive(e.target.checked)} />
          نشط
        </label>
      </div>
      <Field label="المحتوى">
        <textarea rows={8} value={content} onChange={(e) => setContent(e.target.value)} className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm" />
      </Field>
      <div className="grid sm:grid-cols-2 gap-3">
        <Field label="Meta Title">
          <input type="text" value={metaTitle} onChange={(e) => setMetaTitle(e.target.value)} className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm" />
        </Field>
        <Field label="Meta Description">
          <input type="text" value={metaDescription} onChange={(e) => setMetaDescription(e.target.value)} className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm" />
        </Field>
      </div>
      <Button onClick={onSave} disabled={submitting} className="bg-[var(--ht-blue)] hover:bg-[var(--ht-blue-dark)]">
        <Save className="size-4 ml-2" /> {submitting ? '...' : 'حفظ'}
      </Button>
    </section>
  )
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="block text-sm font-medium mb-1.5">{label}</label>
      {children}
    </div>
  )
}