// Admin Services Management
import { createFileRoute } from '@tanstack/react-router'
import { useState } from 'react'
import { Edit, Plus, Trash2, X, Wrench } from 'lucide-react'
import { toast } from 'sonner'
import { deleteServiceFn, upsertServiceFn } from '../lib/admin'
import { getActiveServices } from '../lib/store-api'
import { Button } from '../components/ui/button'
import type { Service } from '../lib/types'

type LoaderData = { services: Service[] }

export const Route = createFileRoute('/admin/services')({
  loader: async (): Promise<LoaderData> => ({ services: await getActiveServices() }),
  component: AdminServices,
})

const ICONS = ['Camera', 'Wrench', 'HardDrive', 'Cpu', 'Laptop', 'Network', 'Wifi', 'Plug', 'Settings']

function AdminServices() {
  const { services } = Route.useLoaderData() as LoaderData
  const [editing, setEditing] = useState<Service | null>(null)
  const [creating, setCreating] = useState(false)

  const onDelete = async (s: Service) => {
    if (!confirm(`حذف "${s.title}"؟`)) return
    await deleteServiceFn({ data: { id: s.id } })
    toast.success('تم الحذف')
    window.location.reload()
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">الخدمات</h1>
          <p className="text-sm text-muted-foreground">{services.length} خدمة</p>
        </div>
        <Button onClick={() => setCreating(true)} className="bg-[var(--ht-blue)] hover:bg-[var(--ht-blue-dark)]">
          <Plus className="size-4 ml-1" /> خدمة جديدة
        </Button>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {services.map((s) => (
          <article key={s.id} className="rounded-xl border border-border bg-card p-4">
            <div className="size-10 rounded-lg bg-[var(--ht-blue-light)] text-[var(--ht-blue)] flex items-center justify-center mb-3">
              <Wrench className="size-5" />
            </div>
            <h3 className="font-bold">{s.title}</h3>
            {s.description && <p className="text-xs text-muted-foreground line-clamp-2 mt-1">{s.description}</p>}
            <div className="flex items-center gap-1 mt-3">
              <Button variant="outline" size="sm" onClick={() => setEditing(s)}><Edit className="size-3.5" /></Button>
              <Button variant="outline" size="sm" onClick={() => onDelete(s)} className="text-red-600"><Trash2 className="size-3.5" /></Button>
            </div>
          </article>
        ))}
      </div>

      {(editing || creating) && (
        <ServiceModal service={editing} onClose={() => { setEditing(null); setCreating(false) }} onSaved={() => window.location.reload()} />
      )}
    </div>
  )
}

function ServiceModal({ service, onClose, onSaved }: { service: Service | null; onClose: () => void; onSaved: () => void }) {
  const [form, setForm] = useState({
    slug: service?.slug ?? '',
    title: service?.title ?? '',
    description: service?.description ?? '',
    icon: service?.icon ?? 'Wrench',
    sort_order: service?.sort_order ?? 0,
    is_active: service?.is_active ?? true,
  })
  const [submitting, setSubmitting] = useState(false)

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitting(true)
    try {
      await upsertServiceFn({
        data: {
          ...(service?.id ? { id: service.id } : {}),
          slug: form.slug || form.title.toLowerCase().replace(/\s+/g, '-'),
          title: form.title,
          description: form.description || null,
          icon: form.icon,
          sort_order: form.sort_order,
          is_active: form.is_active,
        } as any,
      })
      toast.success(service ? 'تم التحديث' : 'تم الإضافة')
      onSaved()
    } catch (e: any) {
      toast.error(e?.message ?? 'فشل')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/50 overflow-y-auto">
      <div className="min-h-full flex items-center justify-center p-4">
        <form onSubmit={onSubmit} className="w-full max-w-lg bg-card rounded-2xl shadow-2xl">
          <div className="border-b border-border p-4 flex items-center justify-between">
            <h2 className="font-bold">{service ? 'تعديل خدمة' : 'خدمة جديدة'}</h2>
            <button type="button" onClick={onClose} className="p-2 hover:bg-muted rounded"><X className="size-5" /></button>
          </div>
          <div className="p-5 space-y-4">
            <Field label="العنوان" required>
              <input type="text" required value={form.title} onChange={(e) => setForm((p) => ({ ...p, title: e.target.value }))} className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm" />
            </Field>
            <Field label="الوصف">
              <textarea rows={3} value={form.description} onChange={(e) => setForm((p) => ({ ...p, description: e.target.value }))} className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm" />
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="الأيقونة">
                <select value={form.icon} onChange={(e) => setForm((p) => ({ ...p, icon: e.target.value }))} className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm">
                  {ICONS.map((i) => <option key={i} value={i}>{i}</option>)}
                </select>
              </Field>
              <Field label="الترتيب">
                <input type="number" min={0} value={form.sort_order} onChange={(e) => setForm((p) => ({ ...p, sort_order: Number(e.target.value) }))} className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm" />
              </Field>
            </div>
            <label className="flex items-center gap-2 text-sm cursor-pointer">
              <input type="checkbox" checked={form.is_active} onChange={(e) => setForm((p) => ({ ...p, is_active: e.target.checked }))} />
              نشط
            </label>
          </div>
          <div className="border-t border-border p-4 flex items-center justify-end gap-2">
            <Button type="button" variant="outline" onClick={onClose}>إلغاء</Button>
            <Button type="submit" disabled={submitting} className="bg-[var(--ht-blue)] hover:bg-[var(--ht-blue-dark)]">{submitting ? '...' : 'حفظ'}</Button>
          </div>
        </form>
      </div>
    </div>
  )
}

function Field({ label, children, required }: { label: string; children: React.ReactNode; required?: boolean }) {
  return (
    <div>
      <label className="block text-sm font-medium mb-1.5">{label} {required && <span className="text-red-600">*</span>}</label>
      {children}
    </div>
  )
}