// Admin Dashboard
import { createFileRoute, Link } from '@tanstack/react-router'
import { useState } from 'react'
import {
  AlertTriangle,
  ArrowLeft,
  BarChart3,
  DollarSign,
  Package,
  ShoppingCart,
  TrendingUp,
  Users,
} from 'lucide-react'
import { getDashboardStats } from '../lib/store-api'

type LoaderData = Awaited<ReturnType<typeof getDashboardStats>> & {
  newOrdersCount: number
}

export const Route = createFileRoute('/admin/')({
  loader: async (): Promise<LoaderData> => {
    const stats = await getDashboardStats()
    return { ...stats, newOrdersCount: stats.newOrders }
  },
  component: AdminDashboard,
})

function AdminDashboard() {
  const data = Route.useLoaderData() as LoaderData

  const kpis = [
    {
      title: 'إجمالي المنتجات',
      value: data.totalProducts,
      icon: Package,
      color: 'bg-blue-500',
      href: '/admin/products',
    },
    {
      title: 'الطلبات الجديدة',
      value: data.newOrders,
      icon: ShoppingCart,
      color: 'bg-green-500',
      href: '/admin/orders',
    },
    {
      title: 'العملاء',
      value: data.totalCustomers,
      icon: Users,
      color: 'bg-purple-500',
      href: '/admin/customers',
    },
    {
      title: 'إجمالي المبيعات',
      value: `${Math.round(data.totalRevenue).toLocaleString('ar-EG')} ج.م`,
      icon: DollarSign,
      color: 'bg-red-500',
      href: '/admin/orders',
    },
    {
      title: 'منخفض المخزون',
      value: data.lowStock,
      icon: AlertTriangle,
      color: 'bg-amber-500',
      href: '/admin/inventory',
    },
    {
      title: 'نفذ المخزون',
      value: data.outOfStock,
      icon: AlertTriangle,
      color: 'bg-gray-700',
      href: '/admin/inventory',
    },
  ]

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">لوحة التحكم</h1>
          <p className="text-sm text-muted-foreground">نظرة عامة على أداء المتجر</p>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {kpis.map((k) => (
          <Link
            key={k.title}
            to={k.href as any}
            className="group rounded-xl border border-border bg-card p-5 transition-all hover:shadow-md"
          >
            <div className="flex items-start justify-between">
              <div className={`size-10 rounded-lg ${k.color} flex items-center justify-center text-white shrink-0`}>
                <k.icon className="size-5" />
              </div>
              <ArrowLeft className="size-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
            </div>
            <p className="mt-3 text-2xl font-bold tabular-nums">{k.value}</p>
            <p className="text-xs text-muted-foreground mt-1">{k.title}</p>
          </Link>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        <article className="rounded-xl border border-border bg-card p-5">
          <div className="flex items-center gap-2 mb-3">
            <BarChart3 className="size-5 text-[var(--ht-blue)]" />
            <h2 className="font-bold">إحصائيات إضافية</h2>
          </div>
          <div className="space-y-3 text-sm">
            <StatRow label="التصنيفات الظاهرة" value={data.totalCategories} />
            <StatRow label="المنتجات المتاحة" value={`${data.availableProducts} / ${data.totalProducts}`} />
            <StatRow label="منتجات عليها خصم" value={data.onSale} />
            <StatRow label="المنتجات المميزة" value={data.featured} />
            <StatRow label="الأكثر مبيعًا" value={data.bestSellers} />
            <StatRow label="إجمالي الطلبات" value={data.totalOrders} />
          </div>
        </article>

        <article className="rounded-xl border border-border bg-card p-5">
          <div className="flex items-center gap-2 mb-3">
            <TrendingUp className="size-5 text-[var(--ht-red)]" />
            <h2 className="font-bold">المنتجات الأكثر مشاهدة</h2>
          </div>
          {data.mostViewed.length === 0 ? (
            <p className="text-sm text-muted-foreground">لا توجد بيانات بعد.</p>
          ) : (
            <ul className="space-y-2">
              {data.mostViewed.slice(0, 5).map((p) => (
                <li key={p.id} className="flex items-center justify-between text-sm">
                  <span className="line-clamp-1 flex-1">{p.name}</span>
                  <span className="text-muted-foreground tabular-nums mr-2">{p.views_count ?? 0} مشاهدة</span>
                </li>
              ))}
            </ul>
          )}
        </article>
      </div>
    </div>
  )
}

function StatRow({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="flex items-center justify-between border-b border-border last:border-0 pb-2 last:pb-0">
      <span className="text-muted-foreground">{label}</span>
      <span className="font-bold tabular-nums">{value}</span>
    </div>
  )
}