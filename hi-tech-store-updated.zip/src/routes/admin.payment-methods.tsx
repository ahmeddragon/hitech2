// Admin Payment Methods
import { createFileRoute } from '@tanstack/react-router'
import { useState } from 'react'
import { CreditCard, Edit, Plus, Trash2, X } from 'lucide-react'
import { toast } from 'sonner'
import { deletePaymentMethodFn, upsertPaymentMethodFn } from '../lib/admin'
import { getActivePaymentMethods } from '../lib/store-api'
import { Button } from '../components/ui/button'
import type { PaymentMethod } from '../lib/types'

type LoaderData = { methods: PaymentMethod[] }

export const Route = createFileRoute('/admin/payment-methods')({
  loader: async (): Promise<LoaderData> => ({ methods: await getActivePaymentMethods() }),
  component: AdminPaymentMethods,
})

function AdminPaymentMethods() {
  const { methods } = Route.useLoaderData() as LoaderData
  const [editing, setEditing] = useState<PaymentMethod | null>(null)
  const [creating, setCreating] = useState(false)

  const onDelete = async (m: PaymentMethod) => {
    if (!confirm(`حذف "${m.name}"؟`)) return
    await deletePaymentMethodFn({ data: { id: m.id } })
    toast.success('تم الحذف')
    window.location.reload()
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">طرق الدفع</h1>
          <p className="text-sm text-muted-foreground">{methods.length} طريقة</p>
        </div>
        <Button onClick={() => setCreating(true)} className="bg-[var(--ht-blue)] hover:bg-[var(--ht-blue-dark)]">
          <Plus className="size-4 ml-1" /> طريقة جديدة
        </Button>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {methods.map((m) => (
          <article key={m.id} className="rounded-xl border border-border bg-card p-4">
            <div className="flex items-start gap-3">
              <div className="size-10 rounded-lg bg-green-100 text-green-600 flex items-center justify-center shrink-0">
                <span className="text-xl">{m.icon ?? '💳'}</span>
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-bold">{m.name}</h3>
                {m.account_number && <p className="text-xs font-mono mt-1">{m.account_number}</p>}
                {m.instructions && <p className="text-xs text-muted-foreground line-clamp-2 mt-1">{m.instructions}</p>}
              </div>
            </div>
            <div className="flex items-center gap-1 mt-3">
              <Button variant="outline" size="sm" onClick={() => setEditing(m)}><Edit className="size-3.5" /></Button>
              <Button variant="outline" size="sm" onClick={() => onDelete(m)} className="text-red-600"><Trash2 className="size-3.5" /></Button>
            </div>
          </article>
        ))}
      </div>

      {(editing || creating) && (
        <PaymentMethodModal method={editing} onClose={() => { setEditing(null); setCreating(false) }} onSaved={() => window.location.reload()} />
      )}
    </div>
  )
}

function PaymentMethodModal({ method, onClose, onSaved }: { method: PaymentMethod | null; onClose: () => void; onSaved: () => void }) {
  const [form, setForm] = useState({
    code: method?.code ?? '',
    name: method?.name ?? '',
    account_number: method?.account_number ?? '',
    instructions: method?.instructions ?? '',
    icon: method?.icon ?? '💵',
    sort_order: method?.sort_order ?? 0,
    is_active: method?.is_active ?? true,
  })
  const [submitting, setSubmitting] = useState(false)

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitting(true)
    try {
      await upsertPaymentMethodFn({
        data: {
          ...(method?.id ? { id: method.id } : {}),
          code: form.code || form.name.toLowerCase().replace(/\s+/g, '_'),
          name: form.name,
          account_number: form.account_number || null,
          instructions: form.instructions || null,
          icon: form.icon || null,
          sort_order: form.sort_order,
          is_active: form.is_active,
        } as any,
      })
      toast.success(method ? 'تم التحديث' : 'تم الإضافة')
      onSaved()
    } catch (e: any) {
      toast.error(e?.message ?? 'فشل')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/50 overflow-y-auto">
      <div className="min-h-full flex items-center justify-center p-4">
        <form onSubmit={onSubmit} className="w-full max-w-lg bg-card rounded-2xl shadow-2xl">
          <div className="border-b border-border p-4 flex items-center justify-between">
            <h2 className="font-bold">{method ? 'تعديل طريقة دفع' : 'طريقة دفع جديدة'}</h2>
            <button type="button" onClick={onClose} className="p-2 hover:bg-muted rounded"><X className="size-5" /></button>
          </div>
          <div className="p-5 space-y-4">
            <Field label="الاسم" required>
              <input type="text" required value={form.name} onChange={(e) => setForm((p) => ({ ...p, name: e.target.value }))} className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm" />
            </Field>
            <Field label="كود">
              <input type="text" value={form.code} onChange={(e) => setForm((p) => ({ ...p, code: e.target.value }))} placeholder="cash, vodafone_cash" className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm" />
            </Field>
            <Field label="رقم الحساب / المعرف">
              <input type="text" value={form.account_number} onChange={(e) => setForm((p) => ({ ...p, account_number: e.target.value }))} className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm" />
            </Field>
            <Field label="تعليمات للعميل">
              <textarea rows={2} value={form.instructions} onChange={(e) => setForm((p) => ({ ...p, instructions: e.target.value }))} className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm" />
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="أيقونة (إيموجي)">
                <input type="text" value={form.icon} onChange={(e) => setForm((p) => ({ ...p, icon: e.target.value }))} className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm" />
              </Field>
              <Field label="الترتيب">
                <input type="number" min={0} value={form.sort_order} onChange={(e) => setForm((p) => ({ ...p, sort_order: Number(e.target.value) }))} className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm" />
              </Field>
            </div>
            <label className="flex items-center gap-2 text-sm cursor-pointer">
              <input type="checkbox" checked={form.is_active} onChange={(e) => setForm((p) => ({ ...p, is_active: e.target.checked }))} />
              نشط
            </label>
          </div>
          <div className="border-t border-border p-4 flex items-center justify-end gap-2">
            <Button type="button" variant="outline" onClick={onClose}>إلغاء</Button>
            <Button type="submit" disabled={submitting} className="bg-[var(--ht-blue)] hover:bg-[var(--ht-blue-dark)]">{submitting ? '...' : 'حفظ'}</Button>
          </div>
        </form>
      </div>
    </div>
  )
}

function Field({ label, children, required }: { label: string; children: React.ReactNode; required?: boolean }) {
  return (
    <div>
      <label className="block text-sm font-medium mb-1.5">{label} {required && <span className="text-red-600">*</span>}</label>
      {children}
    </div>
  )
}