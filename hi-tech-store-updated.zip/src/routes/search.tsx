// Search page
import { createFileRoute, Link } from '@tanstack/react-router'
import { Search as SearchIcon } from 'lucide-react'
import { getSettings, getVisibleCategories, searchProducts } from '../lib/store-api'
import { StoreLayout } from '../components/store-layout'
import { ProductCard } from '../components/product-card'
import { Button } from '../components/ui/button'
import type { Product, Settings } from '../lib/types'

type LoaderData = {
  settings: Settings
  categories: Awaited<ReturnType<typeof getVisibleCategories>>
  results: Product[]
  query: string
}

export const Route = createFileRoute('/search')({
  validateSearch: (search: Record<string, unknown>) => ({
    q: typeof search.q === 'string' ? search.q : '',
  }),
  loaderDeps: ({ search }) => search,
  loader: async ({ deps }): Promise<LoaderData> => {
    const [settings, categories, results] = await Promise.all([
      getSettings(),
      getVisibleCategories(),
      searchProducts({ data: { query: deps.q, limit: 30 } }),
    ])
    return { settings, categories, results, query: deps.q }
  },
  component: SearchPage,
  head: ({ loaderData }) => ({
    meta: [{ title: loaderData?.query ? `بحث: ${loaderData.query} | Hi-Tech` : 'بحث | Hi-Tech' }],
  }),
})

function SearchPage() {
  const { settings, categories, results, query } = Route.useLoaderData() as LoaderData
  return (
    <StoreLayout settings={settings} categories={categories}>
      <div className="mx-auto max-w-7xl px-4 py-6">
        <h1 className="text-2xl font-bold mb-1">نتائج البحث</h1>
        <p className="text-sm text-muted-foreground mb-4">
          {query ? `البحث عن "${query}" — ${results.length} نتيجة` : 'لم يتم إدخال كلمة بحث'}
        </p>

        {results.length === 0 ? (
          <div className="text-center py-20 border border-border rounded-xl bg-card">
            <SearchIcon className="size-12 mx-auto text-muted-foreground" />
            <p className="mt-3">لم نعثر على منتجات مطابقة لبحثك.</p>
            <Link to="/products" className="text-[var(--ht-blue)] hover:underline mt-2 inline-block">
              تصفح كل المنتجات
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
            {results.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        )}
      </div>
    </StoreLayout>
  )
}