import { HeadContent, Scripts, createRootRoute } from '@tanstack/react-router'
import type { ReactNode } from 'react'

import appCss from '../styles.css?url'

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: 'utf-8' },
      { name: 'viewport', content: 'width=device-width, initial-scale=1, viewport-fit=cover' },
      { name: 'theme-color', content: '#1E40AF' },
      { name: 'format-detection', content: 'telephone=no' },
      {
        name: 'description',
        content:
          'متجر Hi-Tech في بلقاس لبيع اللاب توب، الكمبيوتر، شاشات، كاميرات المراقبة، DVR/NVR، هاردات، إكسسوارات وخدمات التركيب والصيانة.',
      },
      { property: 'og:locale', content: 'ar_EG' },
      { property: 'og:type', content: 'website' },
      { property: 'og:site_name', content: 'Hi-Tech' },
      { property: 'og:title', content: 'Hi-Tech - كمبيوتر، لاب توب، كاميرات مراقبة' },
      {
        property: 'og:description',
        content: 'متجر Hi-Tech في بلقاس - لخدمات الكمبيوتر واللاب توب وكاميرات المراقبة.',
      },
      { name: 'twitter:card', content: 'summary_large_image' },
      { title: 'Hi-Tech - كمبيوتر، لاب توب، كاميرات مراقبة' },
    ],
    links: [
      { rel: 'preconnect', href: 'https://fonts.googleapis.com' },
      { rel: 'preconnect', href: 'https://fonts.gstatic.com', crossOrigin: 'anonymous' },
      {
        rel: 'stylesheet',
        href: 'https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;600;700;800&family=Tajawal:wght@400;500;700&display=swap',
      },
      { rel: 'stylesheet', href: appCss },
      { rel: 'icon', type: 'image/svg+xml', href: '/icon.svg' },
      { rel: 'apple-touch-icon', href: '/logo512.png' },
      { rel: 'manifest', href: '/manifest.json' },
    ],
  }),
  shellComponent: RootDocument,
})

function RootDocument({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <head>
        <HeadContent />
      </head>
      <body className="font-arabic bg-background text-foreground antialiased">
        {children}
        <Scripts />
      </body>
    </html>
  )
}