// Offers page
import { createFileRoute, Link } from '@tanstack/react-router'
import { Tag } from 'lucide-react'
import { getActiveOffers, getSettings, getVisibleCategories } from '../lib/store-api'
import { StoreLayout } from '../components/store-layout'
import { Button } from '../components/ui/button'
import type { Settings } from '../lib/types'

type LoaderData = {
  settings: Settings
  categories: Awaited<ReturnType<typeof getVisibleCategories>>
  offers: Awaited<ReturnType<typeof getActiveOffers>>
}

export const Route = createFileRoute('/offers')({
  loader: async (): Promise<LoaderData> => {
    const [settings, categories, offers] = await Promise.all([
      getSettings(),
      getVisibleCategories(),
      getActiveOffers(),
    ])
    return { settings, categories, offers }
  },
  component: OffersPage,
  head: () => ({ meta: [{ title: 'العروض والخصومات | Hi-Tech' }] }),
})

function OffersPage() {
  const { settings, categories, offers } = Route.useLoaderData() as LoaderData
  return (
    <StoreLayout settings={settings} categories={categories}>
      <section className="bg-gradient-to-r from-[var(--ht-red-dark)] to-[var(--ht-red)] text-white">
        <div className="mx-auto max-w-7xl px-4 py-8">
          <Tag className="size-10 mb-2" />
          <h1 className="text-2xl sm:text-3xl font-bold">العروض والخصومات</h1>
          <p className="opacity-90 mt-1 text-sm">اكتشف أقوى العروض على منتجاتنا</p>
        </div>
      </section>

      <div className="mx-auto max-w-7xl px-4 py-6">
        {offers.length === 0 ? (
          <div className="text-center py-20 border border-border rounded-xl bg-card">
            <Tag className="size-12 mx-auto text-muted-foreground" />
            <p className="mt-3">لا توجد عروض نشطة حاليًا.</p>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {offers.map((o) => (
              <article key={o.id} className="rounded-xl overflow-hidden border border-border bg-card hover:shadow-lg transition-all">
                <div className="aspect-[16/9] bg-gradient-to-br from-[var(--ht-blue)] to-[var(--ht-red)] relative">
                  {o.image_url && (
                    <img src={o.image_url} alt={o.title} className="size-full object-cover" />
                  )}
                  <span className="absolute top-3 left-3 bg-[var(--ht-red)] text-white text-sm font-bold px-3 py-1.5 rounded-md">
                    خصم {Math.round(Number(o.discount_percent))}%
                  </span>
                </div>
                <div className="p-4">
                  <h3 className="font-bold mb-1">{o.title}</h3>
                  {o.description && <p className="text-sm text-muted-foreground line-clamp-2">{o.description}</p>}
                  <p className="text-xs text-muted-foreground mt-2">{o.product_ids.length} منتج</p>
                </div>
              </article>
            ))}
          </div>
        )}
        <div className="mt-8 text-center">
          <Link to="/products">
            <Button className="bg-[var(--ht-blue)] hover:bg-[var(--ht-blue-dark)]">تصفح كل المنتجات</Button>
          </Link>
        </div>
      </div>
    </StoreLayout>
  )
}