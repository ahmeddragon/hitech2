// Home page
import { createFileRoute, Link } from '@tanstack/react-router'
import { useEffect } from 'react'
import {
  getActiveBanners,
  getActiveOffers,
  getActiveServices,
  getFeaturedCategories,
  getProducts,
  getSettings,
  getVisibleCategories,
} from '../lib/store-api'
import { StoreLayout } from '../components/store-layout'
import { CategoryCard, ProductCard } from '../components/product-card'
import { Button } from '../components/ui/button'
import { ArrowLeft, ChevronLeft, Phone, Wrench } from 'lucide-react'
import type { Banner, Category, Service, Settings } from '../lib/types'
import { WhatsappIcon } from '../components/header'

type LoaderData = {
  settings: Settings
  categories: Category[]
  featuredCategories: Category[]
  banners: Banner[]
  services: Service[]
  latestProducts: Awaited<ReturnType<typeof getProducts>>['items']
  featuredProducts: Awaited<ReturnType<typeof getProducts>>['items']
  onSaleProducts: Awaited<ReturnType<typeof getProducts>>['items']
  bestSellers: Awaited<ReturnType<typeof getProducts>>['items']
  offers: Awaited<ReturnType<typeof getActiveOffers>>
}

export const Route = createFileRoute('/')({
  loader: async (): Promise<LoaderData> => {
    const [
      settings,
      categories,
      featuredCategories,
      banners,
      services,
      latestRes,
      featuredRes,
      onSaleRes,
      bestSellerRes,
      offers,
    ] = await Promise.all([
      getSettings(),
      getVisibleCategories(),
      getFeaturedCategories(),
      getActiveBanners(),
      getActiveServices(),
      getProducts({ data: { sort: 'newest', page_size: 12 } }),
      getProducts({ data: { is_featured: true, page_size: 8 } }),
      getProducts({ data: { is_on_sale: true, page_size: 8 } }),
      getProducts({ data: { is_best_seller: true, page_size: 8 } }),
      getActiveOffers(),
    ])
    return {
      settings,
      categories,
      featuredCategories,
      banners,
      services,
      latestProducts: latestRes.items,
      featuredProducts: featuredRes.items,
      onSaleProducts: onSaleRes.items,
      bestSellers: bestSellerRes.items,
      offers,
    }
  },
  component: Home,
  head: ({ loaderData }) => ({
    meta: [
      { title: loaderData?.settings.meta_title ?? 'Hi-Tech' },
      { name: 'description', content: loaderData?.settings.meta_description ?? '' },
    ],
  }),
})

function Home() {
  const data = Route.useLoaderData()
  const { settings, featuredCategories, banners, services, latestProducts, featuredProducts, onSaleProducts, bestSellers, offers } = data

  return (
    <StoreLayout settings={settings} categories={data.categories}>
      <HeroCarousel banners={banners} settings={settings} />
      <TrustStrip settings={settings} />
      <FeaturedCategories categories={featuredCategories} />
      <ProductSection
        title="أحدث المنتجات"
        subtitle="وصل حديثًا"
        products={latestProducts}
        link="/products"
      />
      {onSaleProducts.length > 0 && (
        <ProductSection
          title="عروض وخصومات"
          subtitle="وفر الآن"
          products={onSaleProducts}
          link="/offers"
          accent="red"
        />
      )}
      {featuredProducts.length > 0 && (
        <ProductSection
          title="منتجات مميزة"
          subtitle="اختياراتنا لك"
          products={featuredProducts}
        />
      )}
      {bestSellers.length > 0 && (
        <ProductSection
          title="الأكثر طلبًا"
          subtitle="الأكثر مبيعًا"
          products={bestSellers}
        />
      )}
      <ServicesSection services={services} />
      <ContactStrip settings={settings} />
    </StoreLayout>
  )
}

function HeroCarousel({ banners, settings }: { banners: Banner[]; settings: Settings }) {
  // Simple non-rotating version (multiple stacked on mobile, grid on desktop)
  if (banners.length === 0) {
    return (
      <section className="bg-gradient-to-br from-[var(--ht-blue)] via-[var(--ht-blue-dark)] to-[var(--ht-red-dark)] text-white">
        <div className="mx-auto max-w-7xl px-4 py-12 sm:py-16 md:py-20 grid md:grid-cols-2 gap-8 items-center">
          <div>
            <p className="inline-block px-3 py-1 rounded-full bg-white/15 text-sm mb-4">
              {settings.store_description}
            </p>
            <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold leading-tight">
              كمبيوتر، لاب توب، كاميرات مراقبة
            </h1>
            <p className="text-base sm:text-lg opacity-90 mt-3 leading-7">
              متجر Hi-Tech في بلقاس — أحدث الموديلات بضمان حقيقي وخدمات تركيب احترافية.
            </p>
            <div className="flex gap-2 mt-6">
              <Link to="/products">
                <Button size="lg" className="bg-white text-[var(--ht-blue)] hover:bg-white/90">
                  تصفح المنتجات
                </Button>
              </Link>
              <a href={`https://wa.me/${settings.whatsapp.replace(/^0/, '20')}`} target="_blank" rel="noopener noreferrer">
                <Button size="lg" variant="outline" className="border-white/30 text-white hover:bg-white/10">
                  <WhatsappIcon className="size-4 ml-2" /> واتساب
                </Button>
              </a>
            </div>
          </div>
          <div className="hidden md:flex justify-center">
            <div className="size-72 rounded-full bg-white/10 backdrop-blur flex items-center justify-center text-6xl font-black">
              Hi-Tech
            </div>
          </div>
        </div>
      </section>
    )
  }

  return (
    <section className="bg-muted">
      <div className="mx-auto max-w-7xl px-0 sm:px-4">
        <div className="grid gap-3 sm:gap-4 md:grid-cols-2 lg:grid-cols-3">
          {banners.slice(0, 3).map((b) => (
            <Link
              key={b.id}
              to={b.cta_link || '/products'}
              className="relative block overflow-hidden rounded-none sm:rounded-xl group aspect-[4/3] sm:aspect-[16/9] md:aspect-[5/4] lg:aspect-[4/5] bg-[var(--ht-blue-dark)]"
            >
              <img
                src={b.image_url}
                alt={b.title}
                loading="eager"
                className="absolute inset-0 size-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />
              <div className="absolute inset-0 flex flex-col justify-end p-4 sm:p-6 text-white">
                {b.subtitle && (
                  <p className="text-xs sm:text-sm uppercase tracking-wider opacity-90 mb-1">
                    {b.subtitle}
                  </p>
                )}
                <h2 className="text-lg sm:text-2xl md:text-3xl font-bold leading-tight">
                  {b.title}
                </h2>
                {b.description && (
                  <p className="hidden sm:block text-sm opacity-90 mt-2 line-clamp-2">{b.description}</p>
                )}
                {b.cta_label && (
                  <span className="mt-3 inline-flex items-center gap-1 text-xs sm:text-sm font-semibold bg-[var(--ht-red)] text-white px-3 py-1.5 rounded-md w-fit">
                    {b.cta_label} <ChevronLeft className="size-3.5" />
                  </span>
                )}
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}

function TrustStrip({ settings }: { settings: Settings }) {
  const items = [
    { icon: '🚚', label: 'توصيل سريع' },
    { icon: '✅', label: 'ضمان حقيقي' },
    { icon: '💳', label: 'طرق دفع متعددة' },
    { icon: '🛠️', label: 'تركيب احترافي' },
  ]
  return (
    <section className="border-b border-border bg-card">
      <div className="mx-auto max-w-7xl px-4 py-3 grid grid-cols-2 sm:grid-cols-4 gap-3 text-center text-sm">
        {items.map((it) => (
          <div key={it.label} className="flex items-center justify-center gap-2">
            <span className="text-2xl">{it.icon}</span>
            <span className="font-medium">{it.label}</span>
          </div>
        ))}
      </div>
    </section>
  )
}

function FeaturedCategories({ categories }: { categories: Category[] }) {
  if (categories.length === 0) return null
  return (
    <section className="mx-auto max-w-7xl px-4 py-8">
      <SectionHeader title="تصفح حسب القسم" subtitle="اختر القسم المناسب لاحتياجك" />
      <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-3">
        {categories.slice(0, 16).map((c) => (
          <CategoryCard key={c.id} category={c} />
        ))}
      </div>
    </section>
  )
}

function ProductSection({
  title,
  subtitle,
  products,
  link,
  accent = 'blue',
}: {
  title: string
  subtitle: string
  products: any[]
  link?: string
  accent?: 'blue' | 'red'
}) {
  if (products.length === 0) return null
  return (
    <section className="mx-auto max-w-7xl px-4 py-6">
      <div className="flex items-end justify-between mb-4">
        <div>
          <p className={`text-xs uppercase tracking-wider ${accent === 'red' ? 'text-[var(--ht-red)]' : 'text-[var(--ht-blue)]'}`}>
            {subtitle}
          </p>
          <h2 className="text-xl sm:text-2xl font-bold">{title}</h2>
        </div>
        {link && (
          <Link to={link as any} className="text-sm text-[var(--ht-blue)] hover:underline flex items-center gap-1">
            عرض الكل <ArrowLeft className="size-4" />
          </Link>
        )}
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
        {products.slice(0, 10).map((p) => (
          <ProductCard key={p.id} product={p} />
        ))}
      </div>
    </section>
  )
}

function SectionHeader({ title, subtitle }: { title: string; subtitle: string }) {
  return (
    <div className="mb-4">
      <p className="text-xs uppercase tracking-wider text-[var(--ht-blue)]">{subtitle}</p>
      <h2 className="text-xl sm:text-2xl font-bold">{title}</h2>
    </div>
  )
}

function ServicesSection({ services }: { services: Service[] }) {
  if (services.length === 0) return null
  return (
    <section className="mx-auto max-w-7xl px-4 py-8">
      <SectionHeader title="خدماتنا الاحترافية" subtitle="فنيون متخصصون" />
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
        {services.map((s) => (
          <div
            key={s.id}
            className="rounded-xl border border-border bg-card p-5 hover:border-[var(--ht-blue)] hover:shadow-md transition-all"
          >
            <div className="size-12 rounded-lg bg-[var(--ht-blue-light)] flex items-center justify-center mb-3 text-[var(--ht-blue)]">
              <Wrench className="size-6" />
            </div>
            <h3 className="font-bold mb-1">{s.title}</h3>
            {s.description && (
              <p className="text-sm text-muted-foreground line-clamp-3">{s.description}</p>
            )}
          </div>
        ))}
      </div>
      <div className="mt-6 text-center">
        <Link to="/services">
          <Button variant="outline" className="border-[var(--ht-blue)] text-[var(--ht-blue)] hover:bg-[var(--ht-blue)] hover:text-white">
            جميع الخدمات
          </Button>
        </Link>
      </div>
    </section>
  )
}

function ContactStrip({ settings }: { settings: Settings }) {
  return (
    <section className="bg-gradient-to-r from-[var(--ht-blue)] to-[var(--ht-blue-dark)] text-white">
      <div className="mx-auto max-w-7xl px-4 py-8 grid md:grid-cols-3 gap-6 text-center md:text-right">
        <div className="flex md:flex-col items-center md:items-start gap-3 md:gap-1">
          <Phone className="size-7 text-white/80 mb-2" />
          <p className="text-sm opacity-90">اتصل بنا</p>
          <a href={`tel:${settings.phone}`} className="text-lg font-bold tabular-nums hover:underline">
            {settings.phone}
          </a>
        </div>
        <div className="flex md:flex-col items-center md:items-start gap-3 md:gap-1">
          <WhatsappIcon className="size-7 text-white/80 mb-2" />
          <p className="text-sm opacity-90">راسلنا على واتساب</p>
          <a
            href={`https://wa.me/${settings.whatsapp.replace(/^0/, '20')}`}
            target="_blank"
            rel="noopener noreferrer"
            className="text-lg font-bold tabular-nums hover:underline"
          >
            {settings.whatsapp}
          </a>
        </div>
        <div className="flex md:flex-col items-center md:items-start gap-3 md:gap-1">
          <Wrench className="size-7 text-white/80 mb-2" />
          <p className="text-sm opacity-90">العنوان</p>
          <p className="text-sm font-medium">{settings.address}</p>
        </div>
      </div>
    </section>
  )
}