// Product Details page
import { createFileRoute, Link, useNavigate } from '@tanstack/react-router'
import { useState } from 'react'
import {
  ChevronLeft,
  Heart,
  Minus,
  Phone,
  Plus,
  Share2,
  ShoppingCart,
  Truck,
} from 'lucide-react'
import {
  getProductBySlug,
  getProducts,
  getSettings,
  getVisibleCategories,
} from '../lib/store-api'
import { StoreLayout } from '../components/store-layout'
import { ProductCard, PriceDisplay } from '../components/product-card'
import { Button } from '../components/ui/button'
import { toast } from 'sonner'
import { useCart } from '../components/cart-context'
import type { Product, Settings } from '../lib/types'
import { STOCK_COLORS, STOCK_LABELS, getStockStatus } from '../lib/types'
import { cn } from '../lib/utils'
import { WhatsappIcon } from '../components/header'

type LoaderData = {
  settings: Settings
  categories: Awaited<ReturnType<typeof getVisibleCategories>>
  product: Product
  related: Product[]
}

export const Route = createFileRoute('/product/$slug')({
  parseParams: (raw) => ({ slug: typeof raw.slug === 'string' ? raw.slug : '' }),
  loader: async ({ params }): Promise<LoaderData> => {
    const product = await getProductBySlug({ data: { slug: params.slug } })
    if (!product) throw new Error('Product not found')
    const [settings, categories, relatedRes] = await Promise.all([
      getSettings(),
      getVisibleCategories(),
      getProducts({ data: { category_id: product.category_id ?? undefined, page_size: 8 } }),
    ])
    const related = relatedRes.items.filter((p) => p.id !== product.id).slice(0, 4)
    return { settings, categories, product, related }
  },
  component: ProductPage,
  notFoundComponent: () => (
    <div className="mx-auto max-w-3xl px-4 py-20 text-center">
      <h1 className="text-2xl font-bold">المنتج غير موجود</h1>
      <Link to="/products" className="text-[var(--ht-blue)] hover:underline mt-3 inline-block">
        تصفح المنتجات
      </Link>
    </div>
  ),
})

function ProductPage() {
  const { settings, categories, product, related } = Route.useLoaderData() as LoaderData
  const { add } = useCart()
  const [activeImage, setActiveImage] = useState(0)
  const [qty, setQty] = useState(1)
  const [tab, setTab] = useState<'desc' | 'specs' | 'shipping'>('desc')

  const images = product.images?.length ? product.images : []
  const main = images[activeImage]?.url ?? product.main_image?.url
  const stock = getStockStatus(product)
  const disabled = stock === 'out_of_stock' || stock === 'unavailable'

  const handleAdd = () => {
    if (disabled) return
    if (qty > product.stock) {
      toast.error(`الكمية المتاحة ${product.stock} فقط`)
      return
    }
    add({
      product_id: product.id,
      slug: product.slug,
      name: product.name,
      image: main,
      unit_price: product.price,
      original_price: product.price_original > product.price ? product.price_original : undefined,
      quantity: qty,
      max_stock: product.stock,
    })
    toast.success('تمت إضافة المنتج إلى السلة')
  }

  const handleShare = async () => {
    const url = typeof window !== 'undefined' ? window.location.href : ''
    try {
      if (navigator.share) {
        await navigator.share({ title: product.name, url })
      } else if (navigator.clipboard) {
        await navigator.clipboard.writeText(url)
        toast.success('تم نسخ الرابط')
      }
    } catch {}
  }

  return (
    <StoreLayout settings={settings} categories={categories}>
      <div className="mx-auto max-w-7xl px-4 py-6">
        {/* Breadcrumb */}
        <nav className="text-xs text-muted-foreground mb-3">
          <Link to="/" className="hover:underline">الرئيسية</Link>
          {product.category && (
            <>
              {' / '}
              <Link
                to="/category/$slug"
                params={{ slug: product.category.slug }}
                className="hover:underline"
              >
                {product.category.name}
              </Link>
            </>
          )}
          {' / '}
          <span className="text-foreground">{product.name}</span>
        </nav>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Gallery */}
          <div>
            <div className="aspect-square rounded-xl overflow-hidden bg-muted border border-border">
              {main ? (
                <img src={main} alt={product.name} className="size-full object-cover" />
              ) : (
                <div className="size-full flex items-center justify-center text-muted-foreground">
                  لا توجد صورة
                </div>
              )}
            </div>
            {images.length > 1 && (
              <div className="flex gap-2 mt-3 overflow-x-auto scrollbar-hide">
                {images.map((img, idx) => (
                  <button
                    key={img.id}
                    type="button"
                    onClick={() => setActiveImage(idx)}
                    className={cn(
                      'shrink-0 size-16 rounded-md overflow-hidden border-2',
                      activeImage === idx ? 'border-[var(--ht-blue)]' : 'border-transparent',
                    )}
                  >
                    <img src={img.thumbnail_url ?? img.url} alt="" className="size-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Info */}
          <div>
            <div className="flex items-center gap-2 mb-2">
              {product.brand && (
                <span className="text-xs uppercase tracking-wide text-muted-foreground">
                  {product.brand.name}
                </span>
              )}
              {product.sku && (
                <span className="text-xs text-muted-foreground">SKU: {product.sku}</span>
              )}
            </div>
            <h1 className="text-xl sm:text-2xl font-bold leading-7">{product.name}</h1>

            <div className="flex items-center gap-2 mt-3">
              <span className={cn('text-xs px-2 py-1 rounded border', STOCK_COLORS[stock])}>
                {STOCK_LABELS[stock]}
              </span>
              {product.is_new && (
                <span className="text-xs px-2 py-1 rounded bg-[var(--ht-blue)] text-white">جديد</span>
              )}
              {product.discount_percent > 0 && (
                <span className="text-xs px-2 py-1 rounded bg-[var(--ht-red)] text-white">
                  خصم {Math.round(product.discount_percent)}%
                </span>
              )}
            </div>

            <div className="mt-4">
              <PriceDisplay
                price={product.price}
                original={product.price_original}
                discount={product.discount_percent}
                large
              />
            </div>

            {product.short_description && (
              <p className="mt-4 text-sm leading-7 text-foreground/80">
                {product.short_description}
              </p>
            )}

            {/* Quantity + Add to cart */}
            <div className="mt-5 flex flex-col sm:flex-row gap-3">
              <div className="flex items-center border border-border rounded-md">
                <button
                  type="button"
                  onClick={() => setQty(Math.max(1, qty - 1))}
                  className="p-2 hover:bg-muted disabled:opacity-50"
                  disabled={qty <= 1}
                  aria-label="إنقاص"
                >
                  <Minus className="size-4" />
                </button>
                <input
                  type="number"
                  value={qty}
                  min={1}
                  max={product.stock}
                  onChange={(e) => setQty(Math.max(1, Math.min(product.stock, Number(e.target.value))))}
                  className="w-14 text-center bg-transparent border-x border-border py-2 tabular-nums"
                />
                <button
                  type="button"
                  onClick={() => setQty(Math.min(product.stock, qty + 1))}
                  className="p-2 hover:bg-muted disabled:opacity-50"
                  disabled={qty >= product.stock}
                  aria-label="زيادة"
                >
                  <Plus className="size-4" />
                </button>
              </div>

              <Button
                size="lg"
                disabled={disabled}
                onClick={handleAdd}
                className="flex-1 bg-[var(--ht-blue)] hover:bg-[var(--ht-blue-dark)]"
              >
                <ShoppingCart className="size-4 ml-2" />
                {disabled ? 'غير متوفر' : 'أضف إلى السلة'}
              </Button>
            </div>

            <div className="mt-3 grid grid-cols-2 gap-2">
              <a
                href={`https://wa.me/${settings.whatsapp.replace(/^0/, '20')}?text=${encodeURIComponent(
                  `مرحبًا، أرغب في شراء: ${product.name} بسعر ${product.price} ج.م`,
                )}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-md bg-[var(--ht-red)] text-white text-sm font-semibold hover:bg-[var(--ht-red-dark)]"
              >
                <WhatsappIcon className="size-4" /> اطلب عبر واتساب
              </a>
              <a
                href={`tel:${settings.phone}`}
                className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-md border-2 border-[var(--ht-blue)] text-[var(--ht-blue)] text-sm font-semibold hover:bg-[var(--ht-blue-light)]"
              >
                <Phone className="size-4" /> اتصل للاستفسار
              </a>
            </div>

            <div className="mt-4 flex items-center gap-4 text-sm">
              <button onClick={handleShare} className="flex items-center gap-1.5 text-muted-foreground hover:text-foreground">
                <Share2 className="size-4" /> مشاركة
              </button>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="mt-8 border-t border-border">
          <div className="flex gap-1 border-b border-border overflow-x-auto">
            <TabButton active={tab === 'desc'} onClick={() => setTab('desc')}>الوصف</TabButton>
            <TabButton active={tab === 'specs'} onClick={() => setTab('specs')}>المواصفات</TabButton>
            <TabButton active={tab === 'shipping'} onClick={() => setTab('shipping')}>الشحن والاسترجاع</TabButton>
          </div>
          <div className="py-5 text-sm leading-7">
            {tab === 'desc' && (
              <div className="prose prose-sm max-w-none">
                {product.description ? (
                  <p className="whitespace-pre-line">{product.description}</p>
                ) : (
                  <p className="text-muted-foreground">لا يوجد وصف مفصل.</p>
                )}
              </div>
            )}
            {tab === 'specs' && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-w-3xl">
                {Object.entries(product.specs ?? {}).map(([k, v]) => (
                  <div key={k} className="flex border-b border-border py-2">
                    <span className="font-semibold w-1/3 text-muted-foreground">{k}</span>
                    <span className="w-2/3">{String(v)}</span>
                  </div>
                ))}
                {product.model && (
                  <div className="flex border-b border-border py-2">
                    <span className="font-semibold w-1/3 text-muted-foreground">الموديل</span>
                    <span className="w-2/3">{product.model}</span>
                  </div>
                )}
                {product.sku && (
                  <div className="flex border-b border-border py-2">
                    <span className="font-semibold w-1/3 text-muted-foreground">SKU</span>
                    <span className="w-2/3 tabular-nums">{product.sku}</span>
                  </div>
                )}
                {product.barcode && (
                  <div className="flex border-b border-border py-2">
                    <span className="font-semibold w-1/3 text-muted-foreground">Barcode</span>
                    <span className="w-2/3 tabular-nums">{product.barcode}</span>
                  </div>
                )}
              </div>
            )}
            {tab === 'shipping' && (
              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <Truck className="size-5 text-[var(--ht-blue)] mt-1" />
                  <div>
                    <p className="font-semibold">التوصيل داخل بلقاس والمناطق المجاورة</p>
                    <p className="text-muted-foreground">يتوفر توصيل سريع لجميع المنتجات. تواصل معنا لتأكيد موعد التوصيل.</p>
                  </div>
                </div>
                <p className="text-muted-foreground">للاستفسار عن سياسة الاسترجاع والضمان، يرجى التواصل معنا على الواتساب.</p>
              </div>
            )}
          </div>
        </div>

        {/* Related */}
        {related.length > 0 && (
          <section className="mt-10">
            <h2 className="text-xl font-bold mb-4">منتجات مشابهة</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
              {related.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          </section>
        )}
      </div>
    </StoreLayout>
  )
}

function TabButton({ active, children, onClick }: { active: boolean; children: React.ReactNode; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        'px-4 py-3 text-sm font-semibold border-b-2 transition-colors whitespace-nowrap',
        active ? 'border-[var(--ht-blue)] text-[var(--ht-blue)]' : 'border-transparent text-muted-foreground hover:text-foreground',
      )}
    >
      {children}
    </button>
  )
}