// Contact Us page
import { createFileRoute } from '@tanstack/react-router'
import { Clock, Mail, MapPin, Phone, Send } from 'lucide-react'
import { getSettings, getVisibleCategories } from '../lib/store-api'
import { StoreLayout } from '../components/store-layout'
import { Button } from '../components/ui/button'
import type { Settings } from '../lib/types'
import { WhatsappIcon } from '../components/header'

type LoaderData = {
  settings: Settings
  categories: Awaited<ReturnType<typeof getVisibleCategories>>
}

export const Route = createFileRoute('/contact')({
  loader: async (): Promise<LoaderData> => {
    const [settings, categories] = await Promise.all([getSettings(), getVisibleCategories()])
    return { settings, categories }
  },
  component: ContactPage,
  head: () => ({ meta: [{ title: 'اتصل بنا | Hi-Tech' }] }),
})

function ContactPage() {
  const { settings, categories } = Route.useLoaderData() as LoaderData
  return (
    <StoreLayout settings={settings} categories={categories}>
      <section className="bg-gradient-to-r from-[var(--ht-blue)] to-[var(--ht-blue-dark)] text-white">
        <div className="mx-auto max-w-7xl px-4 py-8">
          <h1 className="text-2xl sm:text-3xl font-bold">اتصل بنا</h1>
          <p className="opacity-90 mt-1 text-sm">نحن هنا للإجابة على جميع استفساراتك</p>
        </div>
      </section>

      <div className="mx-auto max-w-6xl px-4 py-8 grid md:grid-cols-2 gap-6">
        <div className="space-y-3">
          <article className="rounded-xl border border-border bg-card p-5 space-y-4">
            <h2 className="font-bold text-lg">{settings.store_name}</h2>
            <p className="text-sm text-muted-foreground">{settings.owner_name}</p>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start gap-3">
                <Phone className="size-5 text-[var(--ht-blue)] mt-0.5" />
                <div>
                  <p className="font-semibold">الهاتف</p>
                  <a href={`tel:${settings.phone}`} className="text-[var(--ht-blue)] hover:underline tabular-nums">
                    {settings.phone}
                  </a>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <WhatsappIcon className="size-5 text-green-500 mt-0.5" />
                <div>
                  <p className="font-semibold">واتساب</p>
                  <a
                    href={`https://wa.me/${settings.whatsapp.replace(/^0/, '20')}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-green-600 hover:underline tabular-nums"
                  >
                    {settings.whatsapp}
                  </a>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <MapPin className="size-5 text-[var(--ht-blue)] mt-0.5" />
                <div>
                  <p className="font-semibold">العنوان</p>
                  <p>{settings.address}</p>
                </div>
              </li>
              {settings.working_hours && (
                <li className="flex items-start gap-3">
                  <Clock className="size-5 text-[var(--ht-blue)] mt-0.5" />
                  <div>
                    <p className="font-semibold">أوقات العمل</p>
                    <p className="text-muted-foreground">{settings.working_hours}</p>
                  </div>
                </li>
              )}
            </ul>
            <div className="grid grid-cols-2 gap-2 pt-2">
              <a
                href={`tel:${settings.phone}`}
                className="flex items-center justify-center gap-2 py-2.5 rounded-md bg-[var(--ht-blue)] text-white font-semibold"
              >
                <Phone className="size-4" /> اتصال
              </a>
              <a
                href={`https://wa.me/${settings.whatsapp.replace(/^0/, '20')}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 py-2.5 rounded-md bg-green-500 text-white font-semibold"
              >
                <Send className="size-4" /> واتساب
              </a>
            </div>
          </article>
        </div>

        <div className="rounded-xl overflow-hidden border border-border bg-card">
          {settings.map_embed ? (
            <iframe
              src={settings.map_embed}
              className="w-full h-80"
              loading="lazy"
              title="موقع المتجر"
            />
          ) : (
            <div className="w-full h-80 bg-muted flex items-center justify-center text-center p-4">
              <div>
                <MapPin className="size-12 mx-auto text-muted-foreground" />
                <p className="mt-2 text-sm text-muted-foreground">
                  {settings.address}
                </p>
                <p className="mt-1 text-xs text-muted-foreground">يمكنك إضافة خريطة Google من لوحة التحكم</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </StoreLayout>
  )
}