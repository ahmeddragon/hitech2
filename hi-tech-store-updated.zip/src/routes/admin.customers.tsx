// Admin Customers
import { createFileRoute } from '@tanstack/react-router'
import { useMemo, useState } from 'react'
import { Search, Trash2 } from 'lucide-react'
import { toast } from 'sonner'
import { deleteCustomerFn } from '../lib/admin'
import { getCustomers } from '../lib/store-api'
import { Button } from '../components/ui/button'
import type { Customer } from '../lib/types'

type LoaderData = { customers: Customer[] }

export const Route = createFileRoute('/admin/customers')({
  loader: async (): Promise<LoaderData> => ({ customers: await getCustomers() }),
  component: AdminCustomers,
})

function AdminCustomers() {
  const { customers } = Route.useLoaderData() as LoaderData
  const [search, setSearch] = useState('')

  const filtered = useMemo(
    () =>
      customers.filter((c) => {
        if (!search.trim()) return true
        const s = search.toLowerCase()
        return [c.name, c.phone, c.address]
          .filter(Boolean)
          .some((v) => String(v).toLowerCase().includes(s))
      }),
    [customers, search],
  )

  const onDelete = async (id: string) => {
    if (!confirm('حذف هذا العميل؟')) return
    await deleteCustomerFn({ data: { id } })
    toast.success('تم الحذف')
    window.location.reload()
  }

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold">العملاء</h1>
        <p className="text-sm text-muted-foreground">{filtered.length} عميل</p>
      </div>

      <div className="relative">
        <Search className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
        <input
          type="search"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="بحث..."
          className="w-full pr-10 pl-3 py-2 rounded-md border border-border bg-card text-sm"
        />
      </div>

      <div className="rounded-xl border border-border bg-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-right">
              <tr>
                <th className="px-3 py-3 font-medium">الاسم</th>
                <th className="px-3 py-3 font-medium">الهاتف</th>
                <th className="px-3 py-3 font-medium">العنوان</th>
                <th className="px-3 py-3 font-medium">الطلبات</th>
                <th className="px-3 py-3 font-medium">إجمالي المشتريات</th>
                <th className="px-3 py-3 font-medium">آخر طلب</th>
                <th className="px-3 py-3 font-medium">إجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-3 py-10 text-center text-muted-foreground">لا يوجد عملاء</td>
                </tr>
              ) : (
                filtered.map((c) => (
                  <tr key={c.id} className="hover:bg-muted/30">
                    <td className="px-3 py-3 font-medium">{c.name}</td>
                    <td className="px-3 py-3 tabular-nums">{c.phone}</td>
                    <td className="px-3 py-3 text-muted-foreground line-clamp-1">{c.address ?? '—'}</td>
                    <td className="px-3 py-3 tabular-nums">{c.total_orders}</td>
                    <td className="px-3 py-3 tabular-nums font-bold">{Number(c.total_spent).toLocaleString('ar-EG')} ج.م</td>
                    <td className="px-3 py-3 text-xs text-muted-foreground">
                      {c.last_order_at ? new Date(c.last_order_at).toLocaleDateString('ar-EG') : '—'}
                    </td>
                    <td className="px-3 py-3">
                      <button onClick={() => onDelete(c.id)} className="p-1.5 rounded hover:bg-red-50 text-red-600">
                        <Trash2 className="size-4" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}