// Admin layout route
// The whole admin area is client-rendered: every admin data request is an
// authenticated server-function call, which needs the browser session.
import { createFileRoute, Outlet } from '@tanstack/react-router'
import { AdminLayout } from '../components/admin-layout'
import { AuthProvider } from '../lib/auth-context'

export const Route = createFileRoute('/admin')({
  ssr: false,
  component: AdminLayoutWrapper,
})

function AdminLayoutWrapper() {
  return (
    <AuthProvider>
      <AdminLayout />
    </AuthProvider>
  )
}
