// Admin Banners Management
import { createFileRoute } from '@tanstack/react-router'
import { useState } from 'react'
import { Edit, Loader2, Plus, Trash2, Upload, X, Image as ImageIcon } from 'lucide-react'
import { toast } from 'sonner'
import { deleteBannerFn, upsertBannerFn } from '../lib/admin'
import { importImageFile } from '../lib/image-upload'
import { getActiveBanners } from '../lib/store-api'
import { Button } from '../components/ui/button'
import type { Banner } from '../lib/types'

type LoaderData = { banners: Banner[] }

export const Route = createFileRoute('/admin/banners')({
  loader: async (): Promise<LoaderData> => ({ banners: await getActiveBanners() }),
  component: AdminBanners,
})

function AdminBanners() {
  const { banners } = Route.useLoaderData() as LoaderData
  const [editing, setEditing] = useState<Banner | null>(null)
  const [creating, setCreating] = useState(false)

  const onDelete = async (b: Banner) => {
    if (!confirm(`حذف البانر "${b.title}"؟`)) return
    await deleteBannerFn({ data: { id: b.id } })
    toast.success('تم الحذف')
    window.location.reload()
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">البانرات</h1>
          <p className="text-sm text-muted-foreground">{banners.length} بانر</p>
        </div>
        <Button onClick={() => setCreating(true)} className="bg-[var(--ht-blue)] hover:bg-[var(--ht-blue-dark)]">
          <Plus className="size-4 ml-1" /> بانر جديد
        </Button>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {banners.map((b) => (
          <article key={b.id} className="rounded-xl border border-border bg-card overflow-hidden">
            <div className="aspect-[16/9] bg-muted relative">
              <img src={b.image_url} alt={b.title} className="size-full object-cover" />
            </div>
            <div className="p-3">
              <h3 className="font-bold line-clamp-1">{b.title}</h3>
              {b.subtitle && <p className="text-xs text-muted-foreground">{b.subtitle}</p>}
              <div className="flex items-center gap-1 mt-3">
                <Button variant="outline" size="sm" onClick={() => setEditing(b)}>
                  <Edit className="size-3.5" />
                </Button>
                <Button variant="outline" size="sm" onClick={() => onDelete(b)} className="text-red-600">
                  <Trash2 className="size-3.5" />
                </Button>
              </div>
            </div>
          </article>
        ))}
      </div>

      {(editing || creating) && (
        <BannerModal
          banner={editing}
          onClose={() => {
            setEditing(null)
            setCreating(false)
          }}
          onSaved={() => window.location.reload()}
        />
      )}
    </div>
  )
}

function BannerModal({ banner, onClose, onSaved }: { banner: Banner | null; onClose: () => void; onSaved: () => void }) {
  const [form, setForm] = useState({
    title: banner?.title ?? '',
    subtitle: banner?.subtitle ?? '',
    description: banner?.description ?? '',
    image_url: banner?.image_url ?? '',
    cta_label: banner?.cta_label ?? '',
    cta_link: banner?.cta_link ?? '',
    sort_order: banner?.sort_order ?? 0,
    is_active: banner?.is_active ?? true,
  })
  const [submitting, setSubmitting] = useState(false)
  const [uploading, setUploading] = useState(false)

  const onPickBannerFile = async (file: File) => {
    setUploading(true)
    try {
      const url = await importImageFile(file)
      setForm((p) => ({ ...p, image_url: url }))
      toast.success('تم رفع صورة البانر')
    } catch (err: any) {
      toast.error(err?.message ?? 'فشل رفع الصورة')
    } finally {
      setUploading(false)
    }
  }

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!form.image_url.trim()) {
      toast.error('يجب إدخال رابط الصورة')
      return
    }
    setSubmitting(true)
    try {
      await upsertBannerFn({
        data: {
          ...(banner?.id ? { id: banner.id } : {}),
          title: form.title,
          subtitle: form.subtitle || null,
          description: form.description || null,
          image_url: form.image_url,
          cta_label: form.cta_label || null,
          cta_link: form.cta_link || null,
          sort_order: form.sort_order,
          is_active: form.is_active,
        } as any,
      })
      toast.success(banner ? 'تم التحديث' : 'تم الإضافة')
      onSaved()
    } catch (e: any) {
      toast.error(e?.message ?? 'فشل')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/50 overflow-y-auto">
      <div className="min-h-full flex items-center justify-center p-4">
        <form onSubmit={onSubmit} className="w-full max-w-lg bg-card rounded-2xl shadow-2xl">
          <div className="border-b border-border p-4 flex items-center justify-between">
            <h2 className="font-bold">{banner ? 'تعديل بانر' : 'بانر جديد'}</h2>
            <button type="button" onClick={onClose} className="p-2 hover:bg-muted rounded">
              <X className="size-5" />
            </button>
          </div>
          <div className="p-5 space-y-4">
            <Field label="العنوان *">
              <input type="text" required value={form.title} onChange={(e) => setForm((p) => ({ ...p, title: e.target.value }))} className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm" />
            </Field>
            <Field label="العنوان الفرعي">
              <input type="text" value={form.subtitle} onChange={(e) => setForm((p) => ({ ...p, subtitle: e.target.value }))} className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm" />
            </Field>
            <Field label="الوصف">
              <textarea rows={2} value={form.description} onChange={(e) => setForm((p) => ({ ...p, description: e.target.value }))} className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm" />
            </Field>
            <Field label="رابط الصورة *">
              <input type="url" required value={form.image_url} onChange={(e) => setForm((p) => ({ ...p, image_url: e.target.value }))} placeholder="https://..." className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm" />
              <label className="mt-2 inline-flex items-center gap-2 cursor-pointer text-sm text-[var(--ht-blue)] hover:underline">
                {uploading ? <Loader2 className="size-4 animate-spin" /> : <Upload className="size-4" />}
                {uploading ? 'جاري الرفع...' : 'أو ارفع صورة من جهازك'}
                <input
                  type="file"
                  accept="image/*"
                  className="hidden"
                  disabled={uploading}
                  onChange={(e) => {
                    const f = e.target.files?.[0]
                    if (f) onPickBannerFile(f)
                    e.target.value = ''
                  }}
                />
              </label>
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="نص الزر">
                <input type="text" value={form.cta_label} onChange={(e) => setForm((p) => ({ ...p, cta_label: e.target.value }))} placeholder="مثال: تصفح" className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm" />
              </Field>
              <Field label="رابط الزر">
                <input type="text" value={form.cta_link} onChange={(e) => setForm((p) => ({ ...p, cta_link: e.target.value }))} placeholder="/category/..." className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm" />
              </Field>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Field label="الترتيب">
                <input type="number" min={0} value={form.sort_order} onChange={(e) => setForm((p) => ({ ...p, sort_order: Number(e.target.value) }))} className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm" />
              </Field>
              <div className="flex items-center pt-6">
                <label className="flex items-center gap-2 text-sm cursor-pointer">
                  <input type="checkbox" checked={form.is_active} onChange={(e) => setForm((p) => ({ ...p, is_active: e.target.checked }))} />
                  نشط
                </label>
              </div>
            </div>
          </div>
          <div className="border-t border-border p-4 flex items-center justify-end gap-2">
            <Button type="button" variant="outline" onClick={onClose}>إلغاء</Button>
            <Button type="submit" disabled={submitting} className="bg-[var(--ht-blue)] hover:bg-[var(--ht-blue-dark)]">{submitting ? '...' : 'حفظ'}</Button>
          </div>
        </form>
      </div>
    </div>
  )
}

function Field({ label, children, required }: { label: string; children: React.ReactNode; required?: boolean }) {
  return (
    <div>
      <label className="block text-sm font-medium mb-1.5">
        {label} {required && <span className="text-red-600">*</span>}
      </label>
      {children}
    </div>
  )
}