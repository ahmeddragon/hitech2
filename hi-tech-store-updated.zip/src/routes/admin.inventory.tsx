// Admin Inventory Management
import { createFileRoute } from '@tanstack/react-router'
import { useMemo, useState } from 'react'
import { Edit, Search } from 'lucide-react'
import { toast } from 'sonner'
import { upsertProductFn } from '../lib/admin'
import { getProducts } from '../lib/store-api'
import { Button } from '../components/ui/button'
import type { Product } from '../lib/types'
import { STOCK_COLORS, STOCK_LABELS, getStockStatus } from '../lib/types'
import { cn } from '../lib/utils'

type LoaderData = { products: Product[] }

export const Route = createFileRoute('/admin/inventory')({
  loader: async (): Promise<LoaderData> => {
    const res = await getProducts({ data: { page_size: 500 } })
    return { products: res.items }
  },
  component: AdminInventory,
})

function AdminInventory() {
  const { products } = Route.useLoaderData() as LoaderData
  const [search, setSearch] = useState('')
  const [filter, setFilter] = useState<'all' | 'low' | 'out' | 'available'>('all')

  const filtered = useMemo(() => {
    return products.filter((p) => {
      if (!search.trim()) return true
      const s = search.toLowerCase()
      if (![p.name, p.sku, p.model].filter(Boolean).some((v) => String(v).toLowerCase().includes(s))) {
        return false
      }
      const stock = getStockStatus(p)
      if (filter === 'low' && stock !== 'limited') return false
      if (filter === 'out' && stock !== 'out_of_stock') return false
      if (filter === 'available' && stock !== 'in_stock') return false
      return true
    })
  }, [products, search, filter])

  const onUpdateStock = async (p: Product, newStock: number) => {
    try {
      await upsertProductFn({ data: { id: p.id, stock: newStock } })
      toast.success(`تم تحديث مخزون "${p.name}"`)
      window.location.reload()
    } catch (e: any) {
      toast.error(e?.message ?? 'فشل')
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold">المخزون</h1>
          <p className="text-sm text-muted-foreground">{filtered.length} منتج</p>
        </div>
      </div>

      <div className="flex gap-2 flex-wrap">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
          <input
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="بحث..."
            className="w-full pr-10 pl-3 py-2 rounded-md border border-border bg-card text-sm"
          />
        </div>
        <select
          value={filter}
          onChange={(e) => setFilter(e.target.value as any)}
          className="px-3 py-2 rounded-md border border-border bg-card text-sm"
        >
          <option value="all">الكل</option>
          <option value="available">متوفر</option>
          <option value="low">كمية محدودة</option>
          <option value="out">نفذ</option>
        </select>
      </div>

      <div className="rounded-xl border border-border bg-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-right">
              <tr>
                <th className="px-3 py-3 font-medium">المنتج</th>
                <th className="px-3 py-3 font-medium">SKU</th>
                <th className="px-3 py-3 font-medium">الكمية</th>
                <th className="px-3 py-3 font-medium">الحد الأدنى</th>
                <th className="px-3 py-3 font-medium">الحالة</th>
                <th className="px-3 py-3 font-medium">إجراء سريع</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-3 py-10 text-center text-muted-foreground">لا توجد نتائج</td>
                </tr>
              ) : (
                filtered.map((p) => {
                  const stock = getStockStatus(p)
                  return (
                    <tr key={p.id} className="hover:bg-muted/30">
                      <td className="px-3 py-3">
                        <div className="flex items-center gap-2">
                          {p.main_image?.url ? (
                            <img src={p.main_image.url} alt="" className="size-8 rounded object-cover" />
                          ) : (
                            <div className="size-8 rounded bg-muted" />
                          )}
                          <span className="line-clamp-1">{p.name}</span>
                        </div>
                      </td>
                      <td className="px-3 py-3 tabular-nums text-muted-foreground">{p.sku ?? '—'}</td>
                      <td className="px-3 py-3 tabular-nums font-bold">{p.stock}</td>
                      <td className="px-3 py-3 tabular-nums text-muted-foreground">{p.low_stock_threshold}</td>
                      <td className="px-3 py-3">
                        <span className={cn('text-xs px-2 py-0.5 rounded border', STOCK_COLORS[stock])}>
                          {STOCK_LABELS[stock]}
                        </span>
                      </td>
                      <td className="px-3 py-3">
                        <div className="flex items-center gap-1">
                          <input
                            type="number"
                            min={0}
                            defaultValue={p.stock}
                            onBlur={(e) => {
                              const v = Number(e.target.value)
                              if (v !== p.stock) onUpdateStock(p, v)
                            }}
                            className="w-20 px-2 py-1 rounded border border-border bg-background text-sm"
                          />
                          <span className="text-xs text-muted-foreground">+1/-1</span>
                          <button
                            type="button"
                            onClick={() => onUpdateStock(p, p.stock + 1)}
                            className="px-2 py-1 rounded bg-green-100 hover:bg-green-200 text-green-700 text-xs"
                          >
                            +
                          </button>
                          <button
                            type="button"
                            onClick={() => onUpdateStock(p, Math.max(0, p.stock - 1))}
                            className="px-2 py-1 rounded bg-red-100 hover:bg-red-200 text-red-700 text-xs"
                          >
                            −
                          </button>
                        </div>
                      </td>
                    </tr>
                  )
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}