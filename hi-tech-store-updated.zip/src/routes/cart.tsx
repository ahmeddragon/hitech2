// Cart page
import { createFileRoute, Link } from '@tanstack/react-router'
import { Minus, Plus, Trash2, ShoppingBag } from 'lucide-react'
import { getSettings, getVisibleCategories } from '../lib/store-api'
import { StoreLayout } from '../components/store-layout'
import { useCart } from '../components/cart-context'
import { Button } from '../components/ui/button'
import type { Settings } from '../lib/types'
import { WhatsappIcon } from '../components/header'

type LoaderData = {
  settings: Settings
  categories: Awaited<ReturnType<typeof getVisibleCategories>>
}

export const Route = createFileRoute('/cart')({
  loader: async (): Promise<LoaderData> => {
    const [settings, categories] = await Promise.all([getSettings(), getVisibleCategories()])
    return { settings, categories }
  },
  component: CartPage,
  head: () => ({ meta: [{ title: 'سلة المشتريات | Hi-Tech' }] }),
})

function CartPage() {
  const { settings, categories } = Route.useLoaderData() as LoaderData
  const { items, updateQuantity, remove, subtotal, discount, total } = useCart()

  return (
    <StoreLayout settings={settings} categories={categories}>
      <div className="mx-auto max-w-5xl px-4 py-6">
        <h1 className="text-2xl font-bold mb-4">سلة المشتريات</h1>
        {items.length === 0 ? (
          <div className="text-center py-20 border border-border rounded-xl bg-card">
            <ShoppingBag className="size-12 mx-auto text-muted-foreground" />
            <p className="mt-3 text-lg">السلة فارغة</p>
            <Link to="/products" className="text-[var(--ht-blue)] hover:underline mt-2 inline-block">
              تصفح المنتجات
            </Link>
          </div>
        ) : (
          <div className="grid lg:grid-cols-[1fr_320px] gap-6">
            <div className="space-y-3">
              {items.map((it) => (
                <div
                  key={it.product_id}
                  className="flex gap-3 p-3 rounded-xl border border-border bg-card"
                >
                  <div className="size-20 sm:size-24 rounded-md overflow-hidden bg-muted shrink-0">
                    {it.image ? (
                      <img src={it.image} alt={it.name} className="size-full object-cover" />
                    ) : (
                      <div className="size-full flex items-center justify-center text-xs text-muted-foreground">
                        لا صورة
                      </div>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <Link
                      to="/product/$slug"
                      params={{ slug: it.slug }}
                      className="font-semibold text-sm leading-5 line-clamp-2 hover:text-[var(--ht-blue)]"
                    >
                      {it.name}
                    </Link>
                    <div className="mt-1 flex items-baseline gap-2 flex-wrap">
                      <span className="font-bold text-[var(--ht-blue)] tabular-nums">
                        {(it.unit_price * it.quantity).toLocaleString('ar-EG')} ج.م
                      </span>
                      {it.original_price && it.original_price > it.unit_price && (
                        <span className="text-xs text-muted-foreground line-through tabular-nums">
                          {(it.original_price * it.quantity).toLocaleString('ar-EG')} ج.م
                        </span>
                      )}
                    </div>
                    <div className="mt-2 flex items-center justify-between gap-2">
                      <div className="flex items-center border border-border rounded-md">
                        <button
                          type="button"
                          onClick={() => updateQuantity(it.product_id, it.quantity - 1)}
                          className="p-1.5 hover:bg-muted"
                          aria-label="إنقاص"
                        >
                          <Minus className="size-3.5" />
                        </button>
                        <span className="px-3 tabular-nums text-sm">{it.quantity}</span>
                        <button
                          type="button"
                          onClick={() => updateQuantity(it.product_id, it.quantity + 1)}
                          disabled={it.quantity >= it.max_stock}
                          className="p-1.5 hover:bg-muted disabled:opacity-50"
                          aria-label="زيادة"
                        >
                          <Plus className="size-3.5" />
                        </button>
                      </div>
                      <button
                        type="button"
                        onClick={() => remove(it.product_id)}
                        className="text-red-600 hover:bg-red-50 p-1.5 rounded-md"
                        aria-label="حذف"
                      >
                        <Trash2 className="size-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <aside className="space-y-3">
              <div className="rounded-xl border border-border bg-card p-4 sticky top-32">
                <h3 className="font-bold mb-3">ملخص الطلب</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center justify-between">
                    <span className="text-muted-foreground">المجموع الفرعي</span>
                    <span className="tabular-nums">{(subtotal + discount).toLocaleString('ar-EG')} ج.م</span>
                  </div>
                  {discount > 0 && (
                    <div className="flex items-center justify-between text-green-600">
                      <span>الخصم</span>
                      <span className="tabular-nums">- {discount.toLocaleString('ar-EG')} ج.م</span>
                    </div>
                  )}
                  <div className="flex items-center justify-between text-lg font-bold pt-2 border-t border-border">
                    <span>الإجمالي</span>
                    <span className="tabular-nums text-[var(--ht-blue)]">
                      {total.toLocaleString('ar-EG')} ج.م
                    </span>
                  </div>
                </div>
                <Link to="/checkout" className="block mt-4">
                  <Button size="lg" className="w-full bg-[var(--ht-blue)] hover:bg-[var(--ht-blue-dark)]">
                    إتمام الطلب عبر واتساب
                  </Button>
                </Link>
                <a
                  href={`https://wa.me/${settings.whatsapp.replace(/^0/, '20')}?text=${encodeURIComponent('مرحبًا Hi-Tech، أرغب في الاستفسار عن المنتجات في سلتي.')}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-2 mt-2 w-full py-2.5 rounded-md border-2 border-[var(--ht-red)] text-[var(--ht-red)] text-sm font-semibold hover:bg-[var(--ht-red)] hover:text-white"
                >
                  <WhatsappIcon className="size-4" /> استفسار سريع
                </a>
              </div>
            </aside>
          </div>
        )}
      </div>
    </StoreLayout>
  )
}