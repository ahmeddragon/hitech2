// Admin Backup & Restore
import { createFileRoute } from '@tanstack/react-router'
import { useRef, useState } from 'react'
import { Database, Download, Upload, AlertTriangle, PackagePlus } from 'lucide-react'
import { toast } from 'sonner'
import { backupDataFn, importProductsFn, restoreDataFn } from '../lib/admin'
import { IMPORT_CATEGORIES, mapRows, type ImportRow, type SkippedRow } from '../lib/import-products'
import { Button } from '../components/ui/button'

export const Route = createFileRoute('/admin/backup')({
  component: AdminBackup,
})

function AdminBackup() {
  const [busy, setBusy] = useState(false)
  const fileInput = useRef<HTMLInputElement>(null)
  const csvInput = useRef<HTMLInputElement>(null)
  const [plan, setPlan] = useState<{ rows: ImportRow[]; skipped: SkippedRow[] } | null>(null)
  const [updateExisting, setUpdateExisting] = useState(true)
  const [progress, setProgress] = useState<string | null>(null)

  const onPickCsv = async (file: File) => {
    try {
      setPlan(mapRows(await file.text()))
    } catch (e: any) {
      setPlan(null)
      toast.error(e?.message ?? 'تعذر قراءة الملف')
    }
  }

  const onRunImport = async () => {
    if (!plan || plan.rows.length === 0) return
    setBusy(true)
    let created = 0
    let updated = 0
    try {
      for (let i = 0; i < plan.rows.length; i += 25) {
        setProgress(`${Math.min(i + 25, plan.rows.length)} / ${plan.rows.length}`)
        const res = await importProductsFn({ data: { rows: plan.rows.slice(i, i + 25), update_existing: updateExisting } })
        created += res.created
        updated += res.updated
      }
      toast.success(`تم: ${created} صنف جديد، ${updated} تحديث سعر/كمية`)
      setPlan(null)
    } catch (e: any) {
      toast.error((e?.message ?? 'فشل الاستيراد') + ` (تم ${created} جديد و${updated} تحديث قبل التوقف — يمكنك إعادة المحاولة بأمان)`)
    } finally {
      setProgress(null)
      setBusy(false)
    }
  }

  const onExport = async () => {
    setBusy(true)
    try {
      const data = await backupDataFn()
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `hitech-backup-${new Date().toISOString().slice(0, 10)}.json`
      document.body.appendChild(a)
      a.click()
      a.remove()
      URL.revokeObjectURL(url)
      toast.success('تم تصدير البيانات')
    } catch (e: any) {
      toast.error(e?.message ?? 'فشل التصدير')
    } finally {
      setBusy(false)
    }
  }

  const onImport = async (file: File) => {
    if (!confirm('استيراد البيانات قد يستبدل البيانات الحالية. هل أنت متأكد؟')) return
    setBusy(true)
    try {
      const text = await file.text()
      const payload = JSON.parse(text)
      await restoreDataFn({ data: { payload, mode: 'replace' } })
      toast.success('تم استيراد البيانات')
      window.location.reload()
    } catch (e: any) {
      toast.error(e?.message ?? 'فشل الاستيراد — تأكد من صحة الملف')
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold">النسخ الاحتياطي والاستعادة</h1>
        <p className="text-sm text-muted-foreground">قم بحفظ واستعادة بيانات متجرك</p>
      </div>

      <div className="rounded-xl border border-border bg-card p-5 space-y-3">
        <div className="flex items-start gap-3">
          <div className="size-10 rounded-lg bg-[var(--ht-blue-light)] text-[var(--ht-blue)] flex items-center justify-center shrink-0">
            <Database className="size-5" />
          </div>
          <div>
            <h2 className="font-bold">تصدير البيانات</h2>
            <p className="text-sm text-muted-foreground">يحفظ ملف JSON يحتوي على كل المنتجات والتصنيفات والعملاء والطلبات والإعدادات.</p>
          </div>
        </div>
        <Button onClick={onExport} disabled={busy} className="bg-[var(--ht-blue)] hover:bg-[var(--ht-blue-dark)]">
          <Download className="size-4 ml-2" /> تصدير الآن
        </Button>
      </div>


      <div className="rounded-xl border border-border bg-card p-5 space-y-3">
        <div className="flex items-start gap-3">
          <div className="size-10 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
            <PackagePlus className="size-5" />
          </div>
          <div>
            <h2 className="font-bold">استيراد الأصناف من برنامج Hi-Tech Pro</h2>
            <p className="text-sm text-muted-foreground">
              صدّر الأصناف من البرنامج (Excel)، افتحه واحفظه كـ CSV UTF-8، ثم ارفعه هنا. الأصناف الجديدة تُضاف بالاسم والوصف والتصنيف،
              والأصناف الموجودة يتحدّث سعرها وكميتها فقط (بدون المساس بالصور والنصوص). سعر الشراء وسعر الجملة لا يُرفعان للموقع.
            </p>
          </div>
        </div>
        <input
          ref={csvInput}
          type="file"
          accept=".csv,text/csv"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0]
            if (f) onPickCsv(f)
            e.target.value = ''
          }}
        />
        <Button onClick={() => csvInput.current?.click()} disabled={busy} variant="outline">
          <Upload className="size-4 ml-2" /> اختر ملف الأصناف (CSV)
        </Button>

        {plan && (
          <div className="space-y-3 pt-2">
            <p className="text-sm">
              جاهز للاستيراد: <b>{plan.rows.length}</b> صنف — تم تخطي <b>{plan.skipped.length}</b>
              {plan.skipped.length > 0 && (
                <span className="text-muted-foreground"> ({plan.skipped.map((s) => `${s.name}: ${s.reason}`).join(' • ')})</span>
              )}
            </p>
            <div className="flex flex-wrap gap-2 text-xs">
              {Object.entries(
                plan.rows.reduce<Record<string, number>>((acc, r) => ((acc[r.category_slug] = (acc[r.category_slug] ?? 0) + 1), acc), {}),
              ).map(([slug, n]) => (
                <span key={slug} className="rounded-full bg-muted px-3 py-1">
                  {IMPORT_CATEGORIES[slug]?.name ?? slug}: {n}
                </span>
              ))}
            </div>
            <div className="max-h-72 overflow-auto rounded-lg border border-border">
              <table className="w-full text-sm">
                <thead className="bg-muted text-right">
                  <tr>
                    <th className="p-2">الكود</th>
                    <th className="p-2">الاسم في الموقع</th>
                    <th className="p-2">التصنيف</th>
                    <th className="p-2">السعر</th>
                    <th className="p-2">الكمية</th>
                  </tr>
                </thead>
                <tbody>
                  {plan.rows.map((r) => (
                    <tr key={r.sku} className="border-t border-border">
                      <td className="p-2 font-mono text-xs">{r.sku}</td>
                      <td className="p-2">{r.name}</td>
                      <td className="p-2">{IMPORT_CATEGORIES[r.category_slug]?.name}</td>
                      <td className="p-2">{r.price}</td>
                      <td className="p-2">{r.stock}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" checked={updateExisting} onChange={(e) => setUpdateExisting(e.target.checked)} />
              تحديث السعر والكمية للأصناف الموجودة في الموقع
            </label>
            <Button onClick={onRunImport} disabled={busy} className="bg-[var(--ht-blue)] hover:bg-[var(--ht-blue-dark)]">
              {progress ? `جاري الاستيراد ${progress}` : `استيراد ${plan.rows.length} صنف`}
            </Button>
          </div>
        )}
      </div>

      <div className="rounded-xl border border-border bg-card p-5 space-y-3">
        <div className="flex items-start gap-3">
          <div className="size-10 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center shrink-0">
            <AlertTriangle className="size-5" />
          </div>
          <div>
            <h2 className="font-bold">استيراد البيانات</h2>
            <p className="text-sm text-muted-foreground">يستبدل كل البيانات الحالية بالبيانات الموجودة في الملف. استخدمه عند الاستعادة من نسخة احتياطية.</p>
          </div>
        </div>
        <input
          ref={fileInput}
          type="file"
          accept="application/json"
          onChange={(e) => {
            const file = e.target.files?.[0]
            if (file) onImport(file)
            e.target.value = ''
          }}
          className="hidden"
        />
        <Button onClick={() => fileInput.current?.click()} disabled={busy} variant="outline">
          <Upload className="size-4 ml-2" /> اختر ملف للاستيراد
        </Button>
      </div>
    </div>
  )
}