// Admin login page (with first-run account setup + invited-admin sign up)
import { createFileRoute, Link, useNavigate } from '@tanstack/react-router'
import { useEffect, useState } from 'react'
import { Eye, EyeOff, Loader2, Lock, Mail, Shield, UserPlus } from 'lucide-react'
import { toast } from 'sonner'
import { adminStatusFn, resolveAdminSessionFn } from '../lib/admin'
import { nubase } from '../integrations/nubase'
import { Logo } from '../components/header'
import { Button } from '../components/ui/button'
import { useAuth } from '../lib/auth-context'

export const Route = createFileRoute('/admin/login')({
  component: AdminLoginPage,
  head: () => ({ meta: [{ title: 'تسجيل دخول الأدمن | Hi-Tech' }] }),
})

function AdminLoginPage() {
  const navigate = useNavigate()
  const { setSession } = useAuth()
  const [needsSetup, setNeedsSetup] = useState<boolean | null>(null)
  const [mode, setMode] = useState<'login' | 'signup'>('login')
  // Lets an owner who already created their account switch from the first-run
  // setup form to sign-in without signing up again.
  const [forceLogin, setForceLogin] = useState(false)

  useEffect(() => {
    let alive = true
    adminStatusFn()
      .then((res) => {
        if (alive) setNeedsSetup(!res.hasAdmin)
      })
      .catch(() => {
        if (alive) setNeedsSetup(false)
      })
    return () => {
      alive = false
    }
  }, [])

  const finish = (email: string, id: string, record: any) => {
    setSession({ email, id, record }, nubase.auth.getAccessToken())
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[var(--ht-blue)] via-[var(--ht-blue-dark)] to-[var(--ht-red-dark)] flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-card rounded-2xl shadow-2xl p-8 animate-fade-in">
        <div className="flex flex-col items-center text-center mb-6">
          <div className="flex items-center gap-2 mb-2">
            <Logo size={48} />
            <span className="font-bold text-2xl gradient-ht">Hi-Tech</span>
          </div>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Shield className="size-4" />
            <span>{needsSetup ? 'إعداد حساب المدير الأول' : 'لوحة تحكم الأدمن'}</span>
          </div>
        </div>

        {needsSetup === null ? (
          <div className="flex items-center justify-center py-10 text-muted-foreground">
            <Loader2 className="size-5 animate-spin ml-2" /> جاري التحميل...
          </div>
        ) : needsSetup && !forceLogin ? (
          <SignUpForm
            isFirstAdmin
            onDone={(email, id, record) => {
              finish(email, id, record)
              toast.success('تم إنشاء حساب المدير بنجاح')
              navigate({ to: '/admin' })
            }}
            onBack={() => setForceLogin(true)}
          />
        ) : mode === 'signup' ? (
          <SignUpForm
            onDone={(email, id, record) => {
              finish(email, id, record)
              toast.success('تم تسجيل الدخول بنجاح')
              navigate({ to: '/admin' })
            }}
            onBack={() => setMode('login')}
          />
        ) : (
          <LoginForm
            onDone={(email, id, record) => {
              finish(email, id, record)
              toast.success('تم تسجيل الدخول بنجاح')
              navigate({ to: '/admin' })
            }}
            onSignUp={() => setMode('signup')}
          />
        )}

        <div className="mt-6 text-center">
          <Link to="/" className="text-sm text-muted-foreground hover:text-foreground">
            ← العودة إلى المتجر
          </Link>
        </div>
      </div>
    </div>
  )
}

function LoginForm({
  onDone,
  onSignUp,
}: {
  onDone: (email: string, id: string, record: any) => void
  onSignUp: () => void
}) {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    setSubmitting(true)
    try {
      const { data, error: authError } = await nubase.auth.signInWithPassword({
        email: email.trim(),
        password,
      })
      if (authError || !data.session) {
        throw new Error(nubase.auth.describeError(authError, 'البريد الإلكتروني أو كلمة المرور غير صحيحة'))
      }
      try {
        const res = await resolveAdminSessionFn()
        onDone(res.user.email, res.user.id, res.record)
      } catch (gateError: any) {
        await nubase.auth.signOut().catch(() => {})
        throw gateError
      }
    } catch (err: any) {
      const msg = err?.message ?? 'فشل تسجيل الدخول. تأكد من البريد وكلمة المرور.'
      setError(msg)
      toast.error(msg)
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <form onSubmit={onSubmit} className="space-y-4">
      <div>
        <label className="block text-sm font-medium mb-1.5">البريد الإلكتروني</label>
        <div className="relative">
          <Mail className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
          <input
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="admin@hi-tech.com"
            className="w-full pr-10 pl-3 py-2.5 rounded-md border border-border bg-background text-sm"
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium mb-1.5">كلمة المرور</label>
        <div className="relative">
          <Lock className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
          <input
            type={showPassword ? 'text' : 'password'}
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full pr-10 pl-10 py-2.5 rounded-md border border-border bg-background text-sm"
          />
          <button
            type="button"
            onClick={() => setShowPassword(!showPassword)}
            className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
            aria-label="إظهار/إخفاء"
          >
            {showPassword ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
          </button>
        </div>
      </div>

      {error && (
        <div className="text-sm text-red-600 bg-red-50 border border-red-200 rounded-md p-3">{error}</div>
      )}

      <Button type="submit" size="lg" disabled={submitting} className="w-full bg-[var(--ht-blue)] hover:bg-[var(--ht-blue-dark)]">
        {submitting ? (
          <>
            <Loader2 className="size-4 ml-2 animate-spin" /> جاري التحقق...
          </>
        ) : (
          <>
            <Lock className="size-4 ml-2" /> تسجيل الدخول
          </>
        )}
      </Button>

      <button
        type="button"
        onClick={onSignUp}
        className="w-full text-center text-sm text-[var(--ht-blue)] hover:underline"
      >
        تمت دعوتك كمدير؟ أنشئ كلمة المرور الخاصة بك
      </button>
    </form>
  )
}

function SignUpForm({
  onDone,
  onBack,
  isFirstAdmin,
}: {
  onDone: (email: string, id: string, record: any) => void
  onBack?: () => void
  isFirstAdmin?: boolean
}) {
  const [fullName, setFullName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [confirm, setConfirm] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [checkEmail, setCheckEmail] = useState<string | null>(null)

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    if (password.length < 8) {
      setError('كلمة المرور يجب أن تكون 8 أحرف على الأقل')
      return
    }
    if (password !== confirm) {
      setError('كلمتا المرور غير متطابقتين')
      return
    }
    setSubmitting(true)
    try {
      const result = await nubase.auth.signUpWithEmailVerification({
        email: email.trim(),
        password,
        options: { data: { full_name: fullName.trim() || null } },
      })

      if (result.status === 'error') {
        throw new Error(result.message ?? 'فشل إنشاء الحساب')
      }

      if (result.status === 'verification_required') {
        setCheckEmail(result.email ?? email.trim())
        return
      }

      // Signed in — resolve admin access. When the dashboard has not been set
      // up yet this promotes the just-verified account to the first admin;
      // otherwise it only lets accounts already on the admin list through.
      const res = await resolveAdminSessionFn()

      onDone(res.user.email, res.user.id, res.record)
    } catch (err: any) {
      // Drop any stale session so the next attempt starts from a fresh token.
      await nubase.auth.signOut().catch(() => {})
      const raw = err?.message ?? 'فشل إنشاء الحساب'
      const msg = /already|registered|موجود|مسجّل|مسجل/i.test(raw)
        ? 'هذا البريد مُسجَّل بالفعل. استخدم زر «لديك حساب بالفعل؟ سجّل الدخول» بالأسفل.'
        : raw
      setError(msg)
      toast.error(msg)
    } finally {
      setSubmitting(false)
    }
  }

  if (checkEmail) {
    return (
      <div className="space-y-4">
        <div className="text-sm bg-emerald-50 border border-emerald-200 text-emerald-900 rounded-md p-4 leading-relaxed">
          أرسلنا رابط تأكيد إلى <span className="font-semibold">{checkEmail}</span>. افتح بريدك واضغط على الرابط،
          ثم عد إلى هذه الصفحة وسجّل الدخول.
        </div>
        {onBack && (
          <Button type="button" variant="outline" className="w-full" onClick={onBack}>
            {isFirstAdmin ? 'أكّدت بريدك بالفعل؟ سجّل الدخول من هنا' : 'العودة لتسجيل الدخول'}
          </Button>
        )}
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <div className="text-sm bg-blue-50 border border-blue-200 text-blue-900 rounded-md p-3 leading-relaxed">
        {isFirstAdmin
          ? 'هذه أول مرة يتم فيها تشغيل لوحة التحكم. أنشئ حساب المدير الخاص بك الآن، وستستخدمه بعد ذلك لتسجيل الدخول وإدارة المنتجات والطلبات.'
          : 'أنشئ كلمة المرور لحسابك. يجب أن يكون بريدك الإلكتروني مضافًا مسبقًا من قِبل مدير النظام لتتمكن من الدخول.'}
      </div>

      <form onSubmit={onSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium mb-1.5">الاسم</label>
          <input
            type="text"
            value={fullName}
            onChange={(e) => setFullName(e.target.value)}
            placeholder="م / أحمد أبو النجا"
            className="w-full px-3 py-2.5 rounded-md border border-border bg-background text-sm"
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1.5">البريد الإلكتروني</label>
          <input
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full px-3 py-2.5 rounded-md border border-border bg-background text-sm"
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1.5">كلمة المرور</label>
          <div className="relative">
            <input
              type={showPassword ? 'text' : 'password'}
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-3 py-2.5 rounded-md border border-border bg-background text-sm"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              aria-label="إظهار/إخفاء"
            >
              {showPassword ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
            </button>
          </div>
        </div>
        <div>
          <label className="block text-sm font-medium mb-1.5">تأكيد كلمة المرور</label>
          <input
            type={showPassword ? 'text' : 'password'}
            required
            value={confirm}
            onChange={(e) => setConfirm(e.target.value)}
            className="w-full px-3 py-2.5 rounded-md border border-border bg-background text-sm"
          />
        </div>

        {error && (
          <div className="text-sm text-red-600 bg-red-50 border border-red-200 rounded-md p-3">{error}</div>
        )}

        <Button type="submit" size="lg" disabled={submitting} className="w-full bg-[var(--ht-red)] hover:bg-[var(--ht-red-dark)]">
          {submitting ? (
            <>
              <Loader2 className="size-4 ml-2 animate-spin" /> جاري الإنشاء...
            </>
          ) : (
            <>
              <UserPlus className="size-4 ml-2" /> إنشاء الحساب
            </>
          )}
        </Button>

        {onBack && (
          <button
            type="button"
            onClick={onBack}
            className="w-full text-center text-sm text-muted-foreground hover:text-foreground"
          >
            لديك حساب بالفعل؟ سجّل الدخول
          </button>
        )}
      </form>
    </div>
  )
}
