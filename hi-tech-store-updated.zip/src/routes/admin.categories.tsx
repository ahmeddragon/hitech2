// Admin Categories Management
import { createFileRoute, Link } from '@tanstack/react-router'
import { useState } from 'react'
import { Edit, Plus, Search, Trash2, X, Eye, EyeOff, ChevronUp, ChevronDown } from 'lucide-react'
import { toast } from 'sonner'
import { deleteCategoryFn, upsertCategoryFn } from '../lib/admin'
import { getCategories } from '../lib/store-api'
import { Button } from '../components/ui/button'
import type { Category, FilterGroup } from '../lib/types'

type LoaderData = { categories: Category[] }

export const Route = createFileRoute('/admin/categories')({
  loader: async (): Promise<LoaderData> => {
    const categories = await getCategories()
    return { categories }
  },
  component: AdminCategories,
})

function AdminCategories() {
  const { categories } = Route.useLoaderData() as LoaderData
  const [search, setSearch] = useState('')
  const [editing, setEditing] = useState<Category | null>(null)
  const [creating, setCreating] = useState(false)
  const [list, setList] = useState(categories)

  const filtered = list.filter((c) => !search || c.name.includes(search))

  const onDelete = async (c: Category) => {
    if (!confirm(`حذف "${c.name}"؟`)) return
    await deleteCategoryFn({ data: { id: c.id } })
    toast.success('تم الحذف')
    setList(list.filter((x) => x.id !== c.id))
  }

  const move = async (idx: number, direction: -1 | 1) => {
    const next = [...list]
    const target = next[idx + direction]
    if (!target) return
    next[idx] = target
    next[idx + direction] = list[idx]
    setList(next)
    await upsertCategoryFn({ data: { id: list[idx].id, sort_order: idx + direction } })
    await upsertCategoryFn({ data: { id: target.id, sort_order: idx } })
    toast.success('تم تحديث الترتيب')
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold">التصنيفات</h1>
          <p className="text-sm text-muted-foreground">{list.length} تصنيف</p>
        </div>
        <Button onClick={() => setCreating(true)} className="bg-[var(--ht-blue)] hover:bg-[var(--ht-blue-dark)]">
          <Plus className="size-4 ml-1" /> تصنيف جديد
        </Button>
      </div>

      <div className="relative">
        <Search className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
        <input
          type="search"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="بحث..."
          className="w-full pr-10 pl-3 py-2 rounded-md border border-border bg-card text-sm"
        />
      </div>

      <div className="rounded-xl border border-border bg-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-right">
              <tr>
                <th className="px-3 py-3 font-medium">الاسم</th>
                <th className="px-3 py-3 font-medium">Slug</th>
                <th className="px-3 py-3 font-medium">الترتيب</th>
                <th className="px-3 py-3 font-medium">الحالة</th>
                <th className="px-3 py-3 font-medium">إجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {filtered.map((c, idx) => (
                <tr key={c.id} className="hover:bg-muted/30">
                  <td className="px-3 py-3">
                    <div className="flex items-center gap-2">
                      {c.image_url ? (
                        <img src={c.image_url} alt="" className="size-8 rounded object-cover" />
                      ) : (
                        <div className="size-8 rounded bg-muted" />
                      )}
                      <div>
                        <p className="font-medium">{c.name}</p>
                        {c.description && <p className="text-xs text-muted-foreground line-clamp-1">{c.description}</p>}
                      </div>
                    </div>
                  </td>
                  <td className="px-3 py-3 text-muted-foreground text-xs">{c.slug}</td>
                  <td className="px-3 py-3">
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => move(idx, -1)}
                        disabled={idx === 0}
                        className="p-1 rounded hover:bg-muted disabled:opacity-30"
                      >
                        <ChevronUp className="size-4" />
                      </button>
                      <span className="tabular-nums">{idx + 1}</span>
                      <button
                        type="button"
                        onClick={() => move(idx, 1)}
                        disabled={idx === list.length - 1}
                        className="p-1 rounded hover:bg-muted disabled:opacity-30"
                      >
                        <ChevronDown className="size-4" />
                      </button>
                    </div>
                  </td>
                  <td className="px-3 py-3">
                    <span
                      className={`text-xs px-2 py-0.5 rounded ${
                        c.is_visible ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-600'
                      }`}
                    >
                      {c.is_visible ? 'ظاهر' : 'مخفي'}
                    </span>
                    {c.is_featured && (
                      <span className="text-xs px-2 py-0.5 rounded bg-amber-100 text-amber-800 mr-1">مميز</span>
                    )}
                  </td>
                  <td className="px-3 py-3">
                    <div className="flex items-center gap-1">
                      <Link to="/category/$slug" params={{ slug: c.slug }} target="_blank" className="p-1.5 rounded hover:bg-muted">
                        <Eye className="size-4" />
                      </Link>
                      <button onClick={() => setEditing(c)} className="p-1.5 rounded hover:bg-muted text-[var(--ht-blue)]">
                        <Edit className="size-4" />
                      </button>
                      <button onClick={() => onDelete(c)} className="p-1.5 rounded hover:bg-red-50 text-red-600">
                        <Trash2 className="size-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {(editing || creating) && (
        <CategoryModal
          category={editing}
          onClose={() => {
            setEditing(null)
            setCreating(false)
          }}
          onSaved={() => window.location.reload()}
        />
      )}
    </div>
  )
}

function CategoryModal({ category, onClose, onSaved }: { category: Category | null; onClose: () => void; onSaved: () => void }) {
  const [form, setForm] = useState({
    name: category?.name ?? '',
    slug: category?.slug ?? '',
    description: category?.description ?? '',
    image_url: category?.image_url ?? '',
    sort_order: category?.sort_order ?? 0,
    is_visible: category?.is_visible ?? true,
    is_featured: category?.is_featured ?? false,
    filter_schema: (category?.filter_schema ?? []) as FilterGroup[],
  })
  const [submitting, setSubmitting] = useState(false)

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitting(true)
    try {
      await upsertCategoryFn({
        data: {
          ...(category?.id ? { id: category.id } : {}),
          name: form.name,
          slug: form.slug || form.name.toLowerCase().replace(/\s+/g, '-').replace(/[^\p{L}\p{N}-]/gu, ''),
          description: form.description || null,
          image_url: form.image_url || null,
          sort_order: form.sort_order,
          is_visible: form.is_visible,
          is_featured: form.is_featured,
          filter_schema: form.filter_schema.filter((g) => g.key.trim() && g.label.trim()),
        } as any,
      })
      toast.success(category ? 'تم التحديث' : 'تم الإضافة')
      onSaved()
    } catch (e: any) {
      toast.error(e?.message ?? 'فشل الحفظ')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/50 overflow-y-auto">
      <div className="min-h-full flex items-center justify-center p-4">
        <form onSubmit={onSubmit} className="w-full max-w-2xl bg-card rounded-2xl shadow-2xl">
          <div className="border-b border-border p-4 flex items-center justify-between">
            <h2 className="font-bold text-lg">{category ? 'تعديل تصنيف' : 'تصنيف جديد'}</h2>
            <button type="button" onClick={onClose} className="p-2 hover:bg-muted rounded">
              <X className="size-5" />
            </button>
          </div>
          <div className="p-5 space-y-4">
            <Field label="الاسم" required>
              <input
                type="text"
                required
                value={form.name}
                onChange={(e) => setForm((p) => ({ ...p, name: e.target.value, slug: p.slug || e.target.value.toLowerCase().replace(/\s+/g, '-') }))}
                className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm"
              />
            </Field>
            <Field label="Slug">
              <input
                type="text"
                value={form.slug}
                onChange={(e) => setForm((p) => ({ ...p, slug: e.target.value }))}
                className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm text-left dir-ltr"
              />
            </Field>
            <Field label="الوصف">
              <textarea
                rows={2}
                value={form.description}
                onChange={(e) => setForm((p) => ({ ...p, description: e.target.value }))}
                className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm"
              />
            </Field>
            <Field label="رابط الصورة">
              <input
                type="url"
                value={form.image_url}
                onChange={(e) => setForm((p) => ({ ...p, image_url: e.target.value }))}
                placeholder="https://..."
                className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm"
              />
            </Field>
            <div className="flex gap-4 text-sm">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={form.is_visible}
                  onChange={(e) => setForm((p) => ({ ...p, is_visible: e.target.checked }))}
                />
                ظاهر
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={form.is_featured}
                  onChange={(e) => setForm((p) => ({ ...p, is_featured: e.target.checked }))}
                />
                مميز
              </label>
            </div>

            <FilterSchemaEditor
              value={form.filter_schema}
              onChange={(v) => setForm((p) => ({ ...p, filter_schema: v }))}
            />
          </div>
          <div className="border-t border-border p-4 flex items-center justify-end gap-2">
            <Button type="button" variant="outline" onClick={onClose}>إلغاء</Button>
            <Button type="submit" disabled={submitting} className="bg-[var(--ht-blue)] hover:bg-[var(--ht-blue-dark)]">
              {submitting ? '...' : 'حفظ'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  )
}

function Field({ label, children, required }: { label: string; children: React.ReactNode; required?: boolean }) {
  return (
    <div>
      <label className="block text-sm font-medium mb-1.5">
        {label} {required && <span className="text-red-600">*</span>}
      </label>
      {children}
    </div>
  )
}

function FilterSchemaEditor({ value, onChange }: { value: FilterGroup[]; onChange: (v: FilterGroup[]) => void }) {
  const update = (i: number, patch: Partial<FilterGroup>) =>
    onChange(value.map((g, idx) => (idx === i ? { ...g, ...patch } : g)))
  const addGroup = () => onChange([...value, { key: '', label: '', type: 'checkbox', options: [] }])
  const removeGroup = (i: number) => onChange(value.filter((_, idx) => idx !== i))
  const addOption = (i: number) => update(i, { options: [...(value[i].options ?? []), { value: '', label: '' }] })
  const updateOption = (i: number, j: number, patch: { value?: string; label?: string }) =>
    update(i, { options: (value[i].options ?? []).map((o, idx) => (idx === j ? { ...o, ...patch } : o)) })
  const removeOption = (i: number, j: number) =>
    update(i, { options: (value[i].options ?? []).filter((_, idx) => idx !== j) })

  return (
    <div className="rounded-lg border border-border p-3 space-y-3 bg-muted/30">
      <div className="flex items-start justify-between gap-2">
        <div>
          <h4 className="font-semibold text-sm">فلاتر القسم (خصائص المنتجات)</h4>
          <p className="text-xs text-muted-foreground mt-0.5 leading-5">
            أضف مجموعات فلترة تظهر لعملائك في صفحة هذا القسم، مثل: المعالج، الرامات، دقة الكاميرا.
          </p>
        </div>
        <Button type="button" size="sm" variant="outline" onClick={addGroup} className="shrink-0">
          <Plus className="size-3.5 ml-1" /> مجموعة
        </Button>
      </div>

      {value.length === 0 && (
        <p className="text-xs text-muted-foreground text-center py-2">
          لا توجد فلاتر بعد — يمكنك إضافتها الآن أو لاحقًا.
        </p>
      )}

      {value.map((group, i) => (
        <div key={i} className="rounded-md border border-border bg-card p-3 space-y-2">
          <div className="flex items-center gap-2">
            <input
              type="text"
              value={group.label}
              onChange={(e) => update(i, { label: e.target.value })}
              placeholder="اسم الفلتر (مثال: المعالج)"
              className="flex-1 px-2 py-1.5 rounded-md border border-border bg-background text-sm"
            />
            <button
              type="button"
              onClick={() => removeGroup(i)}
              aria-label="حذف المجموعة"
              className="p-1.5 rounded hover:bg-red-50 text-red-600 shrink-0"
            >
              <Trash2 className="size-4" />
            </button>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <input
              type="text"
              value={group.key}
              onChange={(e) => update(i, { key: e.target.value.replace(/\s+/g, '_') })}
              placeholder="المفتاح (cpu)"
              className="px-2 py-1.5 rounded-md border border-border bg-background text-sm text-left dir-ltr"
            />
            <select
              value={group.type}
              onChange={(e) => update(i, { type: e.target.value as FilterGroup['type'] })}
              className="px-2 py-1.5 rounded-md border border-border bg-background text-sm"
            >
              <option value="checkbox">اختيار متعدد</option>
              <option value="select">اختيار واحد</option>
              <option value="range">نطاق رقمي</option>
            </select>
          </div>

          {group.type === 'range' ? (
            <div className="grid grid-cols-3 gap-2">
              <input
                type="number"
                value={group.min ?? ''}
                onChange={(e) => update(i, { min: e.target.value ? Number(e.target.value) : undefined })}
                placeholder="الحد الأدنى"
                className="px-2 py-1.5 rounded-md border border-border bg-background text-sm"
              />
              <input
                type="number"
                value={group.max ?? ''}
                onChange={(e) => update(i, { max: e.target.value ? Number(e.target.value) : undefined })}
                placeholder="الحد الأقصى"
                className="px-2 py-1.5 rounded-md border border-border bg-background text-sm"
              />
              <input
                type="text"
                value={group.unit ?? ''}
                onChange={(e) => update(i, { unit: e.target.value })}
                placeholder="الوحدة (ج.م)"
                className="px-2 py-1.5 rounded-md border border-border bg-background text-sm"
              />
            </div>
          ) : (
            <div className="space-y-2">
              {(group.options ?? []).map((opt, j) => (
                <div key={j} className="flex items-center gap-2">
                  <input
                    type="text"
                    value={opt.label}
                    onChange={(e) => updateOption(i, j, { label: e.target.value, value: opt.value || e.target.value } as any)}
                    placeholder="يظهر للعميل (Intel Core i5)"
                    className="flex-1 px-2 py-1.5 rounded-md border border-border bg-background text-sm"
                  />
                  <button
                    type="button"
                    onClick={() => removeOption(i, j)}
                    aria-label="حذف الخيار"
                    className="p-1 rounded hover:bg-red-50 text-red-600 shrink-0"
                  >
                    <X className="size-3.5" />
                  </button>
                </div>
              ))}
              <button
                type="button"
                onClick={() => addOption(i)}
                className="text-xs text-[var(--ht-blue)] hover:underline"
              >
                + إضافة خيار
              </button>
            </div>
          )}
        </div>
      ))}
    </div>
  )
}