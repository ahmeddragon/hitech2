// Admin Settings
import { createFileRoute } from '@tanstack/react-router'
import { useState } from 'react'
import { Facebook, Instagram, MapPin, Save, Youtube } from 'lucide-react'
import { toast } from 'sonner'
import { updateSettingsFn } from '../lib/admin'
import { getSettings } from '../lib/store-api'
import { Button } from '../components/ui/button'
import type { Settings } from '../lib/types'

type LoaderData = { settings: Settings }

export const Route = createFileRoute('/admin/settings')({
  loader: async (): Promise<LoaderData> => ({ settings: await getSettings() }),
  component: AdminSettings,
})

function AdminSettings() {
  const { settings } = Route.useLoaderData() as LoaderData
  const [form, setForm] = useState({
    store_name: settings.store_name,
    store_description: settings.store_description ?? '',
    owner_name: settings.owner_name ?? '',
    phone: settings.phone,
    whatsapp: settings.whatsapp,
    address: settings.address,
    working_hours: settings.working_hours ?? '',
    logo_url: settings.logo_url ?? '',
    favicon_url: settings.favicon_url ?? '',
    facebook_url: settings.facebook_url ?? '',
    instagram_url: settings.instagram_url ?? '',
    tiktok_url: settings.tiktok_url ?? '',
    youtube_url: settings.youtube_url ?? '',
    meta_title: settings.meta_title ?? '',
    meta_description: settings.meta_description ?? '',
    map_embed: settings.map_embed ?? '',
    about_content: settings.about_content ?? '',
    whatsapp_default_message: settings.whatsapp_default_message ?? '',
    order_receipt_header: settings.order_receipt_header ?? '',
  })
  const [submitting, setSubmitting] = useState(false)

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitting(true)
    try {
      await updateSettingsFn({ data: form as any })
      toast.success('تم حفظ الإعدادات')
    } catch (err: any) {
      toast.error(err?.message ?? 'فشل الحفظ')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold">إعدادات الموقع</h1>
        <p className="text-sm text-muted-foreground">المعلومات الأساسية للمتجر</p>
      </div>

      <form onSubmit={onSubmit} className="space-y-4">
        <section className="rounded-xl border border-border bg-card p-5 space-y-4">
          <h2 className="font-bold">المعلومات الأساسية</h2>
          <Field label="اسم المتجر" required>
            <input type="text" required value={form.store_name} onChange={(e) => setForm((p) => ({ ...p, store_name: e.target.value }))} className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm" />
          </Field>
          <Field label="الوصف">
            <input type="text" value={form.store_description} onChange={(e) => setForm((p) => ({ ...p, store_description: e.target.value }))} className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm" />
          </Field>
          <Field label="اسم المالك">
            <input type="text" value={form.owner_name} onChange={(e) => setForm((p) => ({ ...p, owner_name: e.target.value }))} className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm" />
          </Field>
        </section>

        <section className="rounded-xl border border-border bg-card p-5 space-y-4">
          <h2 className="font-bold">التواصل</h2>
          <div className="grid sm:grid-cols-2 gap-3">
            <Field label="رقم الهاتف" required>
              <input type="tel" required value={form.phone} onChange={(e) => setForm((p) => ({ ...p, phone: e.target.value }))} className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm tabular-nums" />
            </Field>
            <Field label="رقم واتساب" required>
              <input type="tel" required value={form.whatsapp} onChange={(e) => setForm((p) => ({ ...p, whatsapp: e.target.value }))} className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm tabular-nums" />
            </Field>
          </div>
          <Field label="العنوان">
            <input type="text" value={form.address} onChange={(e) => setForm((p) => ({ ...p, address: e.target.value }))} className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm" />
          </Field>
          <Field label="أوقات العمل">
            <input type="text" value={form.working_hours} onChange={(e) => setForm((p) => ({ ...p, working_hours: e.target.value }))} className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm" />
          </Field>
          <Field label="رسالة واتساب الافتراضية">
            <input type="text" value={form.whatsapp_default_message} onChange={(e) => setForm((p) => ({ ...p, whatsapp_default_message: e.target.value }))} className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm" />
          </Field>
          <Field label="عنوان إيصال الطلب">
            <input type="text" value={form.order_receipt_header} onChange={(e) => setForm((p) => ({ ...p, order_receipt_header: e.target.value }))} className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm" />
          </Field>
        </section>

        <section className="rounded-xl border border-border bg-card p-5 space-y-4">
          <h2 className="font-bold">السوشيال ميديا</h2>
          <div className="grid sm:grid-cols-2 gap-3">
            <Field label={<span className="flex items-center gap-1"><Facebook className="size-3.5" /> Facebook</span>}>
              <input type="url" value={form.facebook_url} onChange={(e) => setForm((p) => ({ ...p, facebook_url: e.target.value }))} className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm" />
            </Field>
            <Field label={<span className="flex items-center gap-1"><Instagram className="size-3.5" /> Instagram</span>}>
              <input type="url" value={form.instagram_url} onChange={(e) => setForm((p) => ({ ...p, instagram_url: e.target.value }))} className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm" />
            </Field>
            <Field label="TikTok">
              <input type="url" value={form.tiktok_url} onChange={(e) => setForm((p) => ({ ...p, tiktok_url: e.target.value }))} className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm" />
            </Field>
            <Field label={<span className="flex items-center gap-1"><Youtube className="size-3.5" /> YouTube</span>}>
              <input type="url" value={form.youtube_url} onChange={(e) => setForm((p) => ({ ...p, youtube_url: e.target.value }))} className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm" />
            </Field>
          </div>
        </section>

        <section className="rounded-xl border border-border bg-card p-5 space-y-4">
          <h2 className="font-bold">SEO والظهور</h2>
          <Field label="Meta Title">
            <input type="text" value={form.meta_title} onChange={(e) => setForm((p) => ({ ...p, meta_title: e.target.value }))} className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm" />
          </Field>
          <Field label="Meta Description">
            <textarea rows={2} value={form.meta_description} onChange={(e) => setForm((p) => ({ ...p, meta_description: e.target.value }))} className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm" />
          </Field>
          <Field label="Logo URL">
            <input type="url" value={form.logo_url} onChange={(e) => setForm((p) => ({ ...p, logo_url: e.target.value }))} className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm" />
          </Field>
          <Field label="Favicon URL">
            <input type="url" value={form.favicon_url} onChange={(e) => setForm((p) => ({ ...p, favicon_url: e.target.value }))} className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm" />
          </Field>
        </section>

        <section className="rounded-xl border border-border bg-card p-5 space-y-4">
          <h2 className="font-bold flex items-center gap-2"><MapPin className="size-4" /> صفحة "من نحن" و"اتصل بنا"</h2>
          <Field label="محتوى صفحة من نحن">
            <textarea rows={5} value={form.about_content} onChange={(e) => setForm((p) => ({ ...p, about_content: e.target.value }))} className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm" />
          </Field>
          <Field label="كود تضمين خريطة Google (iframe)">
            <textarea rows={3} value={form.map_embed} onChange={(e) => setForm((p) => ({ ...p, map_embed: e.target.value }))} placeholder='<iframe src="..." />' className="w-full px-3 py-2 rounded-md border border-border bg-background text-sm font-mono text-left dir-ltr" />
          </Field>
        </section>

        <div className="flex justify-end">
          <Button type="submit" disabled={submitting} size="lg" className="bg-[var(--ht-blue)] hover:bg-[var(--ht-blue-dark)]">
            <Save className="size-4 ml-2" /> {submitting ? 'جاري الحفظ...' : 'حفظ الإعدادات'}
          </Button>
        </div>
      </form>
    </div>
  )
}

function Field({ label, children, required }: { label: React.ReactNode; children: React.ReactNode; required?: boolean }) {
  return (
    <div>
      <label className="block text-sm font-medium mb-1.5">
        {label} {required && <span className="text-red-600">*</span>}
      </label>
      {children}
    </div>
  )
}