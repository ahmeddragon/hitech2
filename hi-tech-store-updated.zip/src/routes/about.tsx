// About Us page
import { createFileRoute, Link } from '@tanstack/react-router'
import { Award, Clock, MapPin, Phone, ThumbsUp, Users } from 'lucide-react'
import { getSettings, getVisibleCategories } from '../lib/store-api'
import { StoreLayout } from '../components/store-layout'
import type { Settings } from '../lib/types'
import { WhatsappIcon } from '../components/header'

type LoaderData = {
  settings: Settings
  categories: Awaited<ReturnType<typeof getVisibleCategories>>
}

export const Route = createFileRoute('/about')({
  loader: async (): Promise<LoaderData> => {
    const [settings, categories] = await Promise.all([getSettings(), getVisibleCategories()])
    return { settings, categories }
  },
  component: AboutPage,
  head: () => ({ meta: [{ title: 'من نحن | Hi-Tech' }] }),
})

function AboutPage() {
  const { settings, categories } = Route.useLoaderData() as LoaderData
  return (
    <StoreLayout settings={settings} categories={categories}>
      <section className="bg-gradient-to-r from-[var(--ht-blue)] to-[var(--ht-blue-dark)] text-white">
        <div className="mx-auto max-w-7xl px-4 py-8">
          <h1 className="text-2xl sm:text-3xl font-bold">من نحن</h1>
          <p className="opacity-90 mt-1 text-sm">{settings.store_description}</p>
        </div>
      </section>

      <div className="mx-auto max-w-5xl px-4 py-8 space-y-6">
        <article className="rounded-xl border border-border bg-card p-6">
          <p className="text-base leading-8 whitespace-pre-line">
            {settings.about_content || 'متجر Hi-Tech وجهتك الأولى في بلقاس والمناطق المجاورة لكل ما يخص الكمبيوتر واللاب توب وكاميرات المراقبة.'}
          </p>
        </article>

        <div className="grid sm:grid-cols-3 gap-4">
          <FeatureCard icon={Award} title="منتجات أصلية" desc="ماركات عالمية بضمان حقيقي" />
          <FeatureCard icon={ThumbsUp} title="أسعار منافسة" desc="أفضل الأسعار في المنطقة" />
          <FeatureCard icon={Users} title="فريق متخصص" desc="فنيون محترفون لخدمتك" />
          <FeatureCard icon={Clock} title="خدمة سريعة" desc="تنفيذ سريع وتسليم في الوقت" />
        </div>

        <article className="rounded-xl border border-border bg-card p-6 space-y-3">
          <h2 className="font-bold text-lg">تواصل معنا</h2>
          <ul className="space-y-2 text-sm">
            <li className="flex items-center gap-2"><Phone className="size-4 text-[var(--ht-blue)]" /> {settings.phone}</li>
            <li className="flex items-center gap-2"><WhatsappIcon className="size-4 text-green-500" /> {settings.whatsapp}</li>
            <li className="flex items-start gap-2"><MapPin className="size-4 text-[var(--ht-blue)] mt-0.5" /> {settings.address}</li>
            {settings.working_hours && <li className="flex items-start gap-2"><Clock className="size-4 text-[var(--ht-blue)] mt-0.5" /> {settings.working_hours}</li>}
          </ul>
        </article>
      </div>
    </StoreLayout>
  )
}

function FeatureCard({ icon: Icon, title, desc }: { icon: any; title: string; desc: string }) {
  return (
    <div className="rounded-xl border border-border bg-card p-4 text-center">
      <Icon className="size-8 mx-auto text-[var(--ht-blue)]" />
      <h3 className="font-bold mt-2">{title}</h3>
      <p className="text-xs text-muted-foreground mt-1">{desc}</p>
    </div>
  )
}