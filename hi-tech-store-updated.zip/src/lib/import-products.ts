// Hi-Tech Pro (inventory program) -> store catalog mapper.
// Pure and client-safe: no server imports. Used by the admin "import items"
// card (preview in the browser) and by importProductsFn (server) so the same
// rules apply in both places.
//
// Input is the CSV saved from the program's "الأصناف" Excel export.
// Only the sale price, stock and names are used. Purchase price, wholesale
// price and tax are NEVER sent to the store.

export type ImportRow = {
  sku: string
  name: string
  category_slug: string
  unit: string
  price: number
  stock: number
  short_description: string
  description: string
  specs: Record<string, string>
  tags: string[]
}

export type SkippedRow = { sku: string; name: string; reason: string }

export const IMPORT_CATEGORIES: Record<string, { name: string; description: string; sort_order: number }> = {
  cameras: { name: 'كاميرات مراقبة', description: 'كاميرات داخلية وخارجية', sort_order: 4 },
  'dvr-xvr': { name: 'DVR / XVR', description: 'أجهزة تسجيل الكاميرات', sort_order: 5 },
  nvr: { name: 'NVR', description: 'مسجل شبكة الكاميرات', sort_order: 6 },
  'hdd-ssd': { name: 'هاردات و SSD', description: 'هاردات، فلاشات وكروت ميموري', sort_order: 8 },
  rams: { name: 'رامات', description: 'رامات للكمبيوتر واللاب توب', sort_order: 9 },
  monitors: { name: 'شاشات', description: 'شاشات كمبيوتر بمختلف الأحجام', sort_order: 3 },
  laptops: { name: 'لابتوبات', description: 'لابتوبات جديدة ومستعملة', sort_order: 1 },
  networking: { name: 'شبكات وراوترات', description: 'سويتشات وأجهزة شبكات', sort_order: 13 },
  'pc-accessories': { name: 'إكسسوارات الكمبيوتر', description: 'كيبورد، ماوس، سماعات', sort_order: 14 },
  'mobile-accessories': { name: 'إكسسوارات الموبايل', description: 'شواحن، كابلات، سماعات', sort_order: 15 },
  'wifi-extenders': { name: 'أجهزة تقوية الشبكة', description: 'مقويات إشارة', sort_order: 16 },
  cables: { name: 'كابلات ووصلات', description: 'HDMI، VGA، كابلات شبكة وتطويلات', sort_order: 17 },
  'camera-supplies': { name: 'مستلزمات كاميرات المراقبة', description: 'باورات، حوامل، راكات ومستلزمات', sort_order: 18 },
}

// ---------------------------------------------------------------- CSV ------

export function parseCsv(text: string): string[][] {
  const t = text.replace(/^\uFEFF/, '')
  const rows: string[][] = []
  let row: string[] = []
  let cell = ''
  let q = false
  for (let i = 0; i < t.length; i++) {
    const c = t[i]
    if (q) {
      if (c === '"' && t[i + 1] === '"') { cell += '"'; i++ }
      else if (c === '"') q = false
      else cell += c
    } else if (c === '"') q = true
    else if (c === ',') { row.push(cell); cell = '' }
    else if (c === '\n' || c === '\r') {
      if (c === '\r' && t[i + 1] === '\n') i++
      row.push(cell); cell = ''
      if (row.some((x) => x.trim() !== '')) rows.push(row)
      row = []
    } else cell += c
  }
  row.push(cell)
  if (row.some((x) => x.trim() !== '')) rows.push(row)
  return rows
}

const toEnDigits = (s: string) => s.replace(/[٠-٩]/g, (d) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)))
const num = (s: string | undefined) => {
  const n = parseFloat(toEnDigits((s ?? '').replace(/,/g, '').trim()))
  return Number.isFinite(n) ? n : NaN
}

// ------------------------------------------------------------ naming -------

function fixTokens(s: string): string {
  return s
    .replace(/\bhdmi\b/gi, 'HDMI')
    .replace(/\bvga\b/gi, 'VGA')
    .replace(/\busb\b/gi, 'USB')
    .replace(/\bdp\b/gi, 'DP')
    .replace(/\bdvi\b/gi, 'DVI')
    .replace(/\blan\b/gi, 'LAN')
    .replace(/\bpoe\b/gi, 'PoE')
    .replace(/\bhd\b/gi, 'HD')
    .replace(/\bram\b/gi, 'RAM')
    .replace(/\bddr(\d)\b/gi, 'DDR$1')
    .replace(/\s+/g, ' ')
    .trim()
}

const BRAND_WORDS: Record<string, string> = {
  unv: 'Uniview', dahua: 'Dahua', hilook: 'Hilook', colin: 'Colin', yes: 'Yes', tapo: 'Tapo', imou: 'Imou',
}

function cameraInfo(n: string) {
  const m = n.match(/^(?:\d+\s*كشاف\s+)?cam(?:era)?\s+(in|out)\s+(\d+)\s*m\s*(.*)$/i)
  if (!m) return null
  const rest = m[3].toLowerCase()
  const brand = Object.keys(BRAND_WORDS).find((b) => new RegExp(`\\b${b}\\b`).test(rest))
  return {
    place: m[1].toLowerCase() === 'in' ? 'داخلية' : 'خارجية',
    mp: m[2],
    brand: brand ? BRAND_WORDS[brand] : '',
    ip: /\bip\b/.test(rest),
    led: /\bled\b/.test(rest),
    mic: /\bmic\b/.test(rest),
    metal: /معدن/.test(rest),
    original: /original/.test(rest),
    spots: (n.match(/^(\d+)\s*كشاف/) ?? [])[1] ?? '',
  }
}

function cleanName(raw: string, unit: string): { name: string; specs: Record<string, string>; kind: string } {
  const n = toEnDigits(raw.trim())
  const specs: Record<string, string> = {}

  const cam = cameraInfo(n)
  if (cam) {
    const bits = [`كاميرا ${cam.place} ${cam.mp} ميجا`]
    if (cam.brand) bits.push(cam.brand)
    if (cam.ip) bits.push('IP')
    if (cam.led) bits.push('بإضاءة LED')
    if (cam.mic) bits.push('بميكروفون')
    if (cam.metal) bits.push('جسم معدن')
    if (cam.spots) bits.push(`${cam.spots} كشاف`)
    if (cam.original) bits.push('أوريجينال')
    specs['المكان'] = cam.place
    specs['الدقة'] = `${cam.mp} ميجا`
    if (cam.brand) specs['الماركة'] = cam.brand
    if (cam.ip) specs['التقنية'] = 'IP (شبكة)'
    return { name: bits.join(' '), specs, kind: 'camera' }
  }
  let m = n.match(/^cam\s+hilook\s+out\s+(\d)k$/i)
  if (m) return { name: `كاميرا خارجية Hilook ${m[1]}K`, specs: { الماركة: 'Hilook', المكان: 'خارجية' }, kind: 'camera' }

  m = n.match(/^(dvr|nvr)\s+(?:dahua\s+)?(\d+)\s*port\s+(\d+)\s*m(.*)$/i)
  if (m) {
    const kind = m[1].toLowerCase()
    const rest = m[4].toLowerCase()
    const bits = [`جهاز تسجيل ${kind.toUpperCase()} ${m[2]} قنوات ${m[3]} ميجا`]
    if (/4k/.test(rest)) bits.push('4K')
    if (/poe/.test(rest)) bits.push('PoE')
    if (/dahua/.test(n.toLowerCase())) bits.push('Dahua')
    if (/uniarch/.test(rest)) bits.push('Uniarch')
    if (/q3/.test(rest)) bits.push('Q3')
    specs['عدد القنوات'] = m[2]
    specs['الدقة'] = `${m[3]} ميجا`
    return { name: bits.join(' '), specs, kind }
  }
  m = n.match(/^dvr\s+(\d+)\s*port\s+(\d+)mn?\s*(uniarch)?/i)
  if (m) return { name: `جهاز تسجيل DVR ${m[1]} قنوات ${m[2]} ميجا Uniarch`, specs: { 'عدد القنوات': m[1], الدقة: `${m[2]} ميجا` }, kind: 'dvr' }

  m = n.match(/^h\.?d\.?d\s*([\d.]+)\s*(t|tera|g)?/i)
  if (m) {
    const size = m[2]?.toLowerCase() === 'g' ? `${m[1]} جيجا` : `${m[1]} تيرا`
    specs['السعة'] = size
    return { name: `هارد ديسك ${size}`, specs, kind: 'hdd' }
  }
  m = n.match(/^هارد لاب\s*(\d+)/)
  if (m) return { name: `هارد لاب توب ${m[1]} جيجا`, specs: { السعة: `${m[1]} جيجا` }, kind: 'hdd' }

  m = n.match(/^فلاشة\s*(\d+)\s*(.+)$/)
  if (m) {
    const brand = /داهو/.test(m[2]) ? 'Dahua' : /سان ديسك/.test(m[2]) ? 'SanDisk' : m[2]
    return { name: `فلاشة ${m[1]} جيجا ${brand}`, specs: { السعة: `${m[1]} جيجا`, الماركة: brand }, kind: 'flash' }
  }
  m = n.match(/^ميمورى\s*(\d+)\s*(unv)?/i)
  if (m) {
    const brand = m[2] ? 'Uniview' : ''
    return { name: `كارت ميموري ${m[1]} جيجا${brand ? ' ' + brand : ''}`, specs: { السعة: `${m[1]} جيجا` }, kind: 'flash' }
  }
  m = n.match(/^ram\s*(\d+)g\s*(ddr\d)/i)
  if (m) return { name: `رام ${m[1]} جيجا ${m[2].toUpperCase()}`, specs: { السعة: `${m[1]} جيجا`, النوع: m[2].toUpperCase() }, kind: 'ram' }

  m = n.match(/^لاب\s+dell\s+(\d+)/i)
  if (m) return { name: `لاب توب Dell ${m[1]}`, specs: { الماركة: 'Dell', الموديل: m[1] }, kind: 'laptop' }

  const FIXED: Record<string, string> = { 'cable cam': 'سلك كاميرات', 'cable net cat6': 'كابل شبكة Cat6', 'rack 2u': 'راك 2U', 'راك 2u': 'راك 2U' }
  let name = FIXED[n.toLowerCase()] ?? fixTokens(n)
  if (unit === 'متر') name += ' (بالمتر)'
  return { name, specs, kind: 'other' }
}

// ----------------------------------------------------- classification ------

function classify(n: string, sourceCat: string, kind: string): string {
  const s = n.toLowerCase()
  if (kind === 'camera' || /^كاميرا/.test(s)) return 'cameras'
  if (kind === 'dvr') return 'dvr-xvr'
  if (kind === 'nvr') return 'nvr'
  if (kind === 'hdd' || kind === 'flash') return 'hdd-ssd'
  if (kind === 'ram') return 'rams'
  if (kind === 'laptop') return 'laptops'

  if (/كابل شاشة|حامل شاشة|شاحن لاب|شنطة/.test(s)) return /كابل/.test(s) ? 'cables' : 'pc-accessories'
  if (/^شاشة|شاشة (led|ديل)/.test(s)) return 'monitors'
  if (/تقوية شبكة/.test(s)) return 'wifi-extenders'
  if (/سويتش|اكسس|usb wifi|wifi/.test(s)) return 'networking'
  if (/cable cam|pnc|باور \d+ امبير|حامل كاميرا|خرطوم|راك|rack|بواط 27|6 كشاف/.test(s)) return 'camera-supplies'
  if (sourceCat === 'موبيل') return 'mobile-accessories'
  if (/كابل|cable|تطويلة|وصلة|سبلتر|مشترك|lan hdmi|سلك|بواط كهرباء/.test(s)) return 'cables'
  if (/ماوس|كيبورد|سماعة|هيدفون|صب |دراع|ريدر|بادة|كولر|بطارية/.test(s)) return 'pc-accessories'
  return sourceCat === 'كاميرات مراقبة' ? 'camera-supplies' : 'pc-accessories'
}

// -------------------------------------------------------- descriptions -----

const INTRO: Record<string, string> = {
  cameras: 'كاميرا مراقبة مناسبة للمنازل والمحلات والمكاتب.',
  'dvr-xvr': 'جهاز تسجيل لكاميرات المراقبة لتخزين ومشاهدة التسجيلات.',
  nvr: 'جهاز تسجيل لكاميرات الشبكة (IP).',
  'hdd-ssd': 'وحدة تخزين للاستخدام مع الكمبيوتر وأنظمة المراقبة.',
  rams: 'ذاكرة رام لتحسين أداء الجهاز.',
  monitors: 'شاشة للاستخدام المكتبي والمنزلي.',
  laptops: 'لاب توب من Hi-Tech.',
  networking: 'منتج شبكات للاستخدام المنزلي والتجاري.',
  'pc-accessories': 'إكسسوار للكمبيوتر واللاب توب.',
  'mobile-accessories': 'إكسسوار للموبايل.',
  'wifi-extenders': 'جهاز لتقوية الإشارة.',
  cables: 'كابل / وصلة للاستخدام اليومي.',
  'camera-supplies': 'مستلزمات تركيب وتشغيل كاميرات المراقبة.',
}

function buildTexts(name: string, cat: string, specs: Record<string, string>) {
  const short = `${name} — ${INTRO[cat] ?? ''}`.trim()
  const lines = [INTRO[cat] ?? '', ...Object.entries(specs).map(([k, v]) => `• ${k}: ${v}`)].filter(Boolean)
  lines.push('للطلب أو الاستفسار عن التوفر والتركيب تواصل معنا على واتساب — Hi-Tech بلقاس.')
  return { short_description: short, description: lines.join('\n') }
}

// ----------------------------------------------------------- main ----------

export function mapRows(csvText: string): { rows: ImportRow[]; skipped: SkippedRow[] } {
  const table = parseCsv(csvText)
  if (table.length < 2) return { rows: [], skipped: [] }
  const head = table[0].map((h) => h.trim())
  const idx = (label: string) => head.indexOf(label)
  const c = {
    sku: idx('الكود'), name: idx('الاسم'), cat: idx('التصنيف'), unit: idx('الوحدة'),
    price: idx('سعر البيع'), qty: idx('الكمية'), type: idx('النوع'), status: idx('الحالة'),
  }
  const missing = Object.entries(c).filter(([, v]) => v < 0).map(([k]) => k)
  if (missing.length) throw new Error('الملف ناقص أعمدة: ' + missing.join('، ') + ' — لازم يكون تصدير الأصناف من البرنامج')

  const rows: ImportRow[] = []
  const skipped: SkippedRow[] = []
  const seen = new Set<string>()
  for (const r of table.slice(1)) {
    const sku = (r[c.sku] ?? '').trim()
    const rawName = (r[c.name] ?? '').trim()
    if (!sku || !rawName) continue
    if ((r[c.type] ?? '').trim() === 'خدمة') { skipped.push({ sku, name: rawName, reason: 'خدمة (مش منتج)' }); continue }
    if ((r[c.status] ?? '').trim() !== 'نشط') { skipped.push({ sku, name: rawName, reason: 'موقوف' }); continue }
    const price = num(r[c.price])
    if (!(price > 0)) { skipped.push({ sku, name: rawName, reason: 'السعر صفر أو غير صالح' }); continue }
    if (seen.has(sku)) { skipped.push({ sku, name: rawName, reason: 'كود مكرر' }); continue }
    seen.add(sku)
    const unit = (r[c.unit] ?? '').trim()
    const qty = num(r[c.qty])
    const { name, specs, kind } = cleanName(rawName, unit)
    const category_slug = classify(rawName, (r[c.cat] ?? '').trim(), kind)
    const texts = buildTexts(name, category_slug, specs)
    rows.push({
      sku, name, category_slug, unit, price,
      stock: Number.isFinite(qty) ? Math.max(0, Math.floor(qty)) : 0,
      ...texts,
      specs,
      tags: [IMPORT_CATEGORIES[category_slug]?.name ?? ''].filter(Boolean),
    })
  }
  return { rows, skipped }
}

export function slugFromSku(sku: string) {
  return 'p-' + sku.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '')
}
