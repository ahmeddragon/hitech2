// Server-side data access for Hi-Tech Store
// All functions resolve their Nubase client through getStoreDb(), which prefers
// the service-role client and degrades to RLS-scoped access when the runtime
// does not expose a service-role key.
// Pages/loaders receive sanitized data; mutation operations go through
// server functions in /lib/admin.ts.

import { getStoreDb } from './db.server'
import { seedIfEmpty } from './seed.server'
import type {
  Banner,
  Brand,
  Category,
  Order,
  OrderItem,
  PaymentMethod,
  Product,
  ProductImage,
  ProductListFilters,
  Service,
  Settings,
} from './types'

let seeded = false

async function ensureSeed() {
  if (seeded) return
  try {
    await seedIfEmpty()
    seeded = true
  } catch (e) {
    console.error('seed error', e)
  }
}

function row<T>(data: T | T[] | null): T | null {
  if (!data) return null
  if (Array.isArray(data)) return data[0] ?? null
  return data
}

function rows<T>(data: T[] | null | undefined): T[] {
  return data ?? []
}

// ----------------------------------------------------------------------------
// Public catalog
// ----------------------------------------------------------------------------

export async function getSettings(): Promise<Settings> {
  await ensureSeed()
  const client = getStoreDb()
  const { data } = await client.from('settings').select('*').eq('id', 'site').single()
  return (data as Settings) ?? {
    id: 'site',
    store_name: 'Hi-Tech',
    store_description: 'لخدمات الكمبيوتر واللاب توب وكاميرات المراقبة',
    owner_name: 'م / أحمد أبو النجا',
    phone: '01002261030',
    whatsapp: '01002261030',
    address: 'بلقاس – شارع الدهايمة – بجوار كافيتريا الغريب',
    working_hours: 'السبت - الخميس: 10 صباحًا - 10 مساءً',
    logo_url: null,
    favicon_url: null,
    facebook_url: null,
    instagram_url: null,
    tiktok_url: null,
    youtube_url: null,
    meta_title: 'Hi-Tech - كمبيوتر، لاب توب، كاميرات مراقبة',
    meta_description: '',
    map_embed: null,
    about_content: '',
    whatsapp_default_message: 'مرحبًا Hi-Tech، أريد الاستفسار عن أحد المنتجات.',
    order_receipt_header: 'طلب جديد من متجر Hi-Tech',
  }
}

export async function getCategories(): Promise<Category[]> {
  await ensureSeed()
  const client = getStoreDb()
  const { data } = await client
    .from('categories')
    .select('*')
    .order('sort_order', { ascending: true })
  return rows(data as Category[])
}

export async function getVisibleCategories(): Promise<Category[]> {
  const cats = await getCategories()
  return cats.filter((c) => c.is_visible)
}

export async function getFeaturedCategories(): Promise<Category[]> {
  const cats = await getVisibleCategories()
  return cats.filter((c) => c.is_featured)
}

export async function getCategoryBySlug(slug: string): Promise<Category | null> {
  await ensureSeed()
  const client = getStoreDb()
  const { data } = await client
    .from('categories')
    .select('*')
    .eq('slug', slug)
    .single()
  return row(data as Category)
}

export async function getBrands(): Promise<Brand[]> {
  await ensureSeed()
  const client = getStoreDb()
  const { data } = await client.from('brands').select('*').order('name')
  return rows(data as Brand[])
}

export async function getVisibleBrands(): Promise<Brand[]> {
  const brands = await getBrands()
  return brands.filter((b) => b.is_visible)
}

export async function getProducts(filters: ProductListFilters = {}): Promise<{ items: Product[]; total: number }> {
  await ensureSeed()
  const client = getStoreDb()
  const page = filters.page ?? 1
  const pageSize = filters.page_size ?? 24
  const from = (page - 1) * pageSize
  const to = from + pageSize - 1

  // Resolve category_slug -> category_id
  let categoryId = filters.category_id
  if (!categoryId && filters.category_slug) {
    const cat = await getCategoryBySlug(filters.category_slug)
    categoryId = cat?.id
  }

  // We cannot chain arbitrary filters via the simple from().select(),
  // so we fetch all rows matching minimum criteria, then apply server-side filtering.
  let q = client.from('products').select('*').range(from, to)
  if (categoryId) q = client.from('products').select('*').eq('category_id', categoryId).range(from, to)
  if (filters.brand_id) q = client.from('products').select('*').eq('brand_id', filters.brand_id).range(from, to)
  if (filters.ids && filters.ids.length > 0) {
    // Can't use 'in' via simple .eq; load by ids from server.
    return await getProductsByIds(filters.ids, page, pageSize)
  }
  const { data } = await q
  let items = rows(data as Product[])

  // Server-side refinement
  if (filters.search) {
    const s = filters.search.toLowerCase()
    items = items.filter((p) => {
      const haystack = [
        p.name,
        p.brand_id,
        p.model,
        p.sku,
        p.barcode,
        p.short_description,
        p.description,
        ...(p.tags ?? []),
      ]
        .filter(Boolean)
        .map((v) => String(v).toLowerCase())
      return haystack.some((h) => h.includes(s))
    })
  }
  if (filters.is_featured !== undefined) items = items.filter((p) => !!p.is_featured === filters.is_featured)
  if (filters.is_on_sale !== undefined) items = items.filter((p) => !!p.is_on_sale === filters.is_on_sale)
  if (filters.is_new !== undefined) items = items.filter((p) => !!p.is_new === filters.is_new)
  if (filters.is_best_seller !== undefined) items = items.filter((p) => !!p.is_best_seller === filters.is_best_seller)
  if (filters.in_stock_only) items = items.filter((p) => p.is_available && p.stock > 0)
  if (filters.min_price !== undefined) items = items.filter((p) => p.price >= filters.min_price!)
  if (filters.max_price !== undefined) items = items.filter((p) => p.price <= filters.max_price!)

  // Sort
  const sort = filters.sort ?? 'newest'
  if (sort === 'price_asc') items.sort((a, b) => a.price - b.price)
  else if (sort === 'price_desc') items.sort((a, b) => b.price - a.price)
  else if (sort === 'best_selling') items.sort((a, b) => Number(b.is_best_seller) - Number(a.is_best_seller))
  else if (sort === 'most_viewed') items.sort((a, b) => b.views_count - a.views_count)
  else if (sort === 'oldest') items.sort((a, b) => String(a.created_at).localeCompare(String(b.created_at)))
  else items.sort((a, b) => String(b.created_at).localeCompare(String(a.created_at)))

  // Hydrate images and category
  const itemsWithMeta = await Promise.all(items.map((p) => hydrateProduct(p)))
  return { items: itemsWithMeta, total: itemsWithMeta.length }
}

async function getProductsByIds(ids: string[], page = 1, pageSize = 24): Promise<{ items: Product[]; total: number }> {
  const client = getStoreDb()
  const all: Product[] = []
  for (const id of ids) {
    const { data } = await client.from('products').select('*').eq('id', id).single()
    if (data) all.push(data as Product)
  }
  const start = (page - 1) * pageSize
  const items = all.slice(start, start + pageSize)
  const hydrated = await Promise.all(items.map((p) => hydrateProduct(p)))
  return { items: hydrated, total: all.length }
}

export async function getProductBySlug(slug: string): Promise<Product | null> {
  await ensureSeed()
  const client = getStoreDb()
  const { data } = await client.from('products').select('*').eq('slug', slug).single()
  if (!data) return null
  return hydrateProduct(data as Product)
}

export async function getProductById(id: string): Promise<Product | null> {
  const client = getStoreDb()
  const { data } = await client.from('products').select('*').eq('id', id).single()
  if (!data) return null
  return hydrateProduct(data as Product)
}

async function hydrateProduct(p: Product): Promise<Product> {
  const client = getStoreDb()
  const [{ data: images }, brand, category] = await Promise.all([
    client.from('product_images').select('*').eq('product_id', p.id).order('sort_order'),
    p.brand_id
      ? client.from('brands').select('*').eq('id', p.brand_id).single()
      : Promise.resolve({ data: null }),
    p.category_id
      ? client.from('categories').select('*').eq('id', p.category_id).single()
      : Promise.resolve({ data: null }),
  ])
  const imgs = rows(images as ProductImage[]).sort((a, b) => a.sort_order - b.sort_order)
  return {
    ...p,
    images: imgs,
    main_image: imgs.find((i) => i.is_main) ?? imgs[0] ?? null,
    brand: (brand.data as Brand) ?? null,
    category: (category.data as Category) ?? null,
  }
}

export async function getActiveBanners(): Promise<Banner[]> {
  await ensureSeed()
  const client = getStoreDb()
  const { data } = await client
    .from('banners')
    .select('*')
    .eq('is_active', true)
    .order('sort_order')
  return rows(data as Banner[])
}

export async function getActiveServices(): Promise<Service[]> {
  await ensureSeed()
  const client = getStoreDb()
  const { data } = await client
    .from('services')
    .select('*')
    .eq('is_active', true)
    .order('sort_order')
  return rows(data as Service[])
}

export async function getActivePaymentMethods(): Promise<PaymentMethod[]> {
  await ensureSeed()
  const client = getStoreDb()
  const { data } = await client
    .from('payment_methods')
    .select('*')
    .eq('is_active', true)
    .order('sort_order')
  return rows(data as PaymentMethod[])
}

export async function getActiveOffers(): Promise<{ id: string; title: string; slug: string; description: string | null; image_url: string | null; discount_percent: number; product_ids: string[] }[]> {
  await ensureSeed()
  const client = getStoreDb()
  const { data } = await client.from('offers').select('*').eq('is_active', true).order('sort_order')
  const offers = rows(data)
  const result: { id: string; title: string; slug: string; description: string | null; image_url: string | null; discount_percent: number; product_ids: string[] }[] = []
  for (const o of offers) {
    const { data: links } = await client.from('offer_products').select('product_id').eq('offer_id', o.id)
    result.push({ ...o, product_ids: rows(links).map((l) => l.product_id as string) })
  }
  return result
}

export async function searchProducts(query: string, limit = 20): Promise<Product[]> {
  if (!query.trim()) return []
  const { items } = await getProducts({ search: query, page_size: limit })
  return items
}

// ----------------------------------------------------------------------------
// Pages
// ----------------------------------------------------------------------------

export async function getPage(slug: string) {
  const client = getStoreDb()
  const { data } = await client.from('pages').select('*').eq('slug', slug).single()
  return row(data)
}

// ----------------------------------------------------------------------------
// Public order creation (used by checkout)
// ----------------------------------------------------------------------------

export type CreatedOrder = {
  order_number: string
  id: string
  total: number
  lines: { product_id: string; name: string; unit_price: number; quantity: number }[]
}

/**
 * Creates a customer order through the database function `place_order`.
 *
 * SECURITY: the browser is only trusted for WHICH products and HOW MANY.
 * The function reads names and prices from the products table and does the
 * stock check/decrement in one transaction, so a tampered request cannot buy
 * an item at another price or oversell stock. See migration
 * 20261017120000-place-order.sql.
 */
export async function createOrder(input: {
  customer: { name: string; phone: string; address?: string; notes?: string }
  items: { product_id: string; quantity: number; [k: string]: unknown }[]
  payment_method: string
}): Promise<CreatedOrder> {
  const client = getStoreDb()
  const items = input.items.map((i) => ({ product_id: String(i.product_id ?? ''), quantity: Number(i.quantity) }))
  const res = await client.rest('rpc/place_order', {
    method: 'POST',
    body: JSON.stringify({
      p_customer: {
        name: input.customer.name,
        phone: toAsciiDigits(String(input.customer.phone ?? '')),
        address: input.customer.address ?? '',
        notes: input.customer.notes ?? '',
      },
      p_items: items,
      p_payment: input.payment_method,
    }),
  })
  const body: any = await res.json().catch(() => null)
  if (!res.ok) {
    // Postgres `raise exception` messages are written for the customer (Arabic).
    const msg = typeof body?.message === 'string' && /[\u0600-\u06FF]/.test(body.message)
      ? body.message
      : 'تعذر تسجيل الطلب، حاول مرة أخرى'
    throw new Error(msg)
  }
  return body as CreatedOrder
}

function toAsciiDigits(s: string) {
  return s.replace(/[٠-٩]/g, (d) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)))
}

// ----------------------------------------------------------------------------
// Admin: orders / customers
// ----------------------------------------------------------------------------

export async function getOrders(filters: { status?: string; search?: string } = {}): Promise<Order[]> {
  const client = getStoreDb()
  let q = client.from('orders').select('*').order('created_at', { ascending: false })
  const { data } = await q
  let items = rows(data as Order[])
  if (filters.status) items = items.filter((o) => o.status === filters.status)
  if (filters.search) {
    const s = filters.search.toLowerCase()
    items = items.filter((o) =>
      [o.order_number, o.customer_name, o.customer_phone]
        .filter(Boolean)
        .some((v) => String(v).toLowerCase().includes(s)),
    )
  }
  // Hydrate items
  const result: Order[] = []
  for (const o of items) {
    const { data: items } = await client.from('order_items').select('*').eq('order_id', o.id)
    result.push({ ...o, items: rows(items as OrderItem[]) })
  }
  return result
}

export async function getCustomers() {
  const client = getStoreDb()
  const { data } = await client.from('customers').select('*').order('created_at', { ascending: false })
  return rows(data)
}

export async function getDashboardStats() {
  const client = getStoreDb()
  const [{ data: products }, { data: categories }, { data: orders }, { data: customers }] = await Promise.all([
    client.from('products').select('id, stock, is_available, price, is_featured, is_on_sale, is_best_seller, views_count, created_at, name'),
    client.from('categories').select('id, is_visible'),
    client.from('orders').select('id, status, total, created_at'),
    client.from('customers').select('id, total_orders, total_spent'),
  ])
  const productRows = rows(products)
  const orderRows = rows(orders)
  const customerRows = rows(customers)
  const totalProducts = productRows.length
  const availableProducts = productRows.filter((p) => p.is_available && p.stock > 0).length
  const lowStock = productRows.filter((p) => p.is_available && p.stock > 0 && p.stock <= 3).length
  const outOfStock = productRows.filter((p) => p.stock <= 0).length
  const featured = productRows.filter((p) => p.is_featured).length
  const onSale = productRows.filter((p) => p.is_on_sale).length
  const bestSellers = productRows.filter((p) => p.is_best_seller).length
  const totalOrders = orderRows.length
  const newOrders = orderRows.filter((o) => o.status === 'new').length
  const totalCustomers = customerRows.length
  const totalRevenue = orderRows.reduce((s, o) => s + Number(o.total ?? 0), 0)
  const totalCategories = rows(categories).filter((c) => c.is_visible).length
  const mostViewed = [...productRows].sort((a, b) => b.views_count - a.views_count).slice(0, 5)
  const topOrdered = bestSellers > 0 ? productRows.filter((p) => p.is_best_seller).slice(0, 5) : productRows.slice(0, 5)
  return {
    totalProducts,
    availableProducts,
    lowStock,
    outOfStock,
    featured,
    onSale,
    bestSellers,
    totalOrders,
    newOrders,
    totalCustomers,
    totalRevenue,
    totalCategories,
    mostViewed,
    topOrdered,
  }
}