// Client-safe cart + WhatsApp helpers (no server-only imports)

import type { CartItem, Settings } from './types'

export function calcCartTotals(items: CartItem[]) {
  const subtotal = items.reduce((sum, i) => sum + i.unit_price * i.quantity, 0)
  const originalSubtotal = items.reduce(
    (sum, i) => sum + (i.original_price ?? i.unit_price) * i.quantity,
    0,
  )
  const discount = originalSubtotal - subtotal
  return {
    subtotal,
    discount,
    total: subtotal,
  }
}

export function buildWhatsAppMessage(opts: {
  settings: Settings
  cart: CartItem[]
  totals: { subtotal: number; discount: number; total: number }
  customer: { name: string; phone: string; address?: string; notes?: string }
  paymentMethod: string
}) {
  const { settings, cart, totals, customer, paymentMethod } = opts
  const lines: string[] = []
  lines.push(`*${settings.order_receipt_header ?? 'طلب جديد من متجر Hi-Tech'}*`)
  lines.push('')
  lines.push(`👤 اسم العميل: ${customer.name}`)
  lines.push(`📞 الهاتف: ${customer.phone}`)
  if (customer.address) lines.push(`📍 العنوان: ${customer.address}`)
  lines.push('')
  lines.push('*المنتجات:*')
  cart.forEach((item, idx) => {
    lines.push(
      `${idx + 1}- ${item.name} × ${item.quantity} = ${(item.unit_price * item.quantity).toLocaleString('ar-EG')} ج.م`,
    )
    if (item.original_price && item.original_price > item.unit_price) {
      lines.push(`   (السعر الأصلي: ${item.original_price.toLocaleString('ar-EG')} ج.م)`)
    }
  })
  lines.push('')
  if (totals.discount > 0) {
    lines.push(`الإجمالي قبل الخصم: ${(totals.subtotal + totals.discount).toLocaleString('ar-EG')} ج.م`)
    lines.push(`الخصم: ${totals.discount.toLocaleString('ar-EG')} ج.م`)
  }
  lines.push(`*الإجمالي: ${totals.total.toLocaleString('ar-EG')} ج.م*`)
  lines.push('')
  lines.push(`💳 طريقة الدفع: ${paymentMethod}`)
  if (customer.notes) {
    lines.push('')
    lines.push(`📝 ملاحظات: ${customer.notes}`)
  }
  return lines.join('\n')
}

export function buildWhatsAppLink(phone: string, message: string) {
  const clean = phone.replace(/[^0-9+]/g, '')
  const normalized = clean.startsWith('0') ? `2${clean}` : clean
  return `https://wa.me/${normalized}?text=${encodeURIComponent(message)}`
}
