// Hi-Tech Store Type Definitions
// POS-ready structure aligned with Hi-Tech POS (https://hi-tech-pos.web.app/)

export type ID = string

export type Settings = {
  id: string
  store_name: string
  store_description: string | null
  owner_name: string | null
  phone: string
  whatsapp: string
  address: string
  working_hours: string | null
  logo_url: string | null
  favicon_url: string | null
  facebook_url: string | null
  instagram_url: string | null
  tiktok_url: string | null
  youtube_url: string | null
  meta_title: string | null
  meta_description: string | null
  map_embed: string | null
  about_content: string | null
  whatsapp_default_message: string | null
  order_receipt_header: string | null
  admin_bootstrapped?: boolean
  created_at?: string
  updated_at?: string
}

export type Category = {
  id: ID
  slug: string
  name: string
  description: string | null
  image_url: string | null
  parent_id: ID | null
  sort_order: number
  is_visible: boolean
  is_featured: boolean
  filter_schema: FilterSchema
  created_at?: string
  updated_at?: string
  product_count?: number
}

export type FilterSchema = FilterGroup[]

export type FilterGroup = {
  key: string
  label: string
  type: 'select' | 'range' | 'checkbox'
  options?: { value: string; label: string }[]
  min?: number
  max?: number
  unit?: string
}

export type Brand = {
  id: ID
  slug: string
  name: string
  logo_url: string | null
  is_visible: boolean
  product_count?: number
  created_at?: string
  updated_at?: string
}

export type Product = {
  id: ID
  slug: string
  sku: string | null
  barcode: string | null
  name: string
  brand_id: ID | null
  brand?: Brand | null
  category_id: ID | null
  category?: Category | null
  model: string | null
  short_description: string | null
  description: string | null
  specs: Record<string, string>
  tags: string[]
  price_original: number
  price: number
  discount_percent: number
  stock: number
  low_stock_threshold: number
  is_available: boolean
  is_new: boolean
  is_featured: boolean
  is_on_sale: boolean
  is_best_seller: boolean
  views_count: number
  meta_title: string | null
  meta_description: string | null
  images?: ProductImage[]
  main_image?: ProductImage | null
  created_at?: string
  updated_at?: string
}

export type ProductImage = {
  id: ID
  product_id: ID
  url: string
  thumbnail_url: string | null
  sort_order: number
  is_main: boolean
}

export type Banner = {
  id: ID
  title: string
  subtitle: string | null
  description: string | null
  image_url: string
  cta_label: string | null
  cta_link: string | null
  sort_order: number
  is_active: boolean
  starts_at: string | null
  ends_at: string | null
}

export type Offer = {
  id: ID
  slug: string
  title: string
  description: string | null
  image_url: string | null
  discount_percent: number
  starts_at: string | null
  ends_at: string | null
  is_active: boolean
  sort_order: number
  product_ids?: ID[]
  products?: Product[]
}

export type Service = {
  id: ID
  slug: string
  title: string
  description: string | null
  icon: string | null
  image_url: string | null
  sort_order: number
  is_active: boolean
}

export type PaymentMethod = {
  id: ID
  code: string
  name: string
  account_number: string | null
  instructions: string | null
  icon: string | null
  sort_order: number
  is_active: boolean
}

export type Page = {
  id: ID
  slug: string
  title: string
  content: string | null
  meta_title: string | null
  meta_description: string | null
  is_active: boolean
}

export type Customer = {
  id: ID
  name: string
  phone: string
  address: string | null
  notes: string | null
  total_orders: number
  total_spent: number
  last_order_at: string | null
  created_at?: string
  updated_at?: string
}

export type OrderStatus =
  | 'new'
  | 'contacted'
  | 'confirmed'
  | 'preparing'
  | 'shipped'
  | 'delivered'
  | 'cancelled'

export const ORDER_STATUSES: { value: OrderStatus; label: string; color: string }[] = [
  { value: 'new', label: 'جديد', color: 'bg-blue-100 text-blue-800' },
  { value: 'contacted', label: 'تم التواصل', color: 'bg-yellow-100 text-yellow-800' },
  { value: 'confirmed', label: 'مؤكد', color: 'bg-indigo-100 text-indigo-800' },
  { value: 'preparing', label: 'قيد التجهيز', color: 'bg-purple-100 text-purple-800' },
  { value: 'shipped', label: 'تم الشحن', color: 'bg-cyan-100 text-cyan-800' },
  { value: 'delivered', label: 'تم التسليم', color: 'bg-green-100 text-green-800' },
  { value: 'cancelled', label: 'ملغي', color: 'bg-red-100 text-red-800' },
]

export type Order = {
  id: ID
  order_number: string
  customer_id: ID | null
  customer_name: string
  customer_phone: string
  customer_address: string | null
  notes: string | null
  payment_method: string
  status: OrderStatus
  subtotal: number
  discount: number
  total: number
  source: string
  meta: Record<string, unknown>
  items?: OrderItem[]
  created_at?: string
  updated_at?: string
}

export type OrderItem = {
  id: ID
  order_id: ID
  product_id: ID | null
  product_name: string
  product_sku: string | null
  unit_price: number
  quantity: number
  line_total: number
}

export type ActivityLog = {
  id: ID
  actor_email: string | null
  action: string
  entity_type: string | null
  entity_id: string | null
  details: Record<string, unknown>
  ip_address: string | null
  created_at: string
}

export type AdminUser = {
  id: ID
  user_id?: string | null
  email: string
  full_name: string | null
  role: 'admin' | 'manager' | 'staff'
  is_active: boolean
  last_login_at: string | null
}

export type StockStatus = 'in_stock' | 'limited' | 'out_of_stock' | 'unavailable'

export function getStockStatus(
  product: Pick<Product, 'is_available' | 'stock' | 'low_stock_threshold'>,
): StockStatus {
  if (!product.is_available) return 'unavailable'
  if (product.stock <= 0) return 'out_of_stock'
  if (product.stock <= product.low_stock_threshold) return 'limited'
  return 'in_stock'
}

export const STOCK_LABELS: Record<StockStatus, string> = {
  in_stock: 'متوفر',
  limited: 'كمية محدودة',
  out_of_stock: 'نفذ المخزون',
  unavailable: 'غير متاح',
}

export const STOCK_COLORS: Record<StockStatus, string> = {
  in_stock: 'bg-green-100 text-green-800 border-green-200',
  limited: 'bg-amber-100 text-amber-800 border-amber-200',
  out_of_stock: 'bg-gray-200 text-gray-700 border-gray-300',
  unavailable: 'bg-red-100 text-red-800 border-red-200',
}

export type CartItem = {
  product_id: ID
  slug: string
  name: string
  image?: string
  unit_price: number
  original_price?: number
  quantity: number
  max_stock: number
}

export type Cart = {
  items: CartItem[]
  subtotal: number
  discount: number
  total: number
}
export type ProductListFilters = {
  category_id?: string
  category_slug?: string
  brand_id?: string
  search?: string
  min_price?: number
  max_price?: number
  is_featured?: boolean
  is_on_sale?: boolean
  is_new?: boolean
  is_best_seller?: boolean
  tags?: string[]
  in_stock_only?: boolean
  sort?: 'newest' | 'oldest' | 'price_asc' | 'price_desc' | 'best_selling' | 'most_viewed'
  page?: number
  page_size?: number
  ids?: string[]
}
