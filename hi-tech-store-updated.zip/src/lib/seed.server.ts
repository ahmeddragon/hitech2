// Seed initial Hi-Tech data on first run
// Idempotent — only inserts when table is empty.

import { getStoreDb } from './db.server'
import type { FilterSchema } from './types'

const DEFAULT_FILTERS: Record<string, FilterSchema> = {
  laptops: [
    { key: 'brand', label: 'الماركة', type: 'checkbox', options: [] },
    { key: 'processor', label: 'المعالج', type: 'checkbox', options: [
      { value: 'intel_i3', label: 'Intel Core i3' },
      { value: 'intel_i5', label: 'Intel Core i5' },
      { value: 'intel_i7', label: 'Intel Core i7' },
      { value: 'intel_i9', label: 'Intel Core i9' },
      { value: 'ryzen5', label: 'AMD Ryzen 5' },
      { value: 'ryzen7', label: 'AMD Ryzen 7' },
      { value: 'ryzen9', label: 'AMD Ryzen 9' },
    ]},
    { key: 'ram', label: 'الرام', type: 'checkbox', options: [
      { value: '4', label: '4 جيجا' },
      { value: '8', label: '8 جيجا' },
      { value: '16', label: '16 جيجا' },
      { value: '32', label: '32 جيجا' },
      { value: '64', label: '64 جيجا' },
    ]},
    { key: 'storage', label: 'التخزين', type: 'checkbox', options: [
      { value: '256', label: '256 جيجا' },
      { value: '512', label: '512 جيجا' },
      { value: '1024', label: '1 تيرا' },
      { value: '2048', label: '2 تيرا' },
    ]},
    { key: 'screen_size', label: 'حجم الشاشة', type: 'checkbox', options: [
      { value: '13', label: '13 بوصة' },
      { value: '14', label: '14 بوصة' },
      { value: '15', label: '15.6 بوصة' },
      { value: '17', label: '17 بوصة' },
    ]},
    { key: 'price', label: 'السعر', type: 'range', min: 0, max: 200000 },
  ],
  cameras: [
    { key: 'brand', label: 'الماركة', type: 'checkbox', options: [] },
    { key: 'resolution', label: 'الدقة', type: 'checkbox', options: [
      { value: '2mp', label: '2 ميجا' },
      { value: '4mp', label: '4 ميجا' },
      { value: '5mp', label: '5 ميجا' },
      { value: '8mp', label: '8 ميجا (4K)' },
    ]},
    { key: 'type', label: 'النوع', type: 'checkbox', options: [
      { value: 'bullet', label: 'بوليت (خارجية)' },
      { value: 'dome', label: 'دوم (داخلية)' },
      { value: 'ptz', label: 'متحركة PTZ' },
    ]},
    { key: 'environment', label: 'المكان', type: 'checkbox', options: [
      { value: 'indoor', label: 'داخلي' },
      { value: 'outdoor', label: 'خارجي' },
    ]},
    { key: 'technology', label: 'التقنية', type: 'checkbox', options: [
      { value: 'ip', label: 'IP (شبكة)' },
      { value: 'analog', label: 'Analog (تناظري)' },
    ]},
    { key: 'night_vision', label: 'رؤية ليلية', type: 'checkbox', options: [
      { value: 'yes', label: 'يدعم' },
    ]},
    { key: 'price', label: 'السعر', type: 'range', min: 0, max: 50000 },
  ],
  storage: [
    { key: 'brand', label: 'الماركة', type: 'checkbox', options: [] },
    { key: 'type', label: 'النوع', type: 'checkbox', options: [
      { value: 'hdd', label: 'HDD' },
      { value: 'ssd', label: 'SSD' },
      { value: 'nvme', label: 'NVMe SSD' },
    ]},
    { key: 'capacity', label: 'السعة', type: 'checkbox', options: [
      { value: '256', label: '256 جيجا' },
      { value: '512', label: '512 جيجا' },
      { value: '1024', label: '1 تيرا' },
      { value: '2048', label: '2 تيرا' },
      { value: '4096', label: '4 تيرا' },
      { value: '8192', label: '8 تيرا' },
    ]},
    { key: 'interface', label: 'الواجهة', type: 'checkbox', options: [
      { value: 'sata', label: 'SATA' },
      { value: 'nvme', label: 'NVMe M.2' },
    ]},
    { key: 'price', label: 'السعر', type: 'range', min: 0, max: 30000 },
  ],
}

export async function seedIfEmpty() {
  const client = getStoreDb()

  // Check if categories exist
  const { data: existing } = await client
    .from('categories')
    .select('id')
    .limit(1)
  if (existing && existing.length > 0) return

  // Seed categories
  const categories: Array<{ slug: string; name: string; description?: string; image_url?: string; sort_order: number; is_featured?: boolean; filter_key?: string }> = [
    { slug: 'laptops', name: 'لابتوبات', description: 'أحدث اللابتوبات من HP، Lenovo، Dell، Asus', sort_order: 1, is_featured: true, filter_key: 'laptops' },
    { slug: 'computers', name: 'أجهزة كمبيوتر', description: 'كمبيوتر مكتبي وPC Gaming', sort_order: 2, is_featured: true, filter_key: 'laptops' },
    { slug: 'monitors', name: 'شاشات', description: 'شاشات كمبيوتر بمختلف الأحجام', sort_order: 3, is_featured: true },
    { slug: 'cameras', name: 'كاميرات مراقبة', description: 'كاميرات داخلية وخارجية', sort_order: 4, is_featured: true, filter_key: 'cameras' },
    { slug: 'dvr-xvr', name: 'DVR / XVR', description: 'أجهزة تسجيل الكاميرات', sort_order: 5, is_featured: true },
    { slug: 'nvr', name: 'NVR', description: 'مسجل شبكة الكاميرات', sort_order: 6 },
    { slug: 'ip-cameras', name: 'كاميرات IP', description: 'كاميرات شبكية عالية الدقة', sort_order: 7, filter_key: 'cameras' },
    { slug: 'hdd-ssd', name: 'هاردات و SSD', description: 'هاردات تخزين داخلية وخارجية', sort_order: 8, filter_key: 'storage' },
    { slug: 'rams', name: 'رامات', description: 'رامات DDR4 و DDR5', sort_order: 9 },
    { slug: 'gpu', name: 'كروت شاشة', description: 'كروت شاشة Nvidia و AMD', sort_order: 10 },
    { slug: 'processors', name: 'بروسيسورات', description: 'معالجات Intel و AMD', sort_order: 11 },
    { slug: 'psu', name: 'باور سبلاي', description: 'مصادر طاقة لجميع الاستخدامات', sort_order: 12 },
    { slug: 'networking', name: 'شبكات وراوترات', description: 'راوترات و سويتشات', sort_order: 13 },
    { slug: 'pc-accessories', name: 'إكسسوارات الكمبيوتر', description: 'كيبورد، ماوس، هيدفون', sort_order: 14 },
    { slug: 'mobile-accessories', name: 'إكسسوارات الموبايل', description: 'شواحن، كفر، سماعات', sort_order: 15 },
    { slug: 'wifi-extenders', name: 'أجهزة تقوية الشبكة', description: 'مقويات إشارة Wi-Fi', sort_order: 16 },
    { slug: 'cables', name: 'كابلات ووصلات', description: 'HDMI، USB، كابلات شبكة', sort_order: 17 },
    { slug: 'camera-supplies', name: 'مستلزمات كاميرات المراقبة', description: 'بطاريات، أرفف، وصلات', sort_order: 18 },
    { slug: 'services', name: 'خدمات وتركيب', description: 'تركيب وصيانة جميع المنتجات', sort_order: 19 },
    { slug: 'deals', name: 'عروض وخصومات', description: 'أقوى العروض والخصومات', sort_order: 20, is_featured: true },
  ]

  for (const cat of categories) {
    const filterSchema = cat.filter_key ? DEFAULT_FILTERS[cat.filter_key] : []
    const { data } = await client.from('categories').insert({
      slug: cat.slug,
      name: cat.name,
      description: cat.description ?? null,
      image_url: cat.image_url ?? null,
      sort_order: cat.sort_order,
      is_visible: true,
      is_featured: cat.is_featured ?? false,
      filter_schema: filterSchema,
    }).select('id').single()
    if (data && cat.slug === 'services') {
      // continue
    }
  }

  // Seed brands
  const brands = [
    { slug: 'hp', name: 'HP' },
    { slug: 'lenovo', name: 'Lenovo' },
    { slug: 'dell', name: 'Dell' },
    { slug: 'asus', name: 'Asus' },
    { slug: 'acer', name: 'Acer' },
    { slug: 'msi', name: 'MSI' },
    { slug: 'apple', name: 'Apple' },
    { slug: 'dahua', name: 'Dahua' },
    { slug: 'hikvision', name: 'Hikvision' },
    { slug: 'ezviz', name: 'Ezviz' },
    { slug: 'samsung', name: 'Samsung' },
    { slug: 'seagate', name: 'Seagate' },
    { slug: 'wd', name: 'Western Digital' },
    { slug: 'kingston', name: 'Kingston' },
    { slug: 'corsair', name: 'Corsair' },
    { slug: 'gskill', name: 'G.Skill' },
    { slug: 'nvidia', name: 'Nvidia' },
    { slug: 'amd', name: 'AMD' },
    { slug: 'intel', name: 'Intel' },
    { slug: 'tp-link', name: 'TP-Link' },
  ]
  for (const brand of brands) {
    await client.from('brands').insert(brand)
  }

  // Seed sample products
  const { data: catLaptops } = await client.from('categories').select('id').eq('slug', 'laptops').single()
  const { data: catCameras } = await client.from('categories').select('id').eq('slug', 'cameras').single()
  const { data: catHdd } = await client.from('categories').select('id').eq('slug', 'hdd-ssd').single()
  const { data: brandLenovo } = await client.from('brands').select('id').eq('slug', 'lenovo').single()
  const { data: brandDahua } = await client.from('brands').select('id').eq('slug', 'dahua').single()
  const { data: brandHp } = await client.from('brands').select('id').eq('slug', 'hp').single()
  const { data: brandSeagate } = await client.from('brands').select('id').eq('slug', 'seagate').single()

  const sampleProducts = [
    {
      slug: 'lenovo-thinkpad-e14-gen5',
      sku: 'LNV-E14-G5',
      name: 'لاب توب Lenovo ThinkPad E14 Gen 5',
      brand_id: brandLenovo?.id,
      category_id: catLaptops?.id,
      model: 'ThinkPad E14 Gen 5',
      short_description: 'لاب توب أعمال قوي بمعالج Intel Core i5 الجيل الثالث عشر، شاشة 14 بوصة FHD، وزن خفيف ومتين.',
      description: 'لاب توب Lenovo ThinkPad E14 Gen 5 مصمم لرجال الأعمال والمحترفين. يأتي بمعالج Intel Core i5-1335U، ذاكرة عشوائية 8 جيجا DDR4، قرص SSD 512 جيجا NVMe، شاشة 14 بوصة FHD IPS مضادة للتوهج. مزود بـ Windows 11 Pro ولوحة مفاتيح بإضاءة خلفية وكاميرا ويب IR.',
      specs: { المعالج: 'Intel Core i5-1335U', الرام: '8GB DDR4', التخزين: '512GB NVMe SSD', الشاشة: '14 بوصة FHD IPS', 'كرت الشاشة': 'Intel Iris Xe', 'نظام التشغيل': 'Windows 11 Pro', البطارية: 'حتى 12 ساعة' },
      price_original: 28500,
      price: 25999,
      discount_percent: 9,
      stock: 12,
      is_new: true,
      is_featured: true,
      is_on_sale: true,
      is_best_seller: true,
      tags: ['لاب توب', 'أعمال', 'لينوفو', 'i5'],
      meta_title: 'لاب توب Lenovo ThinkPad E14 Gen 5 | Hi-Tech',
      meta_description: 'اشترِ لاب توب Lenovo ThinkPad E14 Gen 5 من Hi-Tech بلقاس - Intel i5، 8GB RAM، 512GB SSD، شاشة 14 بوصة.',
    },
    {
      slug: 'hp-pavilion-15-ryzen5',
      sku: 'HP-PV15-R5',
      name: 'لاب توب HP Pavilion 15 AMD Ryzen 5',
      brand_id: brandHp?.id,
      category_id: catLaptops?.id,
      model: 'Pavilion 15-eg3009nia',
      short_description: 'لاب توب HP Pavilion بمعالج Ryzen 5، شاشة 15.6 بوصة FHD، مناسب للعمل والترفيه.',
      description: 'لاب توب HP Pavilion 15 بمعالج AMD Ryzen 5 5625U، ذاكرة 8GB DDR4، SSD 512GB، شاشة 15.6 بوصة FHD IPS، كارت شاشة AMD Radeon مدمج. مناسب للعمل والدراسة والترفيه، تصميم أنيق ومتين.',
      specs: { المعالج: 'AMD Ryzen 5 5625U', الرام: '8GB DDR4', التخزين: '512GB NVMe SSD', الشاشة: '15.6 بوصة FHD IPS', 'كرت الشاشة': 'AMD Radeon Graphics' },
      price_original: 22500,
      price: 19999,
      discount_percent: 11,
      stock: 8,
      is_featured: true,
      is_on_sale: true,
      tags: ['لاب توب', 'HP', 'ريزن'],
      meta_title: 'لاب توب HP Pavilion 15 Ryzen 5 | Hi-Tech',
      meta_description: 'اشترِ لاب توب HP Pavilion 15 Ryzen 5 من Hi-Tech.',
    },
    {
      slug: 'dahua-ipc-hdw2231t',
      sku: 'DH-IPC-HDW2231T',
      name: 'كاميرا Dahua IPC-HDW2231T IP',
      brand_id: brandDahua?.id,
      category_id: catCameras?.id,
      model: 'IPC-HDW2231T-AS-S2',
      short_description: 'كاميرا IP داخلية 2 ميجا بكسل، رؤية ليلية 30 متر، PoE.',
      description: 'كاميرا Dahua IP داخلية بدقة 2 ميجا (1080P)، تدعم الرؤية الليلية حتى 30 متر بتقنية IR، تدعم PoE وIP67 مقاومة للماء والغبار، مناسبة للمنزل والمكتب والمحلات.',
      specs: { الدقة: '2 ميجا (1080P)', 'نوع العدسة': '3.6mm', 'الرؤية الليلية': '30 متر', 'مقاومة الماء': 'IP67', الطاقة: 'DC 12V / PoE' },
      price_original: 1800,
      price: 1499,
      discount_percent: 17,
      stock: 25,
      is_new: true,
      is_featured: true,
      is_on_sale: true,
      is_best_seller: true,
      tags: ['كاميرا', 'dahua', 'ip'],
      meta_title: 'كاميرا Dahua IPC-HDW2231T | Hi-Tech',
      meta_description: 'كاميرا Dahua IP 2MP من Hi-Tech - رؤية ليلية 30 متر.',
    },
    {
      slug: 'dahua-dvr-xvr-8ch',
      sku: 'DH-XVR1B08-I',
      name: 'مسجل Dahua XVR 8 قنوات',
      brand_id: brandDahua?.id,
      category_id: null,
      model: 'XVR1B08-I',
      short_description: 'جهاز تسجيل 8 قنوات Full HD يدعم جميع التقنيات.',
      description: 'مسجل Dahua XVR 8 قنوات يدعم جميع تقنيات الكاميرات (HDCVI/AHD/TVI/CVBS/IP)، يدعم دقة 1080N/720P، تقنية H.265+ للضغط، تطبيق DMSS للمتابعة عن بُعد.',
      specs: { القنوات: '8 قنوات', الدقة: '1080N', الضغط: 'H.265+', 'دعم IP': 'حتى 2 كاميرا IP', التطبيق: 'DMSS / iDMSS' },
      price_original: 3200,
      price: 2799,
      discount_percent: 13,
      stock: 10,
      is_featured: true,
      is_on_sale: true,
      tags: ['dvr', 'dahua', 'تسجيل'],
    },
    {
      slug: 'seagate-barracuda-2tb',
      sku: 'ST-ST2000DM008',
      name: 'هارد Seagate BarraCuda 2TB',
      brand_id: brandSeagate?.id,
      category_id: catHdd?.id,
      model: 'ST2000DM008',
      short_description: 'هارد ديسك 2 تيرا SATA III 7200RPM لأجهزة الكمبيوتر المكتبية.',
      description: 'هارد Seagate BarraCuda 2TB SATA III بسرعة 7200RPM وذاكرة 256MB cache. مناسب لأجهزة الكمبيوتر المكتبية لتخزين الملفات والبرامج والألعاب.',
      specs: { السعة: '2 تيرا', النوع: 'HDD', السرعة: '7200RPM', الواجهة: 'SATA III 6Gb/s', 'حجم الذاكرة': '256MB Cache' },
      price_original: 2200,
      price: 1899,
      discount_percent: 14,
      stock: 15,
      is_featured: true,
      is_on_sale: true,
      is_best_seller: true,
      tags: ['هارد', 'seagate'],
    },
    {
      slug: 'corsair-vengeance-16gb-ddr4',
      sku: 'CMK16GX4M2B3200C16',
      name: 'رامات Corsair Vengeance 16GB DDR4',
      brand_id: null,
      category_id: null,
      model: 'CMK16GX4M2B3200C16',
      short_description: 'رامات Corsair Vengeance LPX 16GB (2x8) DDR4 3200MHz.',
      description: 'رامات Corsair Vengeance LPX 16GB (2x8GB) DDR4 بسرعة 3200MHz، تصميم منخفض الحرارة مع مشتت ألمنيوم، متوافقة مع Intel و AMD.',
      specs: { السعة: '16GB (2x8GB)', النوع: 'DDR4', السرعة: '3200MHz', الجهد: '1.35V' },
      price_original: 1800,
      price: 1499,
      discount_percent: 17,
      stock: 20,
      is_new: true,
      tags: ['رام', 'corsair', 'ddr4'],
    },
  ]

  // Demo products removed: the real catalog is imported from Hi-Tech Pro.
  for (const p of [] as typeof sampleProducts) {
    const { data: product } = await client.from('products').insert({
      slug: p.slug,
      sku: p.sku,
      barcode: p.sku,
      name: p.name,
      brand_id: p.brand_id ?? null,
      category_id: p.category_id ?? null,
      model: p.model ?? null,
      short_description: p.short_description ?? null,
      description: p.description ?? null,
      specs: p.specs ?? {},
      tags: p.tags ?? [],
      price_original: p.price_original,
      price: p.price,
      discount_percent: p.discount_percent,
      stock: p.stock,
      low_stock_threshold: 3,
      is_available: true,
      is_new: p.is_new ?? false,
      is_featured: p.is_featured ?? false,
      is_on_sale: p.is_on_sale ?? false,
      is_best_seller: p.is_best_seller ?? false,
      meta_title: p.meta_title ?? p.name,
      meta_description: p.meta_description ?? p.short_description,
    }).select('id').single()

    if (product) {
      // Add a placeholder main image
      await client.from('product_images').insert({
        product_id: product.id,
        url: `https://placehold.co/600x600/1E40AF/FFFFFF?text=${encodeURIComponent(p.name.substring(0, 20))}`,
        thumbnail_url: `https://placehold.co/300x300/1E40AF/FFFFFF?text=${encodeURIComponent(p.name.substring(0, 20))}`,
        sort_order: 0,
        is_main: true,
      })
    }
  }

  // Seed payment methods
  const paymentMethods = [
    { code: 'cash', name: 'كاش', icon: '💵', sort_order: 1, instructions: 'الدفع نقدًا عند الاستلام من المحل.' },
    { code: 'vodafone_cash', name: 'فودافون كاش', icon: '📱', account_number: '01002261030', sort_order: 2, instructions: 'التحويل على رقم 01002261030 وإرسال صورة التحويل على واتساب.' },
    { code: 'instapay', name: 'إنستا باي', icon: '⚡', account_number: 'hitech@instapay', sort_order: 3, instructions: 'التحويل عبر InstaPay على الحساب المذكور.' },
    { code: 'bank_transfer', name: 'تحويل بنكي', icon: '🏦', account_number: '0000 0000 0000', sort_order: 4, instructions: 'التحويل البنكي وإرسال صورة الإيصال.' },
  ]
  for (const pm of paymentMethods) {
    await client.from('payment_methods').insert(pm)
  }

  // Seed services
  const services = [
    { slug: 'install-cameras', title: 'تركيب كاميرات المراقبة', description: 'تركيب احترافي لكاميرات المراقبة في المنازل والمحلات والمكاتب.', icon: 'Camera', sort_order: 1 },
    { slug: 'maintain-cameras', title: 'صيانة كاميرات المراقبة', description: 'صيانة دورية وإصلاح أعطال الكاميرات وأجهزة التسجيل.', icon: 'Wrench', sort_order: 2 },
    { slug: 'install-dvr-nvr', title: 'تركيب DVR / NVR', description: 'تركيب وبرمجة أجهزة التسجيل.', icon: 'HardDrive', sort_order: 3 },
    { slug: 'pc-maintenance', title: 'صيانة الكمبيوتر', description: 'تنظيف، فحص، ترقية قطع الكمبيوتر المكتبي.', icon: 'Cpu', sort_order: 4 },
    { slug: 'laptop-maintenance', title: 'صيانة اللاب توب', description: 'تغيير كيبورد، شاشة، بطارية، تنظيف وتحديث.', icon: 'Laptop', sort_order: 5 },
    { slug: 'network-setup', title: 'تركيب الشبكات', description: 'تمديد شبكات داخلية للشركات والمنازل.', icon: 'Network', sort_order: 6 },
    { slug: 'wifi-setup', title: 'تقوية شبكة Wi-Fi', description: 'تركيب مقويات الإشارة وتوزيع الشبكة.', icon: 'Wifi', sort_order: 7 },
    { slug: 'accessories-install', title: 'تركيب الإكسسوارات', description: 'تركيب طابعات، سكانر، إكسسوارات المكتب.', icon: 'Plug', sort_order: 8 },
  ]
  for (const s of services) {
    await client.from('services').insert({ ...s, is_active: true })
  }

  // Seed banners
  const banners = [
    {
      title: 'لاب توبات، كمبيوتر، كاميرات مراقبة',
      subtitle: 'أحدث الموديلات بضمان حقيقي',
      description: 'اكتشف تشكيلتنا من اللاب توبات، أجهزة الكمبيوتر، وكاميرات المراقبة بأسعار منافسة وخدمة احترافية في بلقاس.',
      image_url: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=1600&q=80&auto=format&fit=crop',
      cta_label: 'تصفح اللابتوبات',
      cta_link: '/category/laptops',
      sort_order: 1,
      is_active: true,
    },
    {
      title: 'كاميرات مراقبة عالية الدقة',
      subtitle: 'تركيب احترافي وضمان سنة',
      description: 'كاميرات Dahua و Hikvision بدقة 2MP حتى 8MP، مع خدمة التركيب والصيانة في بلقاس.',
      image_url: 'https://images.unsplash.com/photo-1557597774-9d273605dfa9?w=1600&q=80&auto=format&fit=crop',
      cta_label: 'شاهد الكاميرات',
      cta_link: '/category/cameras',
      sort_order: 2,
      is_active: true,
    },
    {
      title: 'خدمات الصيانة والتركيب',
      subtitle: 'فنيون متخصصون',
      description: 'صيانة كمبيوتر، لاب توب، كاميرات، شبكات. خدمة سريعة وأسعار منافسة.',
      image_url: 'https://images.unsplash.com/photo-1581092918056-0c4c3acd3789?w=1600&q=80&auto=format&fit=crop',
      cta_label: 'تواصل معنا',
      cta_link: '/contact',
      sort_order: 3,
      is_active: true,
    },
  ]
  for (const b of banners) {
    await client.from('banners').insert(b)
  }

  // Seed offers
  const { data: offer1 } = await client.from('offers').insert({
    slug: 'back-to-school',
    title: 'عرض العودة للمدارس',
    description: 'خصومات قوية على اللابتوبات حتى 20%',
    image_url: 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=1200&q=80&auto=format&fit=crop',
    discount_percent: 20,
    is_active: true,
    sort_order: 1,
  }).select('id').single()

  if (offer1) {
    const { data: prods } = await client.from('products').select('id').eq('category_id', catLaptops?.id ?? '')
    if (prods) {
      for (const p of prods) {
        await client.from('offer_products').insert({ offer_id: offer1.id, product_id: p.id })
      }
    }
  }
}