// Client-callable server functions for the Hi-Tech storefront.
// Route loaders/components import ONLY from this module — it never exposes
// server-only modules to the client bundle.

import { createServerFn } from '@tanstack/react-start'
import type { ProductListFilters } from './types'

export const getSettings = createServerFn({ method: 'GET' }).handler(async () => {
  const { getSettings: impl } = await import('./data.server')
  return impl()
})

export const getCategories = createServerFn({ method: 'GET' }).handler(async () => {
  const { getCategories: impl } = await import('./data.server')
  return impl()
})

export const getVisibleCategories = createServerFn({ method: 'GET' }).handler(async () => {
  const { getVisibleCategories: impl } = await import('./data.server')
  return impl()
})

export const getFeaturedCategories = createServerFn({ method: 'GET' }).handler(async () => {
  const { getFeaturedCategories: impl } = await import('./data.server')
  return impl()
})

export const getCategoryBySlug = createServerFn({ method: 'GET' })
  .validator((data: { slug: string }) => data)
  .handler(async ({ data }) => {
    const { getCategoryBySlug: impl } = await import('./data.server')
    return impl(data.slug)
  })

export const getBrands = createServerFn({ method: 'GET' }).handler(async () => {
  const { getBrands: impl } = await import('./data.server')
  return impl()
})

export const getVisibleBrands = createServerFn({ method: 'GET' }).handler(async () => {
  const { getVisibleBrands: impl } = await import('./data.server')
  return impl()
})

export const getProducts = createServerFn({ method: 'GET' })
  .validator((data: ProductListFilters) => data)
  .handler(async ({ data }) => {
    const { getProducts: impl } = await import('./data.server')
    return impl(data ?? {})
  })

export const getProductBySlug = createServerFn({ method: 'GET' })
  .validator((data: { slug: string }) => data)
  .handler(async ({ data }) => {
    const { getProductBySlug: impl } = await import('./data.server')
    return impl(data.slug)
  })

export const getProductById = createServerFn({ method: 'GET' })
  .validator((data: { id: string }) => data)
  .handler(async ({ data }) => {
    const { getProductById: impl } = await import('./data.server')
    return impl(data.id)
  })

export const getActiveBanners = createServerFn({ method: 'GET' }).handler(async () => {
  const { getActiveBanners: impl } = await import('./data.server')
  return impl()
})

export const getActiveServices = createServerFn({ method: 'GET' }).handler(async () => {
  const { getActiveServices: impl } = await import('./data.server')
  return impl()
})

export const getActivePaymentMethods = createServerFn({ method: 'GET' }).handler(async () => {
  const { getActivePaymentMethods: impl } = await import('./data.server')
  return impl()
})

export const getActiveOffers = createServerFn({ method: 'GET' }).handler(async () => {
  const { getActiveOffers: impl } = await import('./data.server')
  return impl()
})

export const searchProducts = createServerFn({ method: 'GET' })
  .validator((data: { query: string; limit?: number }) => data)
  .handler(async ({ data }) => {
    const { searchProducts: impl } = await import('./data.server')
    return impl(data.query, data.limit ?? 20)
  })

export const getPage = createServerFn({ method: 'GET' })
  .validator((data: { slug: string }) => data)
  .handler(async ({ data }) => {
    const { getPage: impl } = await import('./data.server')
    return impl(data.slug)
  })

export const getOrders = createServerFn({ method: 'GET' })
  .validator((data: { status?: string; search?: string }) => data)
  .handler(async ({ data }) => {
    const { getOrders: impl } = await import('./data.server')
    return impl(data ?? {})
  })

export const getCustomers = createServerFn({ method: 'GET' }).handler(async () => {
  const { getCustomers: impl } = await import('./data.server')
  return impl()
})

export const getDashboardStats = createServerFn({ method: 'GET' }).handler(async () => {
  const { getDashboardStats: impl } = await import('./data.server')
  return impl()
})
