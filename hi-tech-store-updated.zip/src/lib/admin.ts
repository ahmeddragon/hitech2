// Hi-Tech Store: Admin server functions
// All mutations live here. Authenticated via session.

import { createServerFn } from '@tanstack/react-start'
import { IMPORT_CATEGORIES, slugFromSku, type ImportRow } from './import-products'
import type {
  AdminUser,
  Banner,
  Brand,
  Category,
  OrderStatus,
  PaymentMethod,
  Product,
  Service,
  Settings,
} from './types'

// Returns the best available data client for the current request: the
// service-role admin client when the runtime exposes the key, otherwise the
// signed-in admin's session through the installed facade (RLS: authenticated).
async function getAdminClient() {
  const { getStoreDb } = await import('./db.server')
  return getStoreDb()
}

async function requireAdmin() {
  const ctx = await requireUser()
  // Row-Level Security only returns rows to an active administrator, so a
  // non-empty result is the authorization decision itself.
  const { record, error } = await findAdminRow(ctx.admin, ctx.user.id, ctx.user.email)
  if (error || !record) throw new Error('UNAUTHORIZED')
  if (record.is_active === false) throw new Error('هذا الحساب موقوف')
  return ctx
}

async function ensureAdminUserRecord(email: string, full_name?: string | null) {
  const admin = await getAdminClient()
  const { data: existing } = await admin.from('admin_users').select('*').eq('email', email).single()
  if (existing) return existing
  await admin.from('admin_users').insert({
    email,
    full_name: full_name ?? null,
    role: 'admin',
    is_active: true,
  })
  await markAdminBootstrapped(admin)
  const { data } = await admin.from('admin_users').select('*').eq('email', email).single()
  return data
}

/**
 * Records on the publicly readable settings row that the store already has an
 * administrator. The login page uses this flag to decide between the first-run
 * setup form and the normal sign-in form, and it stays accurate even when the
 * signed-in account is stored in the auth service rather than in `admin_users`.
 */
async function markAdminBootstrapped(admin: Awaited<ReturnType<typeof getAdminClient>>) {
  try {
    // upsert keeps this working even if the settings row was never seeded.
    await admin.from('settings').upsert({ id: 'site', admin_bootstrapped: true })
  } catch {
    // Never fatal: the flag only picks which login form to render.
  }
}

/**
 * Tells whether the dashboard still has no administrator. Reads the publicly
 * readable settings flag, which stays accurate once the own row exists.
 */
async function adminBootstrapOpen(admin: Awaited<ReturnType<typeof getAdminClient>>) {
  try {
    const { data } = await admin
      .from('settings')
      .select('admin_bootstrapped')
      .eq('id', 'site')
      .limit(1)
    return ((data ?? [])[0] as any)?.admin_bootstrapped !== true
  } catch {
    // Fall through: Row-Level Security still refuses the insert if an admin exists.
    return true
  }
}

// ----------------------------------------------------------------------------
// Auth
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
// Auth guards
// ----------------------------------------------------------------------------

/**
 * Resolves the signed-in account from the request's bearer token.
 *
 * Authorization is NOT decided here: every query below still runs against the
 * database with the same token, so Row-Level Security is what actually grants
 * or denies access. We only read the token claims to know which account the
 * caller claims to be, which is enough to locate the matching admin row.
 */
async function requireUser() {
  const { getRequest } = await import('@tanstack/react-start/server')
  const request = getRequest()
  const auth = request.headers.get('authorization')
  const prefix = 'Bearer '
  const bearer = auth && auth.startsWith(prefix) ? auth.slice(prefix.length) : null
  if (!bearer) throw new Error('UNAUTHORIZED')
  const { decodeJwtPayload } = await import('./db.server')
  const claims = decodeJwtPayload(bearer)
  const exp = typeof claims?.exp === 'number' ? claims.exp : 0
  if (!claims || !exp || exp * 1000 <= Date.now()) {
    throw new Error('انتهت صلاحية الجلسة. يرجى تسجيل الخروج ثم الدخول من جديد.')
  }
  // SECURITY: the token's claims above are unsigned data until the auth
  // service confirms the token. Without this check, a forged token carrying an
  // admin's e-mail would be accepted whenever the service-role client (which
  // bypasses RLS) is in use. The identity used from here on is the verified one.
  const { createNubaseUserClient } = await import('../integrations/nubase/server-client.server')
  const { data: verified, error: verifyError } = await createNubaseUserClient(bearer).auth.getUser()
  const verifiedUser = verified?.user
  if (verifyError || !verifiedUser?.id || !verifiedUser.email) throw new Error('UNAUTHORIZED')
  const email = verifiedUser.email.trim().toLowerCase()
  const id = verifiedUser.id
  const admin = await getAdminClient()
  return { user: { email, id }, accessToken: bearer, admin }
}

/**
 * Resolves the signed-in account's admin access and self-heals the first-run
 * bootstrap.
 *
 * Why this exists: when the auth service is configured to send a confirmation
 * e-mail, `signUp` finishes *without* a session, so the old flow never reached
 * `claimFirstAdminFn` — the account was created in the auth service but no
 * `admin_users` row was ever written. The owner then kept landing on the
 * "first admin" form. Now the account that signs in while no admin exists is
 * promoted automatically, so confirming the e-mail is enough to get in.
 */
/**
 * Finds the administrator row that belongs to the signed-in account. Row-Level
 * Security only returns rows an active admin may see, so a returned row is also
 * the authorization decision.
 */
async function findAdminRow(
  admin: Awaited<ReturnType<typeof getAdminClient>>,
  userId: string,
  email: string,
): Promise<{ record: AdminUser | null; error: unknown }> {
  const byId = await admin.from('admin_users').select('*').eq('user_id', userId).limit(1)
  if (byId.error) return { record: null, error: byId.error }
  const byIdRow = ((byId.data ?? [])[0] ?? null) as AdminUser | null
  if (byIdRow) return { record: byIdRow, error: null }

  const byEmail = await admin.from('admin_users').select('*').eq('email', email).limit(1)
  if (byEmail.error) return { record: null, error: byEmail.error }
  return { record: (((byEmail.data ?? [])[0] ?? null) as AdminUser | null), error: null }
}

async function resolveAdminAccess() {
  const { user, admin } = await requireUser()
  const email = user.email
  const userId = user.id

  const found = await findAdminRow(admin, userId, email)
  if (found.error) throw new Error('UNAUTHORIZED')
  const record = found.record

  if (record) {
    if (record.is_active === false) throw new Error('هذا الحساب موقوف. تواصل مع مدير النظام')
    // Bind the row to the auth account the first time it signs in.
    if (!record.user_id) {
      await admin.from('admin_users').update({ user_id: userId }).eq('id', record.id)
    }
    await admin.from('admin_users').update({ last_login_at: new Date().toISOString() }).eq('id', record.id)
    await markAdminBootstrapped(admin)
    return { user: { email, id: userId }, record, bootstrapped: false }
  }

  // Not on the admin list. Only the very first account may register itself,
  // and only while the dashboard still has no administrator at all.
  if (!(await adminBootstrapOpen(admin))) {
    throw new Error('هذا الحساب لا يملك صلاحية الدخول إلى لوحة التحكم')
  }

  const { error: insErr } = await admin.from('admin_users').insert({
    email,
    user_id: userId,
    role: 'admin',
    is_active: true,
  })
  if (insErr) {
    throw new Error('تعذّر إكمال إعداد حساب المدير. سجّل الخروج ثم الدخول من جديد وحاول مرة أخرى.')
  }
  await markAdminBootstrapped(admin)
  const created = await findAdminRow(admin, userId, email)
  return {
    user: { email, id: userId },
    record: created.record,
    bootstrapped: true,
  }
}

/**
 * Called right after the client-side sign-in so non-admin accounts are
 * rejected before they can enter the dashboard, and so the first verified
 * account can complete the initial setup.
 */
export const resolveAdminSessionFn = createServerFn({ method: 'GET' }).handler(async () => resolveAdminAccess())

// Backwards-compatible alias kept for callers of the earlier name.
export const verifyAdminSessionFn = createServerFn({ method: 'GET' }).handler(async () => resolveAdminAccess())

/**
 * First-run bootstrap: promotes the currently signed-in user to admin.
 * Only allowed while no admin exists yet.
 */
export const claimFirstAdminFn = createServerFn({ method: 'POST' })
  .inputValidator((data: { full_name?: string | null }) => data)
  .handler(async ({ data }) => {
    const { user, admin } = await requireUser()
    if (!(await adminBootstrapOpen(admin))) {
      throw new Error('يوجد حساب مدير بالفعل. الرجاء تسجيل الدخول.')
    }
    const email = user.email
    if (!email.includes('@')) throw new Error('البريد الإلكتروني غير صحيح')
    const { error } = await admin.from('admin_users').insert({
      email,
      user_id: user.id,
      full_name: data.full_name ?? null,
      role: 'admin',
      is_active: true,
    })
    if (error) throw new Error(error.message)
    await markAdminBootstrapped(admin)
    const { data: rows } = await admin
      .from('admin_users')
      .select('*')
      .eq('user_id', user.id)
      .limit(1)
    return { user: { email, id: user.id }, record: (((rows ?? [])[0] ?? null) as AdminUser | null) }
  })

export const getCurrentAdminFn = createServerFn({ method: 'GET' }).handler(async () => {
  try {
    const { user, admin } = await requireAdmin()
    const { data } = await admin.from('admin_users').select('*').eq('email', user.email ?? '').single()
    return { user: { email: user.email, id: user.id }, record: data }
  } catch {
    return null
  }
})

// ----------------------------------------------------------------------------
// Settings
// ----------------------------------------------------------------------------

export const updateSettingsFn = createServerFn({ method: 'POST' })
  .inputValidator((data: Partial<Settings>) => data)
  .handler(async ({ data }) => {
    await requireAdmin()
    const admin = await getAdminClient()
    const { error } = await admin.from('settings').update(data).eq('id', 'site')
    if (error) throw new Error(error.message)
    return { ok: true }
  })

// ----------------------------------------------------------------------------
// Categories
// ----------------------------------------------------------------------------

export const upsertCategoryFn = createServerFn({ method: 'POST' })
  .inputValidator((data: Partial<Category> & { id?: string }) => data)
  .handler(async ({ data }) => {
    await requireAdmin()
    const admin = await getAdminClient()
    if (data.id) {
      const { id, ...rest } = data
      await admin.from('categories').update(rest).eq('id', id)
      return { id }
    }
    const { id, ...rest } = data
    const { data: row } = await admin.from('categories').insert(rest).select('id').single()
    return { id: row?.id }
  })

export const deleteCategoryFn = createServerFn({ method: 'POST' })
  .inputValidator((data: { id: string }) => data)
  .handler(async ({ data }) => {
    await requireAdmin()
    const admin = await getAdminClient()
    await admin.from('categories').delete().eq('id', data.id)
    return { ok: true }
  })

// ----------------------------------------------------------------------------
// Brands
// ----------------------------------------------------------------------------

export const upsertBrandFn = createServerFn({ method: 'POST' })
  .inputValidator((data: Partial<Brand> & { id?: string }) => data)
  .handler(async ({ data }) => {
    await requireAdmin()
    const admin = await getAdminClient()
    if (data.id) {
      const { id, ...rest } = data
      await admin.from('brands').update(rest).eq('id', id)
      return { id }
    }
    const { id, ...rest } = data
    const { data: row } = await admin.from('brands').insert(rest).select('id').single()
    return { id: row?.id }
  })

export const deleteBrandFn = createServerFn({ method: 'POST' })
  .inputValidator((data: { id: string }) => data)
  .handler(async ({ data }) => {
    await requireAdmin()
    const admin = await getAdminClient()
    await admin.from('brands').delete().eq('id', data.id)
    return { ok: true }
  })

// ----------------------------------------------------------------------------
// Products
// ----------------------------------------------------------------------------

export const upsertProductFn = createServerFn({ method: 'POST' })
  .inputValidator((data: Partial<Product> & { id?: string }) => data)
  .handler(async ({ data }) => {
    await requireAdmin()
    const admin = await getAdminClient()
    if (data.id) {
      // `images`/`main_image`/`brand`/`category` are joined or relational fields,
      // not columns on the products table — never send them to the update.
      const { id, images, main_image, brand, category, ...rest } = data as any
      // Make sure price/discount stay consistent.
      if (rest.price_original !== undefined && rest.price !== undefined) {
        if (rest.price_original > 0 && rest.price < rest.price_original) {
          rest.discount_percent = Math.round(((rest.price_original - rest.price) / rest.price_original) * 100 * 100) / 100
          rest.is_on_sale = true
        } else {
          rest.discount_percent = 0
        }
      }
      const { error } = await admin.from('products').update({ ...rest, updated_at: new Date().toISOString() }).eq('id', id)
      if (error) throw new Error(error.message)
      return { id }
    }
    const { id, images, main_image, brand, category, ...rest } = data as any
    const { data: row, error } = await admin.from('products').insert(rest).select('id').single()
    if (error) throw new Error(error.message)
    return { id: row?.id }
  })

export const deleteProductFn = createServerFn({ method: 'POST' })
  .inputValidator((data: { id: string }) => data)
  .handler(async ({ data }) => {
    await requireAdmin()
    const admin = await getAdminClient()
    await admin.from('products').delete().eq('id', data.id)
    return { ok: true }
  })

export const duplicateProductFn = createServerFn({ method: 'POST' })
  .inputValidator((data: { id: string }) => data)
  .handler(async ({ data }) => {
    await requireAdmin()
    const admin = await getAdminClient()
    const { data: p } = await admin.from('products').select('*').eq('id', data.id).single()
    if (!p) throw new Error('Not found')
    const { id, created_at, updated_at, images, main_image, brand, category, ...rest } = p as any
    const slug = `${rest.slug}-copy-${Date.now().toString(36)}`
    const { data: row } = await admin.from('products').insert({ ...rest, slug, sku: rest.sku ? `${rest.sku}-COPY` : null, name: `${rest.name} (نسخة)` }).select('id').single()
    return { id: row?.id }
  })

export const addProductImageFn = createServerFn({ method: 'POST' })
  .inputValidator((data: { product_id: string; url: string; thumbnail_url?: string | null; is_main?: boolean; sort_order?: number }) => data)
  .handler(async ({ data }) => {
    await requireAdmin()
    const admin = await getAdminClient()
    if (data.is_main) {
      await admin.from('product_images').update({ is_main: false }).eq('product_id', data.product_id)
    }
    const { data: row } = await admin.from('product_images').insert({
      product_id: data.product_id,
      url: data.url,
      thumbnail_url: data.thumbnail_url ?? null,
      is_main: !!data.is_main,
      sort_order: data.sort_order ?? 0,
    }).select('id').single()
    return { id: row?.id }
  })

export const deleteProductImageFn = createServerFn({ method: 'POST' })
  .inputValidator((data: { id: string }) => data)
  .handler(async ({ data }) => {
    await requireAdmin()
    const admin = await getAdminClient()
    await admin.from('product_images').delete().eq('id', data.id)
    return { ok: true }
  })

export const reorderProductImageFn = createServerFn({ method: 'POST' })
  .inputValidator((data: { id: string; sort_order: number }) => data)
  .handler(async ({ data }) => {
    await requireAdmin()
    const admin = await getAdminClient()
    await admin.from('product_images').update({ sort_order: data.sort_order }).eq('id', data.id)
    return { ok: true }
  })

// ----------------------------------------------------------------------------
// Banners
// ----------------------------------------------------------------------------

export const upsertBannerFn = createServerFn({ method: 'POST' })
  .inputValidator((data: Partial<Banner> & { id?: string }) => data)
  .handler(async ({ data }) => {
    await requireAdmin()
    const admin = await getAdminClient()
    if (data.id) {
      const { id, ...rest } = data
      await admin.from('banners').update(rest).eq('id', id)
      return { id }
    }
    const { id, ...rest } = data
    const { data: row } = await admin.from('banners').insert(rest).select('id').single()
    return { id: row?.id }
  })

export const deleteBannerFn = createServerFn({ method: 'POST' })
  .inputValidator((data: { id: string }) => data)
  .handler(async ({ data }) => {
    await requireAdmin()
    const admin = await getAdminClient()
    await admin.from('banners').delete().eq('id', data.id)
    return { ok: true }
  })

// ----------------------------------------------------------------------------
// Offers
// ----------------------------------------------------------------------------

export const upsertOfferFn = createServerFn({ method: 'POST' })
  .inputValidator((data: { id?: string; slug: string; title: string; description?: string | null; image_url?: string | null; discount_percent: number; is_active: boolean; sort_order?: number; starts_at?: string | null; ends_at?: string | null; product_ids: string[] }) => data)
  .handler(async ({ data }) => {
    await requireAdmin()
    const admin = await getAdminClient()
    const { id, product_ids, ...rest } = data
    if (id) {
      await admin.from('offers').update(rest).eq('id', id)
      await admin.from('offer_products').delete().eq('offer_id', id)
      for (const pid of product_ids) {
        await admin.from('offer_products').insert({ offer_id: id, product_id: pid })
      }
      return { id }
    }
    const { data: row } = await admin.from('offers').insert(rest).select('id').single()
    if (row) {
      for (const pid of product_ids) {
        await admin.from('offer_products').insert({ offer_id: row.id, product_id: pid })
      }
    }
    return { id: row?.id }
  })

export const deleteOfferFn = createServerFn({ method: 'POST' })
  .inputValidator((data: { id: string }) => data)
  .handler(async ({ data }) => {
    await requireAdmin()
    const admin = await getAdminClient()
    await admin.from('offers').delete().eq('id', data.id)
    return { ok: true }
  })

// ----------------------------------------------------------------------------
// Services
// ----------------------------------------------------------------------------

export const upsertServiceFn = createServerFn({ method: 'POST' })
  .inputValidator((data: Partial<Service> & { id?: string }) => data)
  .handler(async ({ data }) => {
    await requireAdmin()
    const admin = await getAdminClient()
    if (data.id) {
      const { id, ...rest } = data
      await admin.from('services').update(rest).eq('id', id)
      return { id }
    }
    const { id, ...rest } = data
    const { data: row } = await admin.from('services').insert(rest).select('id').single()
    return { id: row?.id }
  })

export const deleteServiceFn = createServerFn({ method: 'POST' })
  .inputValidator((data: { id: string }) => data)
  .handler(async ({ data }) => {
    await requireAdmin()
    const admin = await getAdminClient()
    await admin.from('services').delete().eq('id', data.id)
    return { ok: true }
  })

// ----------------------------------------------------------------------------
// Payment Methods
// ----------------------------------------------------------------------------

export const upsertPaymentMethodFn = createServerFn({ method: 'POST' })
  .inputValidator((data: Partial<PaymentMethod> & { id?: string }) => data)
  .handler(async ({ data }) => {
    await requireAdmin()
    const admin = await getAdminClient()
    if (data.id) {
      const { id, ...rest } = data
      await admin.from('payment_methods').update(rest).eq('id', id)
      return { id }
    }
    const { id, ...rest } = data
    const { data: row } = await admin.from('payment_methods').insert(rest).select('id').single()
    return { id: row?.id }
  })

export const deletePaymentMethodFn = createServerFn({ method: 'POST' })
  .inputValidator((data: { id: string }) => data)
  .handler(async ({ data }) => {
    await requireAdmin()
    const admin = await getAdminClient()
    await admin.from('payment_methods').delete().eq('id', data.id)
    return { ok: true }
  })

// ----------------------------------------------------------------------------
// Orders
// ----------------------------------------------------------------------------

export const updateOrderStatusFn = createServerFn({ method: 'POST' })
  .inputValidator((data: { id: string; status: OrderStatus }) => data)
  .handler(async ({ data }) => {
    await requireAdmin()
    const admin = await getAdminClient()
    await admin.from('orders').update({ status: data.status }).eq('id', data.id)
    return { ok: true }
  })

export const deleteOrderFn = createServerFn({ method: 'POST' })
  .inputValidator((data: { id: string }) => data)
  .handler(async ({ data }) => {
    await requireAdmin()
    const admin = await getAdminClient()
    await admin.from('orders').delete().eq('id', data.id)
    return { ok: true }
  })

// ----------------------------------------------------------------------------
// Customers
// ----------------------------------------------------------------------------

export const deleteCustomerFn = createServerFn({ method: 'POST' })
  .inputValidator((data: { id: string }) => data)
  .handler(async ({ data }) => {
    await requireAdmin()
    const admin = await getAdminClient()
    await admin.from('customers').delete().eq('id', data.id)
    return { ok: true }
  })

// ----------------------------------------------------------------------------
// Pages
// ----------------------------------------------------------------------------

export const upsertPageFn = createServerFn({ method: 'POST' })
  .inputValidator((data: { id?: string; slug: string; title: string; content?: string | null; meta_title?: string | null; meta_description?: string | null; is_active?: boolean }) => data)
  .handler(async ({ data }) => {
    await requireAdmin()
    const admin = await getAdminClient()
    const { id, ...rest } = data
    if (id) {
      await admin.from('pages').update(rest).eq('id', id)
      return { id }
    }
    const { data: row } = await admin.from('pages').insert(rest).select('id').single()
    return { id: row?.id }
  })

// ----------------------------------------------------------------------------
// Backup / Restore
// ----------------------------------------------------------------------------

export const backupDataFn = createServerFn({ method: 'POST' }).handler(async () => {
  await requireAdmin()
  const admin = await getAdminClient()
  const tables = ['products', 'categories', 'brands', 'product_images', 'banners', 'offers', 'offer_products', 'services', 'payment_methods', 'customers', 'orders', 'order_items', 'settings', 'pages']
  const result: Record<string, unknown> = { exported_at: new Date().toISOString() }
  for (const t of tables) {
    const { data } = await admin.from(t).select('*')
    result[t] = data ?? []
  }
  return result
})

export const restoreDataFn = createServerFn({ method: 'POST' })
  .inputValidator((data: { payload: Record<string, any>; mode: 'merge' | 'replace' }) => data)
  .handler(async ({ data }) => {
    await requireAdmin()
    const admin = await getAdminClient()
    const { payload, mode } = data
    if (mode === 'replace') {
      // Clear in reverse-dependency order
      const clear = ['order_items', 'orders', 'offer_products', 'offers', 'product_images', 'products', 'categories', 'brands', 'banners', 'services', 'payment_methods', 'customers', 'pages']
      for (const t of clear) {
        await admin.from(t).delete().neq('id', '00000000-0000-0000-0000-000000000000')
      }
    }
    for (const [table, rows] of Object.entries(payload)) {
      if (!Array.isArray(rows) || rows.length === 0) continue
      if (table === 'exported_at') continue
      try {
        await admin.from(table).insert(rows as any[])
      } catch (e) {
        // Continue — some tables have FK constraints that may fail
        console.warn('restore failed for', table, e)
      }
    }
    return { ok: true }
  })

// ----------------------------------------------------------------------------
// Admin user creation (sign up new admin)
// ----------------------------------------------------------------------------

export const createAdminUserFn = createServerFn({ method: 'POST' })
  .inputValidator((data: { email: string; full_name?: string; role?: 'admin' | 'manager' | 'staff' }) => data)
  .handler(async ({ data }) => {
    // Only an existing admin can invite new admins.
    await requireAdmin()
    const admin = await getAdminClient()
    const email = data.email?.trim().toLowerCase() ?? ''
    if (!email.includes('@')) throw new Error('البريد الإلكتروني غير صحيح')
    const { data: existing } = await admin.from('admin_users').select('id').eq('email', email).single()
    if (existing) throw new Error('هذا البريد مضاف بالفعل')
    const { data: created, error } = await admin
      .from('admin_users')
      .insert({
        email,
        full_name: data.full_name ?? null,
        role: data.role ?? 'admin',
        is_active: true,
      })
      .select('id')
      .single()
    if (error) throw new Error(error.message)
    await markAdminBootstrapped(admin)
    return { id: created?.id, email }
  })

export const updateAdminUserFn = createServerFn({ method: 'POST' })
  .inputValidator((data: { id: string; role?: 'admin' | 'manager' | 'staff'; is_active?: boolean; full_name?: string | null }) => data)
  .handler(async ({ data }) => {
    await requireAdmin()
    const admin = await getAdminClient()
    await admin.from('admin_users').update({
      role: data.role,
      is_active: data.is_active,
      full_name: data.full_name,
    }).eq('id', data.id)
    return { ok: true }
  })

export const deleteAdminUserFn = createServerFn({ method: 'POST' })
  .inputValidator((data: { id: string }) => data)
  .handler(async ({ data }) => {
    await requireAdmin()
    const admin = await getAdminClient()
    await admin.from('admin_users').delete().eq('id', data.id)
    return { ok: true }
  })
// ----------------------------------------------------------------------------
// Admin users listing + first-run setup
// ----------------------------------------------------------------------------

export const listAdminUsersFn = createServerFn({ method: 'GET' }).handler(async () => {
  await requireAdmin()
  const admin = await getAdminClient()
  const { data } = await admin.from('admin_users').select('*').order('created_at')
  return (data ?? []) as AdminUser[]
})

export const adminStatusFn = createServerFn({ method: 'GET' }).handler(async () => {
  const admin = await getAdminClient()

  // 1) Public settings flag. It is readable before sign-in (unlike
  //    `admin_users`, whose policy only allows authenticated reads), so the
  //    login page can reliably tell whether the dashboard is already set up.
  try {
    const { data } = await admin
      .from('settings')
      .select('admin_bootstrapped')
      .eq('id', 'site')
      .limit(1)
    if (((data ?? [])[0] as any)?.admin_bootstrapped === true) return { hasAdmin: true }
  } catch {
    // Fall through to the authenticated probe below.
  }

  // 2) Databases created before the flag existed: an authenticated request can
  //    still read the admin list directly.
  try {
    const { getRequest } = await import('@tanstack/react-start/server')
    if (getRequest()?.headers?.get('authorization')) {
      const { data } = await admin.from('admin_users').select('id').limit(1)
      if ((data ?? []).length > 0) {
        await markAdminBootstrapped(admin)
        return { hasAdmin: true }
      }
    }
  } catch {
    // Ignore and report "not set up" only when nothing could be confirmed.
  }

  return { hasAdmin: false }
})

// ----------------------------------------------------------------------------
// Product images
// ----------------------------------------------------------------------------

export const setMainProductImageFn = createServerFn({ method: 'POST' })
  .inputValidator((data: { product_id: string; id: string }) => data)
  .handler(async ({ data }) => {
    await requireAdmin()
    const admin = await getAdminClient()
    await admin.from('product_images').update({ is_main: false }).eq('product_id', data.product_id)
    const { error } = await admin.from('product_images').update({ is_main: true }).eq('id', data.id)
    if (error) throw new Error(error.message)
    return { ok: true }
  })


// ----------------------------------------------------------------------------
// Import items from the Hi-Tech Pro program (CSV -> mapped in the browser)
// ----------------------------------------------------------------------------

/**
 * Upserts a small batch of mapped items by SKU (the browser sends <= 25 rows
 * per call to stay inside the Worker's subrequest limit).
 *  - new SKU      -> product created with the generated name/description.
 *  - existing SKU -> only price and stock are refreshed (and `is_available` is
 *    left alone). Texts, images, tags and discounts you edited are never
 *    overwritten, so this same function doubles as the price/stock sync.
 */
export const importProductsFn = createServerFn({ method: 'POST' })
  .inputValidator((data: { rows: ImportRow[]; update_existing: boolean }) => data)
  .handler(async ({ data }) => {
    await requireAdmin()
    const rows = data.rows
    if (!Array.isArray(rows) || rows.length === 0) throw new Error('لا توجد أصناف')
    if (rows.length > 25) throw new Error('الدفعة كبيرة (الحد 25 صنف)')
    const admin = await getAdminClient()

    for (const r of rows) {
      if (!r.sku || typeof r.sku !== 'string' || r.sku.length > 40) throw new Error('كود صنف غير صالح')
      if (!r.name || r.name.length > 200) throw new Error(`اسم غير صالح للصنف ${r.sku}`)
      if (!Number.isFinite(r.price) || r.price <= 0 || r.price > 10_000_000) throw new Error(`سعر غير صالح للصنف ${r.sku}`)
      if (!Number.isInteger(r.stock) || r.stock < 0 || r.stock > 1_000_000) throw new Error(`كمية غير صالحة للصنف ${r.sku}`)
    }

    // categories (created on demand from the known list)
    const slugs = [...new Set(rows.map((r) => r.category_slug))]
    const { data: cats } = await admin.from('categories').select('id, slug').in('slug', slugs)
    const catId = new Map<string, string>(((cats ?? []) as any[]).map((c) => [c.slug, c.id]))
    for (const slug of slugs) {
      if (catId.has(slug)) continue
      const def = IMPORT_CATEGORIES[slug]
      if (!def) continue
      const { data: made } = await admin
        .from('categories')
        .insert({ slug, name: def.name, description: def.description, sort_order: def.sort_order, is_visible: true })
        .select('id')
        .single()
      if (made?.id) catId.set(slug, made.id)
    }

    const { data: existingRows } = await admin
      .from('products')
      .select('id, sku, price, price_original')
      .in('sku', rows.map((r) => r.sku))
    const existing = new Map<string, any>(((existingRows ?? []) as any[]).map((p) => [p.sku, p]))

    let created = 0
    let updated = 0
    const fresh: Record<string, unknown>[] = []
    for (const r of rows) {
      const old = existing.get(r.sku)
      if (old) {
        if (!data.update_existing) continue
        const keepOriginal = Number(old.price_original) > r.price
        const { error } = await admin
          .from('products')
          .update({
            price: r.price,
            price_original: keepOriginal ? Number(old.price_original) : r.price,
            discount_percent: keepOriginal
              ? Math.round(((Number(old.price_original) - r.price) / Number(old.price_original)) * 10000) / 100
              : 0,
            stock: r.stock,
            updated_at: new Date().toISOString(),
          })
          .eq('id', old.id)
        if (error) throw new Error(error.message)
        updated++
      } else {
        fresh.push({
          slug: slugFromSku(r.sku),
          sku: r.sku,
          name: r.name,
          category_id: catId.get(r.category_slug) ?? null,
          short_description: r.short_description,
          description: r.description,
          specs: r.specs ?? {},
          tags: r.tags ?? [],
          price_original: r.price,
          price: r.price,
          discount_percent: 0,
          stock: r.stock,
          low_stock_threshold: 3,
          is_available: true,
          meta_title: r.name,
          meta_description: r.short_description,
        })
      }
    }
    if (fresh.length) {
      const { error } = await admin.from('products').insert(fresh)
      if (error) throw new Error(error.message)
      created = fresh.length
    }
    await admin.from('activity_logs').insert({
      action: 'products_imported',
      entity_type: 'product',
      details: { created, updated, source: 'hi-tech-pro-csv' },
    })
    return { created, updated }
  })
