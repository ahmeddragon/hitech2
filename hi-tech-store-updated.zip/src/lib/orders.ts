// Public order submission (no auth required)

import { createServerFn } from '@tanstack/react-start'

export const submitOrderFn = createServerFn({ method: 'POST' })
  .inputValidator(
    (data: {
      customer: { name: string; phone: string; address?: string; notes?: string }
      items: { product_id: string; product_name: string; product_sku: string | null; unit_price: number; quantity: number }[]
      payment_method: string
    }) => data,
  )
  .handler(async ({ data }) => {
    if (!data.customer.name?.trim()) throw new Error('اسم العميل مطلوب')
    if (!data.customer.phone?.trim()) throw new Error('رقم الهاتف مطلوب')
    if (!Array.isArray(data.items) || data.items.length === 0) throw new Error('السلة فارغة')
    if (data.items.length > 50) throw new Error('عدد الأصناف في الطلب كبير جدًا')
    const { createOrder } = await import('./data.server')
    return await createOrder(data)
  })