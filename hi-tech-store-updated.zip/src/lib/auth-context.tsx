// Admin auth context (client-side)
import { createContext, useContext, useEffect, useState, type ReactNode } from 'react'
import {
  getNubaseAccessToken,
  NUBASE_AUTH_STORAGE_KEY,
  setNubaseAccessToken,
} from '../integrations/nubase/token-storage'

export type AdminSession = {
  email: string
  id: string
  record?: { id: string; email: string; role: string; full_name?: string | null; is_active: boolean }
} | null

type AuthContextValue = {
  session: AdminSession
  accessToken: string | null
  setSession: (s: AdminSession, token: string | null) => void
  signOut: () => void
  loading: boolean
}

const AuthContext = createContext<AuthContextValue | null>(null)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSessionState] = useState<AdminSession>(null)
  const [accessToken, setAccessTokenState] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Restore from localStorage, but never trust an expired token: it would
    // otherwise reach the server and be rejected as an anonymous request.
    const token = getNubaseAccessToken()
    if (token) {
      try {
        const parts = token.split('.')
        if (parts.length === 3) {
          const payload = JSON.parse(atob(parts[1].replace(/-/g, '+').replace(/_/g, '/')))
          const exp = typeof payload?.exp === 'number' ? payload.exp : 0
          if (exp && exp * 1000 > Date.now()) {
            setAccessTokenState(token)
            if (payload?.email) {
              setSessionState({ email: payload.email, id: payload.sub })
            }
          } else {
            setNubaseAccessToken(null)
          }
        } else {
          setNubaseAccessToken(null)
        }
      } catch {
        setNubaseAccessToken(null)
      }
    }
    setLoading(false)
  }, [])

  const setSession = (s: AdminSession, token: string | null) => {
    setSessionState(s)
    setAccessTokenState(token)
    setNubaseAccessToken(token)
  }
  const signOut = () => {
    setSessionState(null)
    setAccessTokenState(null)
    setNubaseAccessToken(null)
    if (typeof window !== 'undefined') {
      window.localStorage.removeItem(NUBASE_AUTH_STORAGE_KEY)
    }
  }
  return (
    <AuthContext.Provider value={{ session, accessToken, setSession, signOut, loading }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider')
  return ctx
}

export function authHeader(token: string | null) {
  return token ? { authorization: `Bearer ${token}` } : {}
}