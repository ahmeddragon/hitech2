// Client-side image import helper.
// Compresses photos selected from the admin's device down to a web-friendly
// size, then returns a data URL that can be stored directly as the image `url`.
// Fully client-side: no storage backend or extra hosting account is required.

export const MAX_SOURCE_BYTES = 12 * 1024 * 1024 // 12 MB source limit
export const MAX_RESULT_BYTES = 700 * 1024 // keep stored images lightweight

export const MAX_DIMENSION = 1400
export const JPEG_QUALITY = 0.82

function readFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = () => resolve(String(reader.result ?? ''))
    reader.onerror = () => reject(new Error('تعذّر قراءة الملف'))
    reader.readAsDataURL(file)
  })
}

function approxBytes(dataUrl: string): number {
  const comma = dataUrl.indexOf(',')
  return Math.round((dataUrl.length - comma - 1) * 0.75)
}

function draw(canvas: HTMLCanvasElement, bitmap: ImageBitmap, mime: string, quality: number) {
  const ctx = canvas.getContext('2d')
  if (!ctx) throw new Error('no-canvas')
  ctx.fillStyle = '#ffffff'
  ctx.fillRect(0, 0, canvas.width, canvas.height)
  ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height)
  return canvas.toDataURL(mime, quality)
}

/**
 * Reads an image file from the device and returns a compressed data URL.
 * Falls back gracefully when the browser cannot decode the file.
 */
export async function importImageFile(file: File): Promise<string> {
  if (!file.type.startsWith('image/')) {
    throw new Error('الملف المختار ليس صورة')
  }
  if (file.size > MAX_SOURCE_BYTES) {
    throw new Error('حجم الصورة كبير جدًا (الحد 12 ميجابايت)')
  }

  const rawDataUrl = await readFileAsDataUrl(file)

  const canCompress =
    typeof document !== 'undefined' &&
    file.type !== 'image/svg+xml' &&
    file.type !== 'image/gif'

  if (!canCompress) return rawDataUrl

  try {
    const bitmap = await createImageBitmap(file)
    const scale = Math.min(1, MAX_DIMENSION / Math.max(bitmap.width, bitmap.height))
    const width = Math.max(1, Math.round(bitmap.width * scale))
    const height = Math.max(1, Math.round(bitmap.height * scale))

    let candidate = ''
    for (const [mime, quality] of [
      ['image/webp', JPEG_QUALITY],
      ['image/jpeg', JPEG_QUALITY],
      ['image/jpeg', 0.7],
      ['image/jpeg', 0.6],
    ] as [string, number][]) {
      const canvas = document.createElement('canvas')
      canvas.width = width
      canvas.height = height
      const out = draw(canvas, bitmap, mime, quality)
      if (!candidate) candidate = out
      if (approxBytes(out) <= MAX_RESULT_BYTES) {
        candidate = out
        break
      }
      candidate = out
    }
    bitmap.close?.()

    return candidate && approxBytes(candidate) < approxBytes(rawDataUrl) ? candidate : rawDataUrl
  } catch {
    return rawDataUrl
  }
}
