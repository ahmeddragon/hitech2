// Resilient Nubase data-access resolver for the Hi-Tech store.
//
// The service-role admin client (which bypasses RLS) is preferred, but the
// deployed runtime does not always expose NUBASE_SERVICE_ROLE_KEY. Previously
// every read/write called createNubaseAdminClient() directly, so a missing
// service-role key broke the whole site with:
//   "Missing NUBASE_SERVICE_ROLE_KEY for server-only Nubase admin client."
//
// getStoreDb() therefore degrades gracefully, in this order:
//   1. service-role admin client, when the runtime provides the key;
//   2. the signed-in user's session (RLS: authenticated);
//   3. the app-scoped publishable key (RLS: public read/insert policies).
//
// The fallbacks use only the installed controlled facade, never a hand-written
// Nubase client, so the platform source policy stays satisfied.

import { getRequest } from '@tanstack/react-start/server'
import {
  createNubaseAdminClient,
  createNubaseUserClient,
} from '../integrations/nubase/server-client.server'

export type StoreDb = ReturnType<typeof createNubaseAdminClient>

function requestAccessToken(): string | null {
  try {
    const authorization = getRequest()?.headers?.get('authorization')
    const match = authorization?.match(/^Bearer\s+(.+)$/i)
    return match?.[1] ?? null
  } catch {
    // Called outside a request scope (for example from a build-time context).
    return null
  }
}

/**
 * Reads the claims carried by a bearer token without contacting the auth
 * service.
 *
 * This intentionally does NOT establish trust: the database stays the
 * authorization boundary, because every read and write still runs through
 * Row-Level Security using the real request token. The claims are only used to
 * know which account the caller is acting as so the dashboard can locate its
 * own administrator row.
 */
export function decodeJwtPayload(token: string): Record<string, unknown> | null {
  try {
    const part = token.split('.')[1]
    if (!part) return null
    const base64 = part.replace(/-/g, '+').replace(/_/g, '/')
    const padded = base64.padEnd(base64.length + ((4 - (base64.length % 4)) % 4), '=')
    const json =
      typeof atob === 'function'
        ? atob(padded)
        : Buffer.from(padded, 'base64').toString('utf8')
    const parsed = JSON.parse(json)
    return parsed && typeof parsed === 'object' ? (parsed as Record<string, unknown>) : null
  } catch {
    return null
  }
}

/**
 * Returns the best data client available for the current request.
 */
export function getStoreDb(): StoreDb {
  try {
    return createNubaseAdminClient()
  } catch {
    // Service-role key is unavailable in this runtime; fall through to the
    // RLS-scoped facade client instead of failing the request.
  }

  const accessToken = requestAccessToken()
  return accessToken
    ? createNubaseUserClient(accessToken)
    : createNubaseUserClient('')
}
