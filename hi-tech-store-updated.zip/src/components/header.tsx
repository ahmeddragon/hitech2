// Hi-Tech Store Header
import { Link, useNavigate } from '@tanstack/react-router'
import { Menu, Phone, Search, ShoppingCart, X } from 'lucide-react'
import { useEffect, useMemo, useState } from 'react'
import { useCart } from './cart-context'
import type { Category, Settings } from '../lib/types'
import { cn } from '../lib/utils'

type Props = {
  settings: Settings
  categories: Category[]
}

export function Header({ settings, categories }: Props) {
  const [drawerOpen, setDrawerOpen] = useState(false)
  const [searchOpen, setSearchOpen] = useState(false)
  const [searchTerm, setSearchTerm] = useState('')
  const { itemCount } = useCart()
  const navigate = useNavigate()

  // Lock body scroll when drawer open
  useEffect(() => {
    if (drawerOpen || searchOpen) {
      document.body.style.overflow = 'hidden'
    } else {
      document.body.style.overflow = ''
    }
    return () => {
      document.body.style.overflow = ''
    }
  }, [drawerOpen, searchOpen])

  const onSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!searchTerm.trim()) return
    setSearchOpen(false)
    navigate({ to: '/search', search: { q: searchTerm.trim() } })
  }

  return (
    <>
      <header className="sticky top-0 z-40 bg-white border-b border-border shadow-sm">
        {/* Top bar with phone, whatsapp */}
        <div className="bg-[var(--ht-blue)] text-white text-xs">
          <div className="mx-auto max-w-7xl px-3 py-1.5 flex items-center justify-between gap-3">
            <div className="flex items-center gap-2 truncate">
              <Phone className="size-3.5 shrink-0" />
              <a href={`tel:${settings.phone}`} className="hover:underline tabular-nums truncate">
                {settings.phone}
              </a>
              <span className="opacity-60 hidden sm:inline">•</span>
              <span className="hidden sm:inline truncate">{settings.address}</span>
            </div>
            <div className="hidden md:flex items-center gap-3 shrink-0">
              {settings.working_hours && <span className="opacity-90 truncate">{settings.working_hours}</span>}
            </div>
          </div>
        </div>

        {/* Main bar */}
        <div className="mx-auto max-w-7xl px-3 py-2.5 flex items-center gap-2 md:gap-4">
          <button
            type="button"
            aria-label="فتح القائمة"
            className="lg:hidden p-2 -mr-2 rounded-md hover:bg-muted"
            onClick={() => setDrawerOpen(true)}
          >
            <Menu className="size-6" />
          </button>

          <Link to="/" className="flex items-center gap-2 shrink-0">
            <Logo />
            <span className="font-bold text-lg hidden sm:inline gradient-ht">Hi-Tech</span>
          </Link>

          <form
            onSubmit={onSearchSubmit}
            className="flex-1 hidden md:flex max-w-2xl mx-auto"
          >
            <div className="relative w-full">
              <input
                type="search"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="ابحث عن لاب توب، كاميرا، هارد..."
                className="w-full rounded-lg border border-border bg-muted/50 px-4 py-2.5 pr-10 text-sm focus:outline-none focus:ring-2 focus:ring-[var(--ht-blue)] focus:border-transparent"
              />
              <button
                type="submit"
                aria-label="بحث"
                className="absolute left-2 top-1/2 -translate-y-1/2 p-1.5 rounded-md text-[var(--ht-blue)] hover:bg-white"
              >
                <Search className="size-4" />
              </button>
            </div>
          </form>

          <button
            type="button"
            aria-label="بحث"
            className="md:hidden p-2 rounded-md hover:bg-muted"
            onClick={() => setSearchOpen(true)}
          >
            <Search className="size-5" />
          </button>

          <a
            href={`tel:${settings.phone}`}
            aria-label="اتصال"
            className="hidden sm:inline-flex p-2 rounded-md hover:bg-muted text-[var(--ht-blue)]"
          >
            <Phone className="size-5" />
          </a>

          <a
            href={`https://wa.me/${settings.whatsapp.replace(/^0/, '20')}`}
            target="_blank"
            rel="noopener noreferrer"
            className="hidden sm:inline-flex p-2 rounded-md hover:bg-green-50 text-green-600"
            aria-label="واتساب"
          >
            <WhatsappIcon />
          </a>

          <Link
            to="/cart"
            aria-label="السلة"
            className="relative p-2 rounded-md hover:bg-muted"
          >
            <ShoppingCart className="size-5" />
            {itemCount > 0 && (
              <span className="absolute -top-1 -left-1 min-w-[20px] h-5 px-1 rounded-full bg-[var(--ht-red)] text-white text-[11px] font-bold flex items-center justify-center">
                {itemCount}
              </span>
            )}
          </Link>
        </div>

        {/* Categories nav (desktop) */}
        <nav className="hidden lg:block bg-muted/40 border-t border-border">
          <div className="mx-auto max-w-7xl px-3 py-2 flex items-center gap-2 overflow-x-auto scrollbar-hide">
            <Link
              to="/"
              className="text-sm font-medium px-3 py-1.5 rounded-md hover:bg-white text-foreground/80 hover:text-[var(--ht-blue)]"
            >
              الرئيسية
            </Link>
            <Link
              to="/products"
              className="text-sm font-medium px-3 py-1.5 rounded-md hover:bg-white text-foreground/80 hover:text-[var(--ht-blue)]"
            >
              كل المنتجات
            </Link>
            {categories.slice(0, 10).map((c) => (
              <Link
                key={c.id}
                to="/category/$slug"
                params={{ slug: c.slug }}
                className="text-sm font-medium px-3 py-1.5 rounded-md hover:bg-white text-foreground/80 hover:text-[var(--ht-blue)] whitespace-nowrap"
              >
                {c.name}
              </Link>
            ))}
            <Link
              to="/offers"
              className="text-sm font-bold px-3 py-1.5 rounded-md hover:bg-white text-[var(--ht-red)] whitespace-nowrap"
            >
              🔥 العروض
            </Link>
            <Link
              to="/services"
              className="text-sm font-medium px-3 py-1.5 rounded-md hover:bg-white text-foreground/80 hover:text-[var(--ht-blue)] whitespace-nowrap"
            >
              الخدمات
            </Link>
          </div>
        </nav>
      </header>

      {/* Mobile drawer */}
      {drawerOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div
            className="absolute inset-0 bg-black/50"
            onClick={() => setDrawerOpen(false)}
          />
          <div className="absolute top-0 right-0 h-full w-[85%] max-w-sm bg-white shadow-2xl flex flex-col animate-fade-in">
            <div className="flex items-center justify-between p-4 border-b">
              <span className="font-bold gradient-ht text-lg">Hi-Tech</span>
              <button
                onClick={() => setDrawerOpen(false)}
                aria-label="إغلاق"
                className="p-2 rounded-md hover:bg-muted"
              >
                <X className="size-5" />
              </button>
            </div>
            <nav className="flex-1 overflow-y-auto p-3 space-y-1">
              <DrawerLink to="/" label="الرئيسية" onClick={() => setDrawerOpen(false)} />
              <DrawerLink to="/products" label="كل المنتجات" onClick={() => setDrawerOpen(false)} />
              <DrawerLink to="/offers" label="العروض والخصومات" highlight onClick={() => setDrawerOpen(false)} />
              <DrawerLink to="/services" label="الخدمات" onClick={() => setDrawerOpen(false)} />
              <DrawerLink to="/about" label="من نحن" onClick={() => setDrawerOpen(false)} />
              <DrawerLink to="/contact" label="اتصل بنا" onClick={() => setDrawerOpen(false)} />
              <div className="h-px bg-border my-2" />
              <p className="px-3 text-xs font-semibold text-muted-foreground uppercase">التصنيفات</p>
              {categories.map((c) => (
                <DrawerLink
                  key={c.id}
                  to="/category/$slug"
                  params={{ slug: c.slug }}
                  label={c.name}
                  onClick={() => setDrawerOpen(false)}
                />
              ))}
            </nav>
            <div className="p-4 border-t space-y-2">
              <a
                href={`tel:${settings.phone}`}
                className="flex items-center justify-center gap-2 w-full py-2.5 rounded-md bg-[var(--ht-blue)] text-white font-medium"
              >
                <Phone className="size-4" /> اتصال الآن
              </a>
              <a
                href={`https://wa.me/${settings.whatsapp.replace(/^0/, '20')}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 w-full py-2.5 rounded-md bg-green-500 text-white font-medium"
              >
                <WhatsappIcon /> واتساب
              </a>
            </div>
          </div>
        </div>
      )}

      {/* Mobile search modal */}
      {searchOpen && (
        <div className="fixed inset-0 z-50 md:hidden">
          <div
            className="absolute inset-0 bg-black/50"
            onClick={() => setSearchOpen(false)}
          />
          <div className="absolute top-0 inset-x-0 bg-white p-3 shadow-2xl animate-fade-in">
            <form onSubmit={onSearchSubmit} className="flex items-center gap-2">
              <div className="relative flex-1">
                <input
                  type="search"
                  autoFocus
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="ابحث عن منتج..."
                  className="w-full rounded-lg border border-border bg-muted/50 px-4 py-2.5 pr-10 text-sm focus:outline-none focus:ring-2 focus:ring-[var(--ht-blue)]"
                />
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
              </div>
              <button
                type="button"
                onClick={() => setSearchOpen(false)}
                aria-label="إغلاق"
                className="p-2 rounded-md hover:bg-muted"
              >
                <X className="size-5" />
              </button>
            </form>
          </div>
        </div>
      )}
    </>
  )
}

function DrawerLink({
  to,
  label,
  onClick,
  highlight,
  params,
}: {
  to: any
  label: string
  onClick: () => void
  highlight?: boolean
  params?: Record<string, string>
}) {
  return (
    <Link
      to={to}
      params={params as any}
      onClick={onClick}
      className={cn(
        'block px-3 py-2 rounded-md text-sm font-medium',
        highlight
          ? 'text-[var(--ht-red)] hover:bg-red-50'
          : 'text-foreground hover:bg-muted hover:text-[var(--ht-blue)]',
      )}
    >
      {label}
    </Link>
  )
}

export function Logo({ size = 36 }: { size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 64 64"
      xmlns="http://www.w3.org/2000/svg"
      className="shrink-0"
    >
      <defs>
        <linearGradient id="ht-grad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#DC2626" />
          <stop offset="100%" stopColor="#1E40AF" />
        </linearGradient>
      </defs>
      <rect width="64" height="64" rx="14" fill="url(#ht-grad)" />
      <text
        x="50%"
        y="56%"
        textAnchor="middle"
        dominantBaseline="middle"
        fontFamily="Cairo, sans-serif"
        fontWeight="800"
        fontSize="24"
        fill="white"
      >
        Hi
      </text>
      <circle cx="50" cy="14" r="4" fill="#fff" opacity="0.9" />
    </svg>
  )
}

export function WhatsappIcon({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="currentColor"
      className={className ?? 'size-5'}
      aria-hidden="true"
    >
      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413Z" />
    </svg>
  )
}