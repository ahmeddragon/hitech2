// Storefront layout — wraps every public page
import type { ReactNode } from 'react'
import { useEffect } from 'react'
import type { Category, Settings } from '../lib/types'
import { Header } from './header'
import { Footer, FloatingWhatsApp } from './footer'
import { CartProvider } from './cart-context'
import { AuthProvider } from '../lib/auth-context'
import { Toaster } from './ui/sonner'

type Props = {
  settings: Settings
  categories: Category[]
  children: ReactNode
}

export function StoreLayout({ settings, categories, children }: Props) {
  return (
    <AuthProvider>
      <CartProvider>
        <div className="flex min-h-screen flex-col bg-background">
          <Header settings={settings} categories={categories} />
          <main className="flex-1">{children}</main>
          <Footer settings={settings} categories={categories} />
          <FloatingWhatsApp settings={settings} />
          <Toaster richColors position="top-center" dir="rtl" />
        </div>
      </CartProvider>
    </AuthProvider>
  )
}

export function usePageSEO(meta: {
  title?: string
  description?: string
  image?: string
  url?: string
}) {
  useEffect(() => {
    const title = meta.title
    if (title) document.title = title
    if (meta.description) {
      let el = document.querySelector('meta[name="description"]') as HTMLMetaElement | null
      if (!el) {
        el = document.createElement('meta')
        el.setAttribute('name', 'description')
        document.head.appendChild(el)
      }
      el.setAttribute('content', meta.description)
    }
  }, [meta.title, meta.description])
}