// Product Card, Category Card, and other catalog blocks
import { Link } from '@tanstack/react-router'
import { Eye, ShoppingCart } from 'lucide-react'
import type { Category, Product } from '../lib/types'
import {
  STOCK_COLORS,
  STOCK_LABELS,
  getStockStatus,
} from '../lib/types'
import { useCart } from './cart-context'
import { cn } from '../lib/utils'
import { WhatsappIcon } from './header'

function formatPrice(value: number) {
  return value.toLocaleString('ar-EG', { maximumFractionDigits: 2 })
}

export function ProductCard({
  product,
  compact = false,
}: {
  product: Product
  compact?: boolean
}) {
  const { add } = useCart()
  const stock = getStockStatus(product)
  const disabled = stock === 'out_of_stock' || stock === 'unavailable'
  const main = product.main_image?.url

  return (
    <article className="group relative flex flex-col rounded-xl border border-border bg-card overflow-hidden hover:shadow-lg transition-all hover:-translate-y-0.5">
      <Link
        to="/product/$slug"
        params={{ slug: product.slug }}
        className="block relative aspect-square overflow-hidden bg-muted"
      >
        {main ? (
          <img
            src={main}
            alt={product.name}
            loading="lazy"
            className="size-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
        ) : (
          <div className="size-full flex items-center justify-center text-muted-foreground text-sm">
            لا توجد صورة
          </div>
        )}
        <div className="absolute top-2 right-2 flex flex-col gap-1 items-start">
          {product.discount_percent > 0 && (
            <span className="bg-[var(--ht-red)] text-white text-xs font-bold px-2 py-1 rounded-md">
              خصم {Math.round(product.discount_percent)}%
            </span>
          )}
          {product.is_new && (
            <span className="bg-[var(--ht-blue)] text-white text-xs font-bold px-2 py-1 rounded-md">
              جديد
            </span>
          )}
        </div>
        {product.views_count > 0 && (
          <div className="absolute bottom-2 left-2 flex items-center gap-1 text-[11px] text-white bg-black/50 px-1.5 py-0.5 rounded">
            <Eye className="size-3" /> {product.views_count}
          </div>
        )}
      </Link>

      <div className="flex flex-col flex-1 p-3 gap-2">
        {product.brand && (
          <p className="text-[11px] uppercase tracking-wide text-muted-foreground truncate">
            {product.brand.name}
          </p>
        )}
        <Link
          to="/product/$slug"
          params={{ slug: product.slug }}
          className="font-semibold text-sm leading-5 line-clamp-2 hover:text-[var(--ht-blue)]"
        >
          {product.name}
        </Link>

        <div className="flex items-center gap-1">
          <span
            className={cn(
              'text-[10px] px-1.5 py-0.5 rounded border',
              STOCK_COLORS[stock],
            )}
          >
            {STOCK_LABELS[stock]}
          </span>
        </div>

        <div className="mt-auto space-y-2">
          <div className="flex items-baseline gap-2 flex-wrap">
            <span className="text-base font-bold text-[var(--ht-blue)] tabular-nums">
              {formatPrice(product.price)} ج.م
            </span>
            {product.discount_percent > 0 && product.price_original > product.price && (
              <span className="text-xs text-muted-foreground line-through tabular-nums">
                {formatPrice(product.price_original)} ج.م
              </span>
            )}
          </div>

          {!compact && (
            <div className="grid grid-cols-2 gap-1.5">
              <button
                type="button"
                disabled={disabled}
                onClick={(e) => {
                  e.preventDefault()
                  if (disabled) return
                  add({
                    product_id: product.id,
                    slug: product.slug,
                    name: product.name,
                    image: main,
                    unit_price: product.price,
                    original_price: product.price_original > product.price ? product.price_original : undefined,
                    quantity: 1,
                    max_stock: product.stock,
                  })
                }}
                className="flex items-center justify-center gap-1.5 px-2 py-2 rounded-md bg-[var(--ht-blue)] text-white text-xs font-semibold hover:bg-[var(--ht-blue-dark)] disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <ShoppingCart className="size-3.5" />
                أضف للسلة
              </button>
              <a
                href={`https://wa.me/?text=${encodeURIComponent(
                  `مرحبًا، أرغب في شراء: ${product.name} بسعر ${formatPrice(product.price)} ج.م`,
                )}`}
                target="_blank"
                rel="noopener noreferrer"
                onClick={(e) => e.stopPropagation()}
                className="flex items-center justify-center gap-1.5 px-2 py-2 rounded-md bg-[var(--ht-red)] text-white text-xs font-semibold hover:bg-[var(--ht-red-dark)]"
              >
                <WhatsappIcon className="size-3.5" />
                واتساب
              </a>
            </div>
          )}
        </div>
      </div>
    </article>
  )
}

export function CategoryCard({ category }: { category: Category }) {
  return (
    <Link
      to="/category/$slug"
      params={{ slug: category.slug }}
      className="group flex flex-col items-center justify-center p-4 rounded-xl border border-border bg-card hover:border-[var(--ht-blue)] hover:shadow-md transition-all"
    >
      <div className="size-16 rounded-full bg-[var(--ht-blue-light)] flex items-center justify-center mb-2 group-hover:bg-[var(--ht-blue)] group-hover:text-white transition-colors">
        {category.image_url ? (
          <img src={category.image_url} alt={category.name} className="size-full rounded-full object-cover" />
        ) : (
          <span className="text-2xl font-bold text-[var(--ht-blue)] group-hover:text-white">
            {category.name.charAt(0)}
          </span>
        )}
      </div>
      <p className="text-sm font-medium text-center line-clamp-1">{category.name}</p>
    </Link>
  )
}

export function PriceDisplay({
  price,
  original,
  discount,
  large = false,
}: {
  price: number
  original?: number
  discount?: number
  large?: boolean
}) {
  const hasDiscount = (original ?? 0) > price
  return (
    <div className="flex items-baseline gap-2 flex-wrap">
      <span
        className={cn(
          'font-bold tabular-nums text-[var(--ht-blue)]',
          large ? 'text-2xl' : 'text-base',
        )}
      >
        {formatPrice(price)} ج.م
      </span>
      {hasDiscount && (
        <>
          <span className="text-sm text-muted-foreground line-through tabular-nums">
            {formatPrice(original!)} ج.م
          </span>
          <span className="text-xs font-bold text-[var(--ht-red)]">
            خصم {discount ?? Math.round(((original! - price) / original!) * 100)}%
          </span>
        </>
      )}
    </div>
  )
}