// Admin layout with sidebar and topbar
import { Link, Outlet, useLocation, useNavigate } from '@tanstack/react-router'
import { useEffect, useState } from 'react'
import {
  BarChart3,
  Boxes,
  ChevronLeft,
  CreditCard,
  Database,
  Download,
  FileText,
  Image as ImageIcon,
  Layers,
  LayoutDashboard,
  LogOut,
  Mail,
  Menu,
  Package,
  Settings,
  ShoppingCart,
  Tag,
  Upload,
  Users,
  Wrench,
  X,
} from 'lucide-react'
import { Logo } from './header'
import { useAuth } from '../lib/auth-context'
import { Toaster } from './ui/sonner'
import { cn } from '../lib/utils'

type NavItem = {
  to: string
  label: string
  icon: any
  badge?: string
}

const NAV: NavItem[] = [
  { to: '/admin', label: 'لوحة التحكم', icon: LayoutDashboard },
  { to: '/admin/products', label: 'المنتجات', icon: Package },
  { to: '/admin/categories', label: 'التصنيفات', icon: Layers },
  { to: '/admin/inventory', label: 'المخزون', icon: Boxes },
  { to: '/admin/orders', label: 'الطلبات', icon: ShoppingCart },
  { to: '/admin/customers', label: 'العملاء', icon: Users },
  { to: '/admin/banners', label: 'البانرات', icon: ImageIcon },
  { to: '/admin/offers', label: 'العروض', icon: Tag },
  { to: '/admin/services', label: 'الخدمات', icon: Wrench },
  { to: '/admin/payment-methods', label: 'طرق الدفع', icon: CreditCard },
  { to: '/admin/pages', label: 'الصفحات', icon: FileText },
  { to: '/admin/settings', label: 'الإعدادات', icon: Settings },
  { to: '/admin/users', label: 'المستخدمون', icon: Mail },
  { to: '/admin/backup', label: 'النسخ الاحتياطي', icon: Database },
]

export function AdminLayout() {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const { session, accessToken, signOut, loading } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()
  const isLoginPage = location.pathname === '/admin/login'

  useEffect(() => {
    // Close sidebar on route change (mobile)
    setSidebarOpen(false)
  }, [location.pathname])

  // Guard: redirect to login if there is no active session
  useEffect(() => {
    if (isLoginPage || loading) return
    if (!accessToken) {
      navigate({ to: '/admin/login' })
    }
  }, [isLoginPage, loading, accessToken, navigate])

  const onSignOut = () => {
    signOut()
    navigate({ to: '/admin/login' })
  }

  // Hide layout on login page
  if (isLoginPage) {
    return <Outlet />
  }

  if (loading || !accessToken) {
    return (
      <div className="min-h-screen bg-muted/30 flex items-center justify-center text-muted-foreground">
        جاري التحقق من الصلاحية...
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-muted/30" dir="rtl">
      {/* Sidebar */}
      <aside
        className={cn(
          'fixed top-0 right-0 z-40 h-full w-72 bg-[var(--ht-blue-dark)] text-white transition-transform lg:translate-x-0 shadow-2xl',
          sidebarOpen ? 'translate-x-0' : 'translate-x-full lg:translate-x-0',
        )}
      >
        <div className="h-16 flex items-center justify-between px-4 border-b border-white/10">
          <Link to="/admin" className="flex items-center gap-2">
            <Logo size={32} />
            <span className="font-bold text-lg">Hi-Tech Admin</span>
          </Link>
          <button
            type="button"
            onClick={() => setSidebarOpen(false)}
            aria-label="إغلاق"
            className="lg:hidden p-2 rounded-md hover:bg-white/10"
          >
            <X className="size-5" />
          </button>
        </div>

        <nav className="p-2 overflow-y-auto h-[calc(100%-8rem)]">
          <ul className="space-y-1">
            {NAV.map((item) => {
              const isActive = item.to === '/admin' ? location.pathname === '/admin' : location.pathname.startsWith(item.to)
              return (
                <li key={item.to}>
                  <Link
                    to={item.to as any}
                    className={cn(
                      'flex items-center gap-3 px-3 py-2 rounded-md text-sm transition-colors',
                      isActive
                        ? 'bg-white/15 text-white font-semibold'
                        : 'text-white/80 hover:bg-white/10 hover:text-white',
                    )}
                  >
                    <item.icon className="size-4 shrink-0" />
                    <span className="flex-1">{item.label}</span>
                    {item.badge && (
                      <span className="text-xs px-1.5 py-0.5 rounded bg-[var(--ht-red)] text-white">
                        {item.badge}
                      </span>
                    )}
                  </Link>
                </li>
              )
            })}
          </ul>
        </nav>

        <div className="absolute bottom-0 inset-x-0 p-3 border-t border-white/10 bg-[var(--ht-blue-dark)]">
          <div className="text-xs text-white/70 mb-2 truncate">
            {session?.email ?? 'admin@hi-tech.com'}
          </div>
          <button
            type="button"
            onClick={onSignOut}
            className="w-full flex items-center justify-center gap-2 py-2 rounded-md bg-white/10 hover:bg-white/20 text-sm"
          >
            <LogOut className="size-4" /> تسجيل الخروج
          </button>
        </div>
      </aside>

      {/* Overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-30 bg-black/50 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Main content */}
      <div className="lg:mr-72">
        <header className="sticky top-0 z-20 h-14 bg-card border-b border-border flex items-center justify-between px-3 sm:px-5">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setSidebarOpen(true)}
              aria-label="فتح القائمة"
              className="lg:hidden p-2 rounded-md hover:bg-muted"
            >
              <Menu className="size-5" />
            </button>
            <Link to="/" className="text-sm text-muted-foreground hover:text-foreground flex items-center gap-1">
              <ChevronLeft className="size-4" /> عرض المتجر
            </Link>
          </div>
          <div className="flex items-center gap-2">
            <span className="hidden sm:inline text-sm text-muted-foreground">
              {session?.email ?? 'مرحبًا'}
            </span>
          </div>
        </header>

        <main className="p-3 sm:p-5 max-w-7xl mx-auto">
          <Outlet />
        </main>
      </div>

      <Toaster richColors position="top-center" dir="rtl" />
    </div>
  )
}