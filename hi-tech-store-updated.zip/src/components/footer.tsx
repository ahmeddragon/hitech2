// Hi-Tech Footer
import { Link } from '@tanstack/react-router'
import { Facebook, Instagram, MapPin, Phone, Youtube } from 'lucide-react'
import type { Category, Settings } from '../lib/types'
import { Logo, WhatsappIcon } from './header'

type Props = {
  settings: Settings
  categories: Category[]
}

export function Footer({ settings, categories }: Props) {
  return (
    <footer className="bg-[var(--ht-blue-dark)] text-white mt-12">
      <div className="mx-auto max-w-7xl px-4 py-10 grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
        <div>
          <div className="flex items-center gap-2 mb-3">
            <Logo size={44} />
            <div>
              <p className="font-bold text-xl">{settings.store_name}</p>
              <p className="text-xs opacity-80">{settings.owner_name}</p>
            </div>
          </div>
          <p className="text-sm opacity-90 leading-7">{settings.store_description}</p>
          <div className="flex gap-2 mt-4">
            {settings.facebook_url && (
              <a
                href={settings.facebook_url}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Facebook"
                className="size-9 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center"
              >
                <Facebook className="size-4" />
              </a>
            )}
            {settings.instagram_url && (
              <a
                href={settings.instagram_url}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Instagram"
                className="size-9 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center"
              >
                <Instagram className="size-4" />
              </a>
            )}
            {settings.youtube_url && (
              <a
                href={settings.youtube_url}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="YouTube"
                className="size-9 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center"
              >
                <Youtube className="size-4" />
              </a>
            )}
          </div>
        </div>

        <div>
          <h3 className="font-bold mb-3 text-white/95">أقسام المتجر</h3>
          <ul className="space-y-2 text-sm opacity-90">
            <li><Link to="/products" className="hover:underline">كل المنتجات</Link></li>
            <li><Link to="/offers" className="hover:underline text-red-300">العروض</Link></li>
            <li><Link to="/services" className="hover:underline">الخدمات</Link></li>
            {categories.slice(0, 6).map((c) => (
              <li key={c.id}>
                <Link to="/category/$slug" params={{ slug: c.slug }} className="hover:underline">
                  {c.name}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h3 className="font-bold mb-3 text-white/95">روابط مهمة</h3>
          <ul className="space-y-2 text-sm opacity-90">
            <li><Link to="/" className="hover:underline">الرئيسية</Link></li>
            <li><Link to="/about" className="hover:underline">من نحن</Link></li>
            <li><Link to="/contact" className="hover:underline">اتصل بنا</Link></li>
            <li><Link to="/cart" className="hover:underline">سلة المشتريات</Link></li>
          </ul>
        </div>

        <div>
          <h3 className="font-bold mb-3 text-white/95">تواصل معنا</h3>
          <ul className="space-y-3 text-sm opacity-90">
            <li className="flex items-start gap-2">
              <MapPin className="size-4 mt-0.5 shrink-0" />
              <span>{settings.address}</span>
            </li>
            <li className="flex items-center gap-2">
              <Phone className="size-4 shrink-0" />
              <a href={`tel:${settings.phone}`} className="hover:underline tabular-nums">{settings.phone}</a>
            </li>
            <li className="flex items-center gap-2">
              <WhatsappIcon className="size-4 shrink-0" />
              <a
                href={`https://wa.me/${settings.whatsapp.replace(/^0/, '20')}`}
                target="_blank"
                rel="noopener noreferrer"
                className="hover:underline tabular-nums"
              >
                {settings.whatsapp}
              </a>
            </li>
            {settings.working_hours && (
              <li className="text-xs opacity-80 leading-6 mt-2">{settings.working_hours}</li>
            )}
          </ul>
        </div>
      </div>

      <div className="border-t border-white/10">
        <div className="mx-auto max-w-7xl px-4 py-4 text-center text-xs opacity-70">
          © {new Date().getFullYear()} {settings.store_name}. جميع الحقوق محفوظة.
        </div>
      </div>
    </footer>
  )
}

export function FloatingWhatsApp({ settings }: { settings: Settings }) {
  const message = settings.whatsapp_default_message ?? 'مرحبًا Hi-Tech، أريد الاستفسار عن أحد المنتجات.'
  const href = `https://wa.me/${settings.whatsapp.replace(/^0/, '20')}?text=${encodeURIComponent(message)}`
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="تواصل واتساب"
      className="fixed bottom-4 left-4 z-30 size-14 rounded-full bg-green-500 text-white flex items-center justify-center shadow-xl whatsapp-pulse hover:bg-green-600"
    >
      <WhatsappIcon className="size-7" />
    </a>
  )
}