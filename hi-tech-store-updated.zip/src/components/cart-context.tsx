// Cart context: persists in localStorage, syncs with URL on checkout
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from 'react'
import type { Cart, CartItem } from '../lib/types'

type CartContextValue = {
  items: CartItem[]
  subtotal: number
  discount: number
  total: number
  add: (item: CartItem) => void
  updateQuantity: (product_id: string, qty: number) => void
  remove: (product_id: string) => void
  clear: () => void
  itemCount: number
}

const CartContext = createContext<CartContextValue | null>(null)
const STORAGE_KEY = 'hitech-cart-v1'

function loadFromStorage(): CartItem[] {
  if (typeof window === 'undefined') return []
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY)
    if (!raw) return []
    const parsed = JSON.parse(raw) as CartItem[]
    if (!Array.isArray(parsed)) return []
    return parsed
  } catch {
    return []
  }
}

function saveToStorage(items: CartItem[]) {
  if (typeof window === 'undefined') return
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(items))
  } catch {}
}

function calcTotals(items: CartItem[]) {
  const subtotal = items.reduce((s, i) => s + i.unit_price * i.quantity, 0)
  const originalSubtotal = items.reduce(
    (s, i) => s + (i.original_price ?? i.unit_price) * i.quantity,
    0,
  )
  return {
    subtotal,
    discount: Math.max(0, originalSubtotal - subtotal),
    total: subtotal,
  }
}

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([])
  const [hydrated, setHydrated] = useState(false)

  useEffect(() => {
    setItems(loadFromStorage())
    setHydrated(true)
  }, [])

  useEffect(() => {
    if (hydrated) saveToStorage(items)
  }, [items, hydrated])

  const add = useCallback((newItem: CartItem) => {
    setItems((prev) => {
      const existing = prev.find((i) => i.product_id === newItem.product_id)
      if (existing) {
        return prev.map((i) =>
          i.product_id === newItem.product_id
            ? { ...i, quantity: Math.min(i.max_stock, i.quantity + newItem.quantity) }
            : i,
        )
      }
      return [...prev, newItem]
    })
  }, [])

  const updateQuantity = useCallback((product_id: string, qty: number) => {
    setItems((prev) =>
      prev
        .map((i) =>
          i.product_id === product_id
            ? { ...i, quantity: Math.max(1, Math.min(i.max_stock, qty)) }
            : i,
        )
        .filter((i) => i.quantity > 0),
    )
  }, [])

  const remove = useCallback((product_id: string) => {
    setItems((prev) => prev.filter((i) => i.product_id !== product_id))
  }, [])

  const clear = useCallback(() => setItems([]), [])

  const totals = useMemo(() => calcTotals(items), [items])
  const itemCount = items.reduce((s, i) => s + i.quantity, 0)

  return (
    <CartContext.Provider
      value={{ items, ...totals, add, updateQuantity, remove, clear, itemCount }}
    >
      {children}
    </CartContext.Provider>
  )
}

export function useCart() {
  const ctx = useContext(CartContext)
  if (!ctx) throw new Error('useCart must be used inside CartProvider')
  return ctx
}